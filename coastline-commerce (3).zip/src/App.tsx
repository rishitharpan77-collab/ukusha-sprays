import React from 'react';
import { StoreProvider } from './context/StoreContext';
import { Navbar } from './components/Navbar';
import { Hero } from './components/Hero';
import { ProductCatalog } from './components/ProductCatalog';
import { CoastalStory } from './components/CoastalStory';
import { CustomerReviews } from './components/CustomerReviews';
import { Footer } from './components/Footer';
import { ProductDetailModal } from './components/ProductDetailModal';
import { CartDrawer } from './components/CartDrawer';
import { CheckoutModal } from './components/CheckoutModal';
import { OrderConfirmationModal } from './components/OrderConfirmationModal';
import { LoyaltyModal } from './components/LoyaltyModal';
import { AdminDashboard } from './components/AdminDashboard';
import { OrderTrackerModal } from './components/OrderTrackerModal';
import { OrderTrackingSection } from './components/OrderTrackingSection';
import { OwnerLoginModal } from './components/OwnerLoginModal';
import { OwnerFloatingBar } from './components/OwnerFloatingBar';

export default function App() {
  return (
    <StoreProvider>
      <div className="min-h-screen flex flex-col bg-[#faf9f6] text-[#172428] selection:bg-[#133c46] selection:text-white">
        {/* Navigation Bar */}
        <Navbar />

        {/* Main Content Area */}
        <main className="flex-1">
          <Hero />
          <ProductCatalog />
          <CoastalStory />
          <OrderTrackingSection />
          <CustomerReviews />
        </main>

        {/* Footer */}
        <Footer />

        {/* Modals & Interactive Overlays */}
        <ProductDetailModal />
        <CartDrawer />
        <CheckoutModal />
        <OrderConfirmationModal />
        <LoyaltyModal />
        <AdminDashboard />
        <OrderTrackerModal />
        <OwnerLoginModal />
        <OwnerFloatingBar />
      </div>
    </StoreProvider>
  );
}
