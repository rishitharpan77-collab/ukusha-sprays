import React, { useState } from 'react';
import { 
  X, 
  Package, 
  ShoppingBag, 
  BarChart3, 
  Users, 
  Truck, 
  Edit3, 
  Plus, 
  Minus, 
  CheckCircle2, 
  ShieldCheck, 
  TrendingUp, 
  AlertTriangle,
  Award,
  Search,
  Save,
  LogOut
} from 'lucide-react';
import { useStore } from '../context/StoreContext';
import { Product, ProductVariant, Order, OrderStatus, CourierPickupDetails } from '../types';

export const AdminDashboard: React.FC = () => {
  const { 
    isAdminOpen, 
    toggleAdmin, 
    adminTab, 
    setAdminTab, 
    products, 
    updateProduct,
    orders, 
    updateOrderStatus, 
    scheduleCourierPickup,
    inventory, 
    updateInventoryStock, 
    customers,
    addBonusPoints,
    isOwnerAuthenticated,
    logoutOwner
  } = useStore();

  // Search & filter states
  const [orderFilter, setOrderFilter] = useState<'all' | OrderStatus>('all');
  const [searchTerm, setSearchTerm] = useState('');

  // Editing Product Modal state
  const [editingProduct, setEditingProduct] = useState<Product | null>(null);
  const [editProductForm, setEditProductForm] = useState<{
    name: string;
    subtitle: string;
    tagline: string;
    price: number;
    originalPrice?: number;
    holdLevel: Product['holdLevel'];
    finish: Product['finish'];
    badge?: string;
    inStock: boolean;
    variants: ProductVariant[];
  } | null>(null);

  // Courier Pickup Dispatch Modal state
  const [dispatchOrder, setDispatchOrder] = useState<Order | null>(null);
  const [pickupCarrier, setPickupCarrier] = useState<CourierPickupDetails['carrier']>('BlueDart Ocean Express');
  const [pickupTime, setPickupTime] = useState('Today at 4:30 PM');
  const [pickupNotes, setPickupNotes] = useState('Fragile marine glass texturizer bottles. Hand-off at Bay 3, Bandra Hub.');

  // Customer points award modal
  const [rewardCustomer, setRewardCustomer] = useState<{ id: string; name: string } | null>(null);
  const [pointsToAward, setPointsToAward] = useState(100);
  const [awardReason, setAwardReason] = useState('Store VIP Customer Courtesy Gift');

  if (!isAdminOpen || !isOwnerAuthenticated) return null;

  // Open Edit Product
  const startEditProduct = (prod: Product) => {
    setEditingProduct(prod);
    setEditProductForm({
      name: prod.name,
      subtitle: prod.subtitle,
      tagline: prod.tagline,
      price: prod.price,
      originalPrice: prod.originalPrice,
      holdLevel: prod.holdLevel,
      finish: prod.finish,
      badge: prod.badge || '',
      inStock: prod.inStock,
      variants: JSON.parse(JSON.stringify(prod.variants))
    });
  };

  const handleSaveProduct = (e: React.FormEvent) => {
    e.preventDefault();
    if (!editingProduct || !editProductForm) return;

    updateProduct(editingProduct.id, {
      name: editProductForm.name,
      subtitle: editProductForm.subtitle,
      tagline: editProductForm.tagline,
      price: Number(editProductForm.price),
      originalPrice: editProductForm.originalPrice ? Number(editProductForm.originalPrice) : undefined,
      holdLevel: editProductForm.holdLevel,
      finish: editProductForm.finish,
      badge: editProductForm.badge || undefined,
      inStock: editProductForm.inStock,
      variants: editProductForm.variants,
      totalStock: editProductForm.variants.reduce((sum, v) => sum + Number(v.stock), 0)
    });

    setEditingProduct(null);
    setEditProductForm(null);
  };

  const handleSaveDispatch = (e: React.FormEvent) => {
    e.preventDefault();
    if (!dispatchOrder) return;
    scheduleCourierPickup(dispatchOrder.id, pickupCarrier, pickupTime, pickupNotes);
    setDispatchOrder(null);
  };

  // Analytics Calculations (INR)
  const totalRevenue = orders.reduce((sum, o) => sum + o.total, 0);
  const totalOrdersCount = orders.length;
  const averageOrderValue = totalOrdersCount > 0 ? Math.round(totalRevenue / totalOrdersCount) : 0;

  const filteredOrders = orders.filter((o) => {
    if (orderFilter !== 'all' && o.status !== orderFilter) return false;
    if (!searchTerm.trim()) return true;
    const term = searchTerm.toLowerCase();
    return (
      o.orderNumber.toLowerCase().includes(term) ||
      o.customer.name.toLowerCase().includes(term) ||
      o.customer.email.toLowerCase().includes(term) ||
      o.courierPickup.trackingNumber.toLowerCase().includes(term)
    );
  });

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-2 sm:p-4 bg-stone-950/80 backdrop-blur-md overflow-hidden animate-fade-in">
      <div 
        className="bg-white rounded-2xl shadow-2xl w-full max-w-6xl h-[95vh] flex flex-col border border-stone-200 overflow-hidden"
        role="dialog"
        aria-modal="true"
        aria-labelledby="admin-title"
      >
        {/* Admin Bar Header */}
        <div className="bg-[#0f282f] text-white p-4 sm:p-5 flex items-center justify-between border-b border-[#1b434d]">
          <div className="flex items-center gap-3">
            <div className="w-9 h-9 rounded-xl bg-amber-500/20 text-amber-300 flex items-center justify-center font-bold">
              <ShoppingBag className="w-5 h-5" />
            </div>
            <div>
              <div className="flex items-center gap-2">
                <h2 id="admin-title" className="font-serif text-lg sm:text-xl font-bold">
                  Ukusha Sprays Store Management Portal (India)
                </h2>
                <span className="text-[10px] font-mono uppercase bg-amber-900/60 text-amber-300 border border-amber-600/50 px-2 py-0.5 rounded">
                  Store Owner View · INR (₹)
                </span>
              </div>
              <p className="text-xs text-stone-300">
                Live Sales Analytics (₹) · Real-time Price Editing · Courier Pickup Dispatch · Inventory Control
              </p>
            </div>
          </div>

          <div className="flex items-center gap-2">
            <button
              onClick={logoutOwner}
              className="px-3 py-1.5 text-xs font-semibold bg-rose-500/20 hover:bg-rose-500/30 text-rose-200 border border-rose-400/30 rounded-lg flex items-center gap-1.5 transition-colors"
              title="Log out and view store as a customer"
            >
              <LogOut className="w-3.5 h-3.5" />
              <span className="hidden sm:inline">Exit Owner Mode</span>
            </button>

            <button
              onClick={toggleAdmin}
              className="p-1.5 text-stone-300 hover:text-white rounded-lg hover:bg-white/10 transition-colors"
              aria-label="Close admin dashboard"
            >
              <X className="w-5 h-5" />
            </button>
          </div>
        </div>

        {/* Tab Navigation */}
        <div className="flex items-center border-b border-stone-200 px-6 bg-stone-50 overflow-x-auto">
          {[
            { id: 'products', label: 'Products & Pricing (₹)', icon: Edit3, count: products.length },
            { id: 'orders', label: 'Orders & Indian Couriers', icon: Truck, count: orders.length },
            { id: 'inventory', label: 'Inventory Control', icon: Package, count: inventory.length },
            { id: 'analytics', label: 'Sales Analytics (₹)', icon: BarChart3 },
            { id: 'customers', label: 'Customer Loyalty & CRM', icon: Users, count: customers.length }
          ].map((tab) => {
            const Icon = tab.icon;
            const isActive = adminTab === tab.id;
            return (
              <button
                key={tab.id}
                onClick={() => setAdminTab(tab.id as any)}
                className={`py-3.5 px-4 text-xs font-semibold border-b-2 flex items-center gap-2 transition-colors whitespace-nowrap ${
                  isActive
                    ? 'border-[#133c46] text-[#133c46] bg-white font-bold'
                    : 'border-transparent text-stone-600 hover:text-stone-900'
                }`}
              >
                <Icon className="w-4 h-4" />
                <span>{tab.label}</span>
                {tab.count !== undefined && (
                  <span className={`px-1.5 py-0.2 rounded text-[10px] tabular-nums ${
                    isActive ? 'bg-[#133c46] text-white' : 'bg-stone-200 text-stone-700'
                  }`}>
                    {tab.count}
                  </span>
                )}
              </button>
            );
          })}
        </div>

        {/* Content Body */}
        <div className="flex-1 overflow-y-auto p-6 bg-stone-100/60">
          
          {/* TAB 1: PRODUCTS & PRICING EDITING (₹) */}
          {adminTab === 'products' && (
            <div className="space-y-6">
              <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
                <div>
                  <h3 className="font-serif text-xl font-bold text-stone-900">
                    Product Catalog &amp; Indian Rupee (₹) Price Editing
                  </h3>
                  <p className="text-xs text-stone-500">
                    As the store owner, you can edit spray names, descriptions, base prices, comparison prices, and variant stocks. Changes update the live storefront immediately.
                  </p>
                </div>
              </div>

              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                {products.map((product) => (
                  <div key={product.id} className="p-5 bg-white rounded-xl border border-stone-200 shadow-xs flex flex-col justify-between">
                    <div>
                      <div className="flex gap-4">
                        <img
                          src={product.image}
                          alt={product.name}
                          className="w-20 h-20 rounded-lg object-cover bg-stone-100 shrink-0 border border-stone-200"
                          referrerPolicy="no-referrer"
                        />
                        <div className="flex-1 min-w-0">
                          <div className="flex items-center justify-between">
                            <span className="text-[11px] font-bold text-[#133c46] uppercase tracking-wider">
                              {product.category}
                            </span>
                            {product.badge && (
                              <span className="text-[10px] bg-stone-900 text-white px-2 py-0.5 rounded font-medium">
                                {product.badge}
                              </span>
                            )}
                          </div>
                          <h4 className="font-serif text-base font-bold text-stone-900 truncate mt-0.5">
                            {product.name}
                          </h4>
                          <p className="text-xs text-stone-500 line-clamp-1 mt-0.5">
                            {product.subtitle}
                          </p>

                          <div className="flex items-baseline gap-2 mt-2">
                            <span className="font-serif text-xl font-bold text-stone-900 tabular-nums">
                              ₹{product.price}
                            </span>
                            {product.originalPrice && (
                              <span className="text-xs text-stone-400 line-through tabular-nums">
                                ₹{product.originalPrice}
                              </span>
                            )}
                            <span className="text-xs text-emerald-800 bg-emerald-50 px-2 py-0.5 rounded font-medium ml-auto">
                              Total Stock: {product.totalStock}
                            </span>
                          </div>
                        </div>
                      </div>

                      {/* Variant breakdown pill list */}
                      <div className="mt-4 pt-3 border-t border-stone-100 space-y-1.5">
                        <div className="text-[11px] font-bold text-stone-700 uppercase tracking-wide">
                          Variants &amp; Pricing (₹):
                        </div>
                        <div className="grid grid-cols-1 sm:grid-cols-3 gap-1.5">
                          {product.variants.map((v) => (
                            <div key={v.id} className="p-2 bg-stone-50 rounded-lg text-[11px] border border-stone-200/80">
                              <div className="font-semibold text-stone-900 truncate">{v.size}</div>
                              <div className="text-[#133c46] font-bold tabular-nums">₹{v.price} ({v.stock} in stock)</div>
                            </div>
                          ))}
                        </div>
                      </div>
                    </div>

                    <div className="mt-5 pt-3 border-t border-stone-100 flex items-center justify-between">
                      <div className="flex items-center gap-1.5 text-xs">
                        <span className={`w-2 h-2 rounded-full ${product.inStock ? 'bg-emerald-500' : 'bg-rose-500'}`} />
                        <span className="text-stone-600 font-medium">
                          {product.inStock ? 'Active on Storefront' : 'Hidden / Out of Stock'}
                        </span>
                      </div>

                      <button
                        onClick={() => startEditProduct(product)}
                        className="px-3.5 py-1.5 text-xs font-bold text-white bg-[#133c46] hover:bg-[#0e2a30] rounded-lg transition-colors flex items-center gap-1.5 shadow-xs"
                      >
                        <Edit3 className="w-3.5 h-3.5" />
                        <span>Edit Details &amp; Prices</span>
                      </button>
                    </div>
                  </div>
                ))}
              </div>
            </div>
          )}

          {/* TAB 2: ORDERS & COURIER PICKUP MANAGEMENT */}
          {adminTab === 'orders' && (
            <div className="space-y-4">
              <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
                <div>
                  <h3 className="font-serif text-xl font-bold text-stone-900">
                    Customer Orders &amp; Courier Pickup Logistics (India)
                  </h3>
                  <p className="text-xs text-stone-500">
                    Fulfill purchases by dispatching couriers (BlueDart / Delhivery / DTDC) directly from your Mumbai warehouse to pick up packages and deliver to customers across India.
                  </p>
                </div>

                {/* Search & Filter */}
                <div className="flex items-center gap-2">
                  <div className="relative">
                    <Search className="w-3.5 h-3.5 text-stone-400 absolute left-2.5 top-1/2 -translate-y-1/2" />
                    <input
                      type="text"
                      placeholder="Search order #, customer..."
                      value={searchTerm}
                      onChange={(e) => setSearchTerm(e.target.value)}
                      className="pl-8 pr-3 py-1.5 text-xs bg-white border border-stone-300 rounded-lg w-44"
                    />
                  </div>

                  <select
                    value={orderFilter}
                    onChange={(e) => setOrderFilter(e.target.value as any)}
                    className="text-xs bg-white border border-stone-300 rounded-lg px-2.5 py-1.5 font-medium"
                  >
                    <option value="all">All Statuses</option>
                    <option value="pickup_scheduled">Pickup Scheduled</option>
                    <option value="carrier_picked_up">Picked Up by Courier</option>
                    <option value="in_transit">In Transit</option>
                    <option value="delivered">Delivered</option>
                  </select>
                </div>
              </div>

              {/* Orders Table */}
              <div className="bg-white rounded-xl border border-stone-200 overflow-hidden shadow-xs">
                <table className="w-full text-left text-xs">
                  <thead className="bg-stone-50 text-stone-700 font-bold border-b border-stone-200">
                    <tr>
                      <th className="p-3.5">Order #</th>
                      <th className="p-3.5">Customer &amp; Drop-off</th>
                      <th className="p-3.5">Items</th>
                      <th className="p-3.5">Total &amp; Payment (₹)</th>
                      <th className="p-3.5">Courier Pickup Dispatch</th>
                      <th className="p-3.5">Status Action</th>
                    </tr>
                  </thead>
                  <tbody className="divide-y divide-stone-100">
                    {filteredOrders.length === 0 ? (
                      <tr>
                        <td colSpan={6} className="p-8 text-center text-stone-500">
                          No orders match the selected filters.
                        </td>
                      </tr>
                    ) : (
                      filteredOrders.map((ord) => (
                        <tr key={ord.id} className="hover:bg-stone-50/80 transition-colors">
                          <td className="p-3.5 font-mono font-bold text-stone-900">
                            #{ord.orderNumber}
                            <div className="text-[11px] text-stone-400 font-sans font-normal">
                              {new Date(ord.createdAt).toLocaleDateString()}
                            </div>
                          </td>

                          <td className="p-3.5">
                            <div className="font-bold text-stone-900">{ord.customer.name}</div>
                            <div className="text-stone-500 text-[11px] truncate max-w-[180px]">
                              {ord.customer.city}, {ord.customer.state} ({ord.customer.postalCode})
                            </div>
                            <div className="text-stone-400 text-[10px]">{ord.customer.phone}</div>
                          </td>

                          <td className="p-3.5">
                            <div className="space-y-0.5">
                              {ord.items.map((it, i) => (
                                <div key={i} className="text-[11px] text-stone-800 truncate max-w-[160px]">
                                  {it.quantity}× {it.product.name} ({it.selectedVariant.size.split(' ')[0]})
                                </div>
                              ))}
                            </div>
                          </td>

                          <td className="p-3.5">
                            <div className="font-serif font-bold text-stone-900 text-sm tabular-nums">
                              ₹{ord.total}
                            </div>
                            <div className="text-[10px] text-emerald-800 font-medium">
                              {ord.payment.method === 'upi' ? `UPI: ${ord.payment.upiId}` : ord.payment.cardBrand}
                            </div>
                          </td>

                          <td className="p-3.5">
                            <div className="font-bold text-[#133c46] flex items-center gap-1">
                              <Truck className="w-3.5 h-3.5" />
                              <span>{ord.courierPickup.carrier}</span>
                            </div>
                            <div className="text-[11px] font-mono text-stone-600 mt-0.5">
                              AWB: {ord.courierPickup.trackingNumber}
                            </div>
                            <div className="text-[10px] text-stone-500">
                              Pickup: {ord.courierPickup.pickupScheduledTime}
                            </div>
                          </td>

                          <td className="p-3.5">
                            <div className="space-y-1.5">
                              <select
                                value={ord.status}
                                onChange={(e) => updateOrderStatus(ord.id, e.target.value as any)}
                                className={`text-[11px] font-bold rounded-md px-2 py-1 border cursor-pointer ${
                                  ord.status === 'delivered'
                                    ? 'bg-emerald-50 text-emerald-800 border-emerald-300'
                                    : ord.status === 'in_transit' || ord.status === 'carrier_picked_up'
                                    ? 'bg-blue-50 text-blue-800 border-blue-300'
                                    : 'bg-amber-50 text-amber-800 border-amber-300'
                                }`}
                              >
                                <option value="pickup_scheduled">Pickup Scheduled</option>
                                <option value="carrier_picked_up">Courier Collected from Merchant</option>
                                <option value="in_transit">In Transit to Customer</option>
                                <option value="out_for_delivery">Out for Doorstep Delivery</option>
                                <option value="delivered">Delivered Successfully</option>
                              </select>

                              <button
                                onClick={() => {
                                  setDispatchOrder(ord);
                                  setPickupCarrier(ord.courierPickup.carrier);
                                }}
                                className="block text-[10px] text-[#133c46] hover:underline font-semibold"
                              >
                                Modify Courier Pickup &rarr;
                              </button>
                            </div>
                          </td>
                        </tr>
                      ))
                    )}
                  </tbody>
                </table>
              </div>
            </div>
          )}

          {/* TAB 3: INVENTORY CONTROL */}
          {adminTab === 'inventory' && (
            <div className="space-y-4">
              <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
                <div>
                  <h3 className="font-serif text-xl font-bold text-stone-900">
                    Live Inventory &amp; Stock Levels
                  </h3>
                  <p className="text-xs text-stone-500">
                    Real-time stock tracking for each formula and size variant with automatic replenishment alerts.
                  </p>
                </div>
              </div>

              <div className="bg-white rounded-xl border border-stone-200 overflow-hidden shadow-xs">
                <table className="w-full text-left text-xs">
                  <thead className="bg-stone-50 text-stone-700 font-bold border-b border-stone-200">
                    <tr>
                      <th className="p-3.5">Product &amp; Variant</th>
                      <th className="p-3.5">SKU</th>
                      <th className="p-3.5">Unit Cost / Retail (₹)</th>
                      <th className="p-3.5">Available Stock</th>
                      <th className="p-3.5">Reserved</th>
                      <th className="p-3.5">Stock Status</th>
                      <th className="p-3.5 text-right">Quick Stock Adjustment</th>
                    </tr>
                  </thead>
                  <tbody className="divide-y divide-stone-100">
                    {inventory.map((inv) => {
                      const isLow = inv.availableStock <= inv.lowStockThreshold;
                      return (
                        <tr key={inv.variantId} className="hover:bg-stone-50/80">
                          <td className="p-3.5">
                            <div className="font-bold text-stone-900">{inv.productName}</div>
                            <div className="text-[11px] text-stone-500">{inv.variantSize}</div>
                          </td>

                          <td className="p-3.5 font-mono text-[11px] text-stone-600">
                            {inv.sku}
                          </td>

                          <td className="p-3.5">
                            <div className="tabular-nums font-semibold text-stone-900">₹{inv.retailPrice}</div>
                            <div className="text-[10px] text-stone-400">Cost: ₹{inv.costPrice}</div>
                          </td>

                          <td className="p-3.5 font-bold font-mono text-stone-900 text-sm tabular-nums">
                            {inv.availableStock}
                          </td>

                          <td className="p-3.5 font-mono text-stone-500 tabular-nums">
                            {inv.reservedStock}
                          </td>

                          <td className="p-3.5">
                            {isLow ? (
                              <span className="inline-flex items-center gap-1 text-[11px] font-bold text-amber-800 bg-amber-50 border border-amber-200 px-2 py-0.5 rounded">
                                <AlertTriangle className="w-3 h-3 text-amber-600" />
                                Low Stock (&le;{inv.lowStockThreshold})
                              </span>
                            ) : (
                              <span className="inline-flex items-center gap-1 text-[11px] font-bold text-emerald-800 bg-emerald-50 border border-emerald-200 px-2 py-0.5 rounded">
                                <CheckCircle2 className="w-3 h-3 text-emerald-600" />
                                In Stock
                              </span>
                            )}
                          </td>

                          <td className="p-3.5 text-right">
                            <div className="inline-flex items-center gap-1 border border-stone-200 rounded-lg bg-stone-50 p-1">
                              <button
                                onClick={() => updateInventoryStock(inv.variantId, -5)}
                                className="p-1 hover:bg-white rounded text-stone-600 hover:text-stone-900"
                                title="Reduce 5 units"
                              >
                                -5
                              </button>
                              <button
                                onClick={() => updateInventoryStock(inv.variantId, -1)}
                                className="p-1 hover:bg-white rounded text-stone-600 hover:text-stone-900"
                                title="Reduce 1 unit"
                              >
                                <Minus className="w-3 h-3" />
                              </button>
                              <button
                                onClick={() => updateInventoryStock(inv.variantId, 1)}
                                className="p-1 hover:bg-white rounded text-stone-600 hover:text-stone-900"
                                title="Add 1 unit"
                              >
                                <Plus className="w-3 h-3" />
                              </button>
                              <button
                                onClick={() => updateInventoryStock(inv.variantId, 25)}
                                className="p-1 hover:bg-white rounded font-bold text-[#133c46] hover:text-[#0e2a30]"
                                title="Restock +25 units"
                              >
                                +25
                              </button>
                            </div>
                          </td>
                        </tr>
                      );
                    })}
                  </tbody>
                </table>
              </div>
            </div>
          )}

          {/* TAB 4: SALES ANALYTICS (₹) */}
          {adminTab === 'analytics' && (
            <div className="space-y-6">
              <div>
                <h3 className="font-serif text-xl font-bold text-stone-900">
                  Store Sales Performance &amp; Conversion Metrics (INR ₹)
                </h3>
                <p className="text-xs text-stone-500">
                  Real-time sales velocity, average order values, and cart conversion telemetry in Indian Rupees.
                </p>
              </div>

              {/* 4 KPI Cards */}
              <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
                <div className="p-4 bg-white rounded-xl border border-stone-200 shadow-xs">
                  <div className="flex items-center justify-between text-stone-500 text-xs font-semibold">
                    <span>Total Net Revenue</span>
                    <span className="font-serif font-bold text-emerald-600 text-sm">₹</span>
                  </div>
                  <div className="font-serif text-2xl font-bold text-stone-900 mt-2 tabular-nums">
                    ₹{totalRevenue.toLocaleString('en-IN')}
                  </div>
                  <div className="text-[11px] text-emerald-700 font-medium mt-1">
                    +18.4% from last week
                  </div>
                </div>

                <div className="p-4 bg-white rounded-xl border border-stone-200 shadow-xs">
                  <div className="flex items-center justify-between text-stone-500 text-xs font-semibold">
                    <span>Orders Processed</span>
                    <ShoppingBag className="w-4 h-4 text-[#133c46]" />
                  </div>
                  <div className="font-serif text-2xl font-bold text-stone-900 mt-2 tabular-nums">
                    {totalOrdersCount}
                  </div>
                  <div className="text-[11px] text-stone-500 mt-1">
                    100% courier pickups dispatched
                  </div>
                </div>

                <div className="p-4 bg-white rounded-xl border border-stone-200 shadow-xs">
                  <div className="flex items-center justify-between text-stone-500 text-xs font-semibold">
                    <span>Average Order Value</span>
                    <TrendingUp className="w-4 h-4 text-blue-600" />
                  </div>
                  <div className="font-serif text-2xl font-bold text-stone-900 mt-2 tabular-nums">
                    ₹{averageOrderValue.toLocaleString('en-IN')}
                  </div>
                  <div className="text-[11px] text-stone-500 mt-1">
                    Boosted by Trilogy Vault bundles
                  </div>
                </div>

                <div className="p-4 bg-white rounded-xl border border-stone-200 shadow-xs">
                  <div className="flex items-center justify-between text-stone-500 text-xs font-semibold">
                    <span>Cart Abandonment</span>
                    <ShieldCheck className="w-4 h-4 text-emerald-600" />
                  </div>
                  <div className="font-serif text-2xl font-bold text-emerald-700 mt-2 tabular-nums">
                    14.2%
                  </div>
                  <div className="text-[11px] text-stone-500 mt-1">
                    Industry avg: 69.8% (Minimized by 1-click UPI checkout)
                  </div>
                </div>
              </div>

              {/* Sales Chart Visualization */}
              <div className="p-5 bg-white rounded-xl border border-stone-200 shadow-xs space-y-4">
                <div className="flex items-center justify-between">
                  <div>
                    <h4 className="font-serif text-base font-bold text-stone-900">
                      Weekly Revenue &amp; Indian Courier Dispatches
                    </h4>
                    <p className="text-xs text-stone-500">Daily gross volume across all texturizing formulas (in ₹)</p>
                  </div>
                  <span className="text-xs font-bold text-[#133c46] bg-[#eef7f6] px-2.5 py-1 rounded-lg">
                    Real-time Data Active
                  </span>
                </div>

                {/* Clean SVG Bar Chart */}
                <div className="pt-4">
                  <div className="h-44 w-full flex items-end justify-between gap-3 px-2 border-b border-stone-200 pb-2">
                    {[
                      { day: 'Mon', amount: 14200, orders: 8 },
                      { day: 'Tue', amount: 22400, orders: 12 },
                      { day: 'Wed', amount: 18900, orders: 10 },
                      { day: 'Thu', amount: 34500, orders: 19 },
                      { day: 'Fri', amount: 48900, orders: 26 },
                      { day: 'Sat', amount: 56400, orders: 31 },
                      { day: 'Sun', amount: 42300, orders: 22 }
                    ].map((bar, i) => (
                      <div key={i} className="flex-1 flex flex-col items-center gap-1.5 h-full justify-end group">
                        <div className="text-[10px] font-mono font-bold text-stone-500 opacity-0 group-hover:opacity-100 transition-opacity tabular-nums">
                          ₹{(bar.amount / 1000).toFixed(1)}k
                        </div>
                        <div 
                          className="w-full bg-[#133c46] hover:bg-[#0d2a31] rounded-t-lg transition-all"
                          style={{ height: `${(bar.amount / 60000) * 100}%` }}
                        />
                        <span className="text-xs font-semibold text-stone-600">{bar.day}</span>
                      </div>
                    ))}
                  </div>
                </div>
              </div>
            </div>
          )}

          {/* TAB 5: CUSTOMER CRM & LOYALTY */}
          {adminTab === 'customers' && (
            <div className="space-y-4">
              <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
                <div>
                  <h3 className="font-serif text-xl font-bold text-stone-900">
                    Customer Engagement &amp; Loyalty Circle CRM
                  </h3>
                  <p className="text-xs text-stone-500">
                    Track customer lifetime spend (₹), points balances, and reward loyalty members with bonus credits.
                  </p>
                </div>
              </div>

              <div className="bg-white rounded-xl border border-stone-200 overflow-hidden shadow-xs">
                <table className="w-full text-left text-xs">
                  <thead className="bg-stone-50 text-stone-700 font-bold border-b border-stone-200">
                    <tr>
                      <th className="p-3.5">Customer Name &amp; Email</th>
                      <th className="p-3.5">Tier Status</th>
                      <th className="p-3.5">Available Points</th>
                      <th className="p-3.5">Lifetime Points</th>
                      <th className="p-3.5">Total Spend (₹)</th>
                      <th className="p-3.5">Orders</th>
                      <th className="p-3.5 text-right">Award Points</th>
                    </tr>
                  </thead>
                  <tbody className="divide-y divide-stone-100">
                    {customers.map((c) => (
                      <tr key={c.id} className="hover:bg-stone-50/80">
                        <td className="p-3.5">
                          <div className="font-bold text-stone-900">{c.name}</div>
                          <div className="text-[11px] text-stone-500">{c.email}</div>
                          <div className="text-[10px] text-stone-400">{c.city}, {c.state} ({c.postalCode})</div>
                        </td>

                        <td className="p-3.5">
                          <span className={`inline-flex items-center gap-1 text-[11px] font-bold px-2 py-0.5 rounded ${
                            c.tier === 'High Tide VIP'
                              ? 'bg-amber-100 text-amber-900 border border-amber-300'
                              : c.tier === 'Tide Explorer'
                              ? 'bg-[#e3f3f2] text-[#133c46] border border-[#a6ded8]'
                              : 'bg-stone-100 text-stone-800'
                          }`}>
                            <Award className="w-3 h-3" />
                            {c.tier}
                          </span>
                        </td>

                        <td className="p-3.5 font-mono font-bold text-[#133c46] text-sm tabular-nums">
                          {c.pointsBalance} pts
                        </td>

                        <td className="p-3.5 font-mono text-stone-600 tabular-nums">
                          {c.lifetimePointsEarned} pts
                        </td>

                        <td className="p-3.5 font-serif font-bold text-stone-900 tabular-nums">
                          ₹{c.totalSpend.toLocaleString('en-IN')}
                        </td>

                        <td className="p-3.5 font-mono text-stone-700 tabular-nums">
                          {c.ordersCount}
                        </td>

                        <td className="p-3.5 text-right">
                          <button
                            onClick={() => setRewardCustomer({ id: c.id, name: c.name })}
                            className="px-3 py-1.5 text-xs font-semibold text-[#133c46] bg-[#eef7f6] hover:bg-[#deeeec] border border-[#c4e6e2] rounded-lg transition-colors whitespace-nowrap"
                          >
                            + Award Points
                          </button>
                        </td>
                      </tr>
                    ))}
                  </tbody>
                </table>
              </div>
            </div>
          )}

        </div>

        {/* MODAL 1: Edit Product Details & Prices (Store Owner Tool in ₹) */}
        {editingProduct && editProductForm && (
          <div className="fixed inset-0 z-60 flex items-center justify-center p-4 bg-stone-950/75 backdrop-blur-xs">
            <div className="bg-white rounded-2xl shadow-2xl max-w-2xl w-full max-h-[90vh] flex flex-col overflow-hidden border border-stone-300 animate-fade-in">
              <div className="p-5 bg-[#0f282f] text-white flex items-center justify-between">
                <div>
                  <h3 className="font-serif text-lg font-bold">Edit Product: {editingProduct.name}</h3>
                  <p className="text-xs text-stone-300">Modify title, pricing (₹), hold, and size variants</p>
                </div>
                <button
                  onClick={() => setEditingProduct(null)}
                  className="p-1 text-stone-300 hover:text-white rounded-lg hover:bg-white/10"
                >
                  <X className="w-5 h-5" />
                </button>
              </div>

              <form onSubmit={handleSaveProduct} className="p-6 overflow-y-auto space-y-4 flex-1 text-xs">
                <div>
                  <label className="block font-bold text-stone-700 mb-1">Product Title</label>
                  <input
                    type="text"
                    value={editProductForm.name}
                    onChange={(e) => setEditProductForm({ ...editProductForm, name: e.target.value })}
                    className="w-full px-3 py-2 border border-stone-300 rounded-lg text-xs"
                    required
                  />
                </div>

                <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                  <div>
                    <label className="block font-bold text-stone-700 mb-1">Base Price (₹)</label>
                    <input
                      type="number"
                      value={editProductForm.price}
                      onChange={(e) => setEditProductForm({ ...editProductForm, price: parseInt(e.target.value, 10) || 0 })}
                      className="w-full px-3 py-2 border border-stone-300 rounded-lg text-xs font-mono"
                      required
                    />
                  </div>
                  <div>
                    <label className="block font-bold text-stone-700 mb-1">Original / Compare Price (₹)</label>
                    <input
                      type="number"
                      value={editProductForm.originalPrice || ''}
                      onChange={(e) => setEditProductForm({ ...editProductForm, originalPrice: parseInt(e.target.value, 10) || undefined })}
                      placeholder="e.g. 1899"
                      className="w-full px-3 py-2 border border-stone-300 rounded-lg text-xs font-mono"
                    />
                  </div>
                </div>

                <div>
                  <label className="block font-bold text-stone-700 mb-1">Subtitle / Headline</label>
                  <input
                    type="text"
                    value={editProductForm.subtitle}
                    onChange={(e) => setEditProductForm({ ...editProductForm, subtitle: e.target.value })}
                    className="w-full px-3 py-2 border border-stone-300 rounded-lg text-xs"
                  />
                </div>

                <div className="grid grid-cols-1 sm:grid-cols-3 gap-3">
                  <div>
                    <label className="block font-bold text-stone-700 mb-1">Hold Level</label>
                    <select
                      value={editProductForm.holdLevel}
                      onChange={(e) => setEditProductForm({ ...editProductForm, holdLevel: e.target.value as any })}
                      className="w-full px-3 py-2 border border-stone-300 rounded-lg text-xs bg-white"
                    >
                      <option value="Light Natural">Light Natural</option>
                      <option value="Medium Textured">Medium Textured</option>
                      <option value="Firm Gritty">Firm Gritty</option>
                    </select>
                  </div>
                  <div>
                    <label className="block font-bold text-stone-700 mb-1">Finish</label>
                    <select
                      value={editProductForm.finish}
                      onChange={(e) => setEditProductForm({ ...editProductForm, finish: e.target.value as any })}
                      className="w-full px-3 py-2 border border-stone-300 rounded-lg text-xs bg-white"
                    >
                      <option value="Matte Beach Natural">Matte Beach Natural</option>
                      <option value="Satin Hydrated">Satin Hydrated</option>
                      <option value="Wind-Blown Matte">Wind-Blown Matte</option>
                    </select>
                  </div>
                  <div>
                    <label className="block font-bold text-stone-700 mb-1">Promotional Badge</label>
                    <input
                      type="text"
                      value={editProductForm.badge}
                      onChange={(e) => setEditProductForm({ ...editProductForm, badge: e.target.value })}
                      placeholder="e.g. Best Seller, Limited Run"
                      className="w-full px-3 py-2 border border-stone-300 rounded-lg text-xs"
                    />
                  </div>
                </div>

                {/* Variant prices and stock editor */}
                <div className="pt-2 border-t border-stone-200">
                  <div className="font-bold text-stone-800 uppercase tracking-wide text-[11px] mb-2">
                    Size Variants &amp; Inventory Stock
                  </div>
                  <div className="space-y-2">
                    {editProductForm.variants.map((v, idx) => (
                      <div key={v.id} className="p-3 bg-stone-50 rounded-xl border border-stone-200 grid grid-cols-1 sm:grid-cols-3 gap-2 items-center">
                        <div>
                          <div className="font-bold text-stone-900">{v.size}</div>
                          <div className="text-stone-400 text-[10px]">{v.volumeMl}ml bottle</div>
                        </div>
                        <div>
                          <label className="text-[10px] text-stone-500 font-semibold block">Price (₹)</label>
                          <input
                            type="number"
                            value={v.price}
                            onChange={(e) => {
                              const updatedVariants = [...editProductForm.variants];
                              updatedVariants[idx].price = parseInt(e.target.value, 10) || 0;
                              setEditProductForm({ ...editProductForm, variants: updatedVariants });
                            }}
                            className="w-full px-2 py-1 border border-stone-300 rounded bg-white font-mono text-xs"
                          />
                        </div>
                        <div>
                          <label className="text-[10px] text-stone-500 font-semibold block">Available Stock</label>
                          <input
                            type="number"
                            value={v.stock}
                            onChange={(e) => {
                              const updatedVariants = [...editProductForm.variants];
                              updatedVariants[idx].stock = parseInt(e.target.value, 10) || 0;
                              setEditProductForm({ ...editProductForm, variants: updatedVariants });
                            }}
                            className="w-full px-2 py-1 border border-stone-300 rounded bg-white font-mono text-xs"
                          />
                        </div>
                      </div>
                    ))}
                  </div>
                </div>

                <div className="pt-2 flex items-center justify-between border-t border-stone-200">
                  <label className="flex items-center gap-2 cursor-pointer font-bold text-stone-800">
                    <input
                      type="checkbox"
                      checked={editProductForm.inStock}
                      onChange={(e) => setEditProductForm({ ...editProductForm, inStock: e.target.checked })}
                      className="rounded text-[#133c46]"
                    />
                    <span>Available for Purchase (In Stock)</span>
                  </label>

                  <div className="flex gap-2">
                    <button
                      type="button"
                      onClick={() => setEditingProduct(null)}
                      className="px-4 py-2 border border-stone-300 text-stone-700 rounded-lg hover:bg-stone-50"
                    >
                      Cancel
                    </button>
                    <button
                      type="submit"
                      className="px-5 py-2 font-bold text-white bg-[#133c46] hover:bg-[#0e2a30] rounded-lg shadow-sm flex items-center gap-1.5"
                    >
                      <Save className="w-4 h-4" />
                      <span>Save Changes</span>
                    </button>
                  </div>
                </div>
              </form>
            </div>
          </div>
        )}

        {/* MODAL 2: Courier Pickup Dispatch Modal (Indian Carriers) */}
        {dispatchOrder && (
          <div className="fixed inset-0 z-60 flex items-center justify-center p-4 bg-stone-950/75 backdrop-blur-xs">
            <div className="bg-white rounded-2xl shadow-2xl max-w-lg w-full flex flex-col overflow-hidden border border-stone-300 animate-fade-in">
              <div className="p-5 bg-[#0f282f] text-white flex items-center justify-between">
                <div>
                  <h3 className="font-serif text-lg font-bold">Schedule Courier Warehouse Pickup</h3>
                  <p className="text-xs text-stone-300">Order #{dispatchOrder.orderNumber} &rarr; {dispatchOrder.customer.name}</p>
                </div>
                <button
                  onClick={() => setDispatchOrder(null)}
                  className="p-1 text-stone-300 hover:text-white rounded-lg hover:bg-white/10"
                >
                  <X className="w-5 h-5" />
                </button>
              </div>

              <form onSubmit={handleSaveDispatch} className="p-6 space-y-4 text-xs">
                <div>
                  <label className="block font-bold text-stone-700 mb-1">Select Indian Shipping Carrier for Pickup</label>
                  <select
                    value={pickupCarrier}
                    onChange={(e) => setPickupCarrier(e.target.value as any)}
                    className="w-full px-3 py-2 border border-stone-300 rounded-lg bg-white"
                  >
                    <option value="BlueDart Ocean Express">BlueDart Ocean Express (Priority Air)</option>
                    <option value="Delhivery Coastal Priority">Delhivery Coastal Priority (Pan-India)</option>
                    <option value="DTDC Green Express">DTDC Green Express (Regional)</option>
                  </select>
                </div>

                <div>
                  <label className="block font-bold text-stone-700 mb-1">Pickup From Merchant Location</label>
                  <input
                    type="text"
                    disabled
                    value="Ukusha Sprays Fulfillment Hub - Bandra Coastal Dock, Mumbai 400050"
                    className="w-full px-3 py-2 border border-stone-200 bg-stone-100 rounded-lg text-stone-600"
                  />
                </div>

                <div>
                  <label className="block font-bold text-stone-700 mb-1">Scheduled Driver Pickup Window</label>
                  <input
                    type="text"
                    value={pickupTime}
                    onChange={(e) => setPickupTime(e.target.value)}
                    placeholder="e.g. Today between 4:00 PM - 6:00 PM"
                    className="w-full px-3 py-2 border border-stone-300 rounded-lg"
                    required
                  />
                </div>

                <div>
                  <label className="block font-bold text-stone-700 mb-1">Courier Packaging &amp; Driver Instructions</label>
                  <textarea
                    rows={2}
                    value={pickupNotes}
                    onChange={(e) => setPickupNotes(e.target.value)}
                    className="w-full px-3 py-2 border border-stone-300 rounded-lg"
                  />
                </div>

                <div className="p-3 bg-stone-50 rounded-xl border border-stone-200 text-stone-600">
                  <div className="font-bold text-stone-800">Automated Indian Logistics Protocol:</div>
                  <div className="mt-1">
                    Clicking dispatch generates a digital courier Airway Bill (AWB), assigns a BlueDart / Delhivery driver, and notifies the customer with SMS tracking from Mumbai pickup to doorstep drop-off.
                  </div>
                </div>

                <div className="pt-2 flex justify-end gap-2">
                  <button
                    type="button"
                    onClick={() => setDispatchOrder(null)}
                    className="px-4 py-2 border border-stone-300 text-stone-700 rounded-lg hover:bg-stone-50"
                  >
                    Cancel
                  </button>
                  <button
                    type="submit"
                    className="px-5 py-2 font-bold text-white bg-[#133c46] hover:bg-[#0e2a30] rounded-lg shadow-sm flex items-center gap-1.5"
                  >
                    <Truck className="w-4 h-4" />
                    <span>Confirm Courier Dispatch</span>
                  </button>
                </div>
              </form>
            </div>
          </div>
        )}

        {/* MODAL 3: Award Points to Customer */}
        {rewardCustomer && (
          <div className="fixed inset-0 z-60 flex items-center justify-center p-4 bg-stone-950/75 backdrop-blur-xs">
            <div className="bg-white rounded-2xl shadow-2xl max-w-md w-full flex flex-col overflow-hidden border border-stone-300 animate-fade-in">
              <div className="p-5 bg-[#0f282f] text-white flex items-center justify-between">
                <div>
                  <h3 className="font-serif text-lg font-bold">Award Loyalty Points</h3>
                  <p className="text-xs text-stone-300">Member: {rewardCustomer.name}</p>
                </div>
                <button
                  onClick={() => setRewardCustomer(null)}
                  className="p-1 text-stone-300 hover:text-white rounded-lg hover:bg-white/10"
                >
                  <X className="w-5 h-5" />
                </button>
              </div>

              <div className="p-6 space-y-4 text-xs">
                <div>
                  <label className="block font-bold text-stone-700 mb-1">Points to Grant</label>
                  <input
                    type="number"
                    value={pointsToAward}
                    onChange={(e) => setPointsToAward(parseInt(e.target.value, 10) || 0)}
                    className="w-full px-3 py-2 border border-stone-300 rounded-lg font-mono text-sm"
                  />
                </div>

                <div>
                  <label className="block font-bold text-stone-700 mb-1">Reason / Note</label>
                  <input
                    type="text"
                    value={awardReason}
                    onChange={(e) => setAwardReason(e.target.value)}
                    className="w-full px-3 py-2 border border-stone-300 rounded-lg"
                  />
                </div>

                <div className="pt-2 flex justify-end gap-2">
                  <button
                    type="button"
                    onClick={() => setRewardCustomer(null)}
                    className="px-4 py-2 border border-stone-300 text-stone-700 rounded-lg hover:bg-stone-50"
                  >
                    Cancel
                  </button>
                  <button
                    type="button"
                    onClick={() => {
                      addBonusPoints(pointsToAward, awardReason);
                      setRewardCustomer(null);
                    }}
                    className="px-5 py-2 font-bold text-white bg-[#133c46] hover:bg-[#0e2a30] rounded-lg shadow-sm flex items-center gap-1.5"
                  >
                    <Award className="w-4 h-4" />
                    <span>Credit Points</span>
                  </button>
                </div>
              </div>
            </div>
          </div>
        )}

      </div>
    </div>
  );
};
