import React, { useState } from 'react';
import { 
  X, 
  Trash2, 
  Plus, 
  Minus, 
  ShoppingBag, 
  ShieldCheck, 
  Truck, 
  ArrowRight, 
  Tag, 
  Award, 
  Check 
} from 'lucide-react';
import { useStore } from '../context/StoreContext';

export const CartDrawer: React.FC = () => {
  const { 
    cart, 
    isCartOpen, 
    closeCart, 
    removeFromCart, 
    updateQuantity, 
    cartSubtotal, 
    discountCode, 
    discountAmount, 
    applyPromoCode, 
    removePromoCode, 
    cartTotal, 
    pointsToEarn, 
    openCheckout,
    openLoyaltyModal,
    customer
  } = useStore();

  const [promoInput, setPromoInput] = useState('');
  const [promoMessage, setPromoMessage] = useState<{ text: string; success: boolean } | null>(null);

  if (!isCartOpen) return null;

  const freeShippingThreshold = 999.00;
  const amountToFreeShipping = Math.max(0, freeShippingThreshold - cartSubtotal);
  const freeShippingProgress = Math.min(100, Math.round((cartSubtotal / freeShippingThreshold) * 100));

  const handleApplyPromo = (e: React.FormEvent) => {
    e.preventDefault();
    if (!promoInput.trim()) return;
    const res = applyPromoCode(promoInput);
    setPromoMessage({ text: res.message, success: res.success });
    if (res.success) {
      setPromoInput('');
    }
  };

  return (
    <div className="fixed inset-0 z-50 overflow-hidden">
      {/* Backdrop */}
      <div 
        className="absolute inset-0 bg-stone-900/60 backdrop-blur-xs transition-opacity"
        onClick={closeCart}
      />

      <div className="fixed inset-y-0 right-0 max-w-full flex pl-10">
        <div 
          className="w-screen max-w-md bg-white shadow-2xl flex flex-col border-l border-stone-200"
          role="dialog"
          aria-modal="true"
          aria-labelledby="cart-drawer-title"
        >
          {/* Header */}
          <div className="p-5 border-b border-stone-200 flex items-center justify-between bg-stone-50">
            <div className="flex items-center gap-2">
              <ShoppingBag className="w-5 h-5 text-[#133c46]" />
              <h2 id="cart-drawer-title" className="font-serif text-xl font-bold text-stone-900">
                Your Shopping Bag ({cart.reduce((s, i) => s + i.quantity, 0)})
              </h2>
            </div>
            <button
              onClick={closeCart}
              className="p-1.5 text-stone-400 hover:text-stone-700 rounded-lg hover:bg-stone-200 transition-colors"
              aria-label="Close cart drawer"
            >
              <X className="w-5 h-5" />
            </button>
          </div>

          {/* Free Shipping Progress Indicator */}
          <div className="bg-[#f0f8f7] p-3 px-5 border-b border-[#c8e6e2]">
            <div className="flex items-center justify-between text-xs font-semibold text-[#133c46] mb-1.5">
              {amountToFreeShipping > 0 ? (
                <span>Add ₹{amountToFreeShipping.toFixed(0)} more for <strong>Free Courier Delivery across India</strong></span>
              ) : (
                <span className="flex items-center gap-1.5 text-emerald-800">
                  <Check className="w-4 h-4 text-emerald-600" />
                  <span>Unlocked! You qualify for Free Courier Delivery across India</span>
                </span>
              )}
              <span className="tabular-nums">{freeShippingProgress}%</span>
            </div>
            <div className="w-full bg-[#d0eee9] h-1.5 rounded-full overflow-hidden">
              <div 
                className="bg-[#133c46] h-full rounded-full transition-all duration-300"
                style={{ width: `${freeShippingProgress}%` }}
              />
            </div>
          </div>

          {/* Cart Items List */}
          <div className="flex-1 overflow-y-auto p-5 space-y-4">
            {cart.length === 0 ? (
              <div className="h-full flex flex-col items-center justify-center text-center p-6 space-y-4">
                <div className="w-16 h-16 rounded-full bg-stone-100 flex items-center justify-center text-stone-400">
                  <ShoppingBag className="w-8 h-8" />
                </div>
                <h3 className="font-serif text-lg font-bold text-stone-800">Your bag is empty</h3>
                <p className="text-xs text-stone-500 max-w-xs">
                  Experience wild Atlantic texture and weightless matte hold. Add any of our handcrafted sea salt sprays to get started.
                </p>
                <button
                  onClick={closeCart}
                  className="px-5 py-2.5 text-xs font-semibold text-white bg-[#133c46] hover:bg-[#0e2a30] rounded-xl transition-all shadow-sm"
                >
                  Explore Formulas
                </button>
              </div>
            ) : (
              cart.map((item) => (
                <div 
                  key={item.id} 
                  className="flex gap-4 p-3 bg-stone-50/70 rounded-xl border border-stone-200/80 items-center justify-between"
                >
                  <img
                    src={item.product.image}
                    alt={item.product.name}
                    className="w-16 h-16 rounded-lg object-cover bg-stone-200 shrink-0 border border-stone-200"
                    referrerPolicy="no-referrer"
                  />
                  <div className="flex-1 min-w-0">
                    <h4 className="text-xs font-bold text-stone-900 truncate">{item.product.name}</h4>
                    <p className="text-[11px] text-stone-500">{item.selectedVariant.size}</p>
                    <div className="font-serif text-sm font-bold text-stone-900 mt-1 tabular-nums">
                      ₹{item.selectedVariant.price}
                    </div>
                  </div>

                  <div className="flex flex-col items-end gap-2 shrink-0">
                    <button
                      onClick={() => removeFromCart(item.id)}
                      className="text-stone-400 hover:text-rose-600 transition-colors p-1"
                      aria-label="Remove item"
                    >
                      <Trash2 className="w-3.5 h-3.5" />
                    </button>

                    <div className="flex items-center border border-stone-300 rounded-lg bg-white px-1.5 py-0.5">
                      <button
                        onClick={() => updateQuantity(item.id, item.quantity - 1)}
                        className="p-1 text-stone-500 hover:text-stone-900"
                        aria-label="Decrease quantity"
                      >
                        <Minus className="w-3 h-3" />
                      </button>
                      <span className="px-2 text-xs font-bold text-stone-900 tabular-nums">
                        {item.quantity}
                      </span>
                      <button
                        onClick={() => updateQuantity(item.id, item.quantity + 1)}
                        className="p-1 text-stone-500 hover:text-stone-900"
                        aria-label="Increase quantity"
                      >
                        <Plus className="w-3 h-3" />
                      </button>
                    </div>
                  </div>
                </div>
              ))
            )}
          </div>

          {/* Cart Footer & Quick Checkout */}
          {cart.length > 0 && (
            <div className="p-5 border-t border-stone-200 bg-stone-50 space-y-4">
              
              {/* Promo / Loyalty Code Input */}
              <div>
                <form onSubmit={handleApplyPromo} className="flex gap-2">
                  <div className="relative flex-1">
                    <Tag className="w-3.5 h-3.5 text-stone-400 absolute left-3 top-1/2 -translate-y-1/2" />
                    <input
                      type="text"
                      placeholder="Code (e.g. COASTAL15)"
                      value={promoInput}
                      onChange={(e) => setPromoInput(e.target.value)}
                      className="w-full pl-8 pr-3 py-1.5 text-xs bg-white border border-stone-300 rounded-lg uppercase focus:outline-none focus:ring-1 focus:ring-[#133c46]"
                    />
                  </div>
                  <button
                    type="submit"
                    className="px-3 py-1.5 text-xs font-semibold text-stone-700 bg-stone-200 hover:bg-stone-300 rounded-lg transition-colors"
                  >
                    Apply
                  </button>
                </form>

                {promoMessage && (
                  <p className={`text-[11px] mt-1.5 ${promoMessage.success ? 'text-emerald-700' : 'text-amber-700'}`}>
                    {promoMessage.text}
                  </p>
                )}

                {discountCode && (
                  <div className="mt-2 flex items-center justify-between text-xs bg-emerald-50 text-emerald-900 px-2.5 py-1 rounded-md border border-emerald-200">
                    <span>Applied: <strong>{discountCode}</strong> (-₹{discountAmount})</span>
                    <button 
                      onClick={removePromoCode}
                      className="text-stone-500 hover:text-stone-800 text-[10px] underline ml-2"
                    >
                      Remove
                    </button>
                  </div>
                )}
              </div>

              {/* Loyalty Points Reminder */}
              <div 
                onClick={() => {
                  closeCart();
                  openLoyaltyModal();
                }}
                className="p-2.5 bg-[#eef7f6] rounded-xl border border-[#c4e7e3] flex items-center justify-between cursor-pointer hover:bg-[#e2f3f1] transition-colors"
              >
                <div className="flex items-center gap-2">
                  <Award className="w-4 h-4 text-[#133c46]" />
                  <span className="text-xs text-[#133c46] font-medium">
                    You'll earn <strong className="tabular-nums">{pointsToEarn}</strong> loyalty points!
                  </span>
                </div>
                <span className="text-[11px] font-bold text-[#133c46] underline">
                  Use {customer.pointsBalance} pts
                </span>
              </div>

              {/* Cost Summary */}
              <div className="space-y-1.5 text-xs text-stone-600 pt-1">
                <div className="flex justify-between">
                  <span>Subtotal</span>
                  <span className="tabular-nums font-semibold text-stone-900">₹{cartSubtotal}</span>
                </div>
                {discountAmount > 0 && (
                  <div className="flex justify-between text-emerald-700 font-medium">
                    <span>Savings ({discountCode})</span>
                    <span className="tabular-nums">-₹{discountAmount}</span>
                  </div>
                )}
                <div className="flex justify-between">
                  <span>Courier Delivery (Merchant Pickup &rarr; Dropoff)</span>
                  <span className="tabular-nums font-semibold text-stone-900">
                    {cartSubtotal >= freeShippingThreshold ? 'FREE' : '₹99'}
                  </span>
                </div>
                <div className="flex justify-between pt-2 border-t border-stone-200 text-sm font-bold text-stone-900">
                  <span>Estimated Total</span>
                  <span className="font-serif text-lg tabular-nums">
                    ₹{(cartTotal + (cartSubtotal >= freeShippingThreshold ? 0 : 99))}
                  </span>
                </div>
              </div>

              {/* Checkout Button */}
              <button
                onClick={openCheckout}
                className="w-full py-3.5 px-4 text-sm font-bold text-white bg-[#133c46] hover:bg-[#0e2a30] rounded-xl transition-all shadow-md flex items-center justify-center gap-2 hover:translate-y-[-1px]"
              >
                <ShieldCheck className="w-4 h-4" />
                <span>Proceed to Encrypted Checkout</span>
                <ArrowRight className="w-4 h-4" />
              </button>

              {/* Security Seal */}
              <div className="flex items-center justify-center gap-3 text-[11px] text-stone-500 pt-1">
                <div className="flex items-center gap-1">
                  <ShieldCheck className="w-3.5 h-3.5 text-emerald-600" />
                  <span>256-Bit SSL Encrypted</span>
                </div>
                <span>·</span>
                <div className="flex items-center gap-1">
                  <Truck className="w-3.5 h-3.5 text-stone-600" />
                  <span>Doorstep Courier Dropoff</span>
                </div>
              </div>

            </div>
          )}

        </div>
      </div>
    </div>
  );
};
