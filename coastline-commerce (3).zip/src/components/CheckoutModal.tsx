import React, { useState } from 'react';
import { 
  X, 
  ShieldCheck, 
  Lock, 
  CreditCard, 
  Truck, 
  CheckCircle2, 
  Award, 
  ArrowRight, 
  Smartphone, 
  Banknote,
  AlertCircle,
  QrCode
} from 'lucide-react';
import { useStore } from '../context/StoreContext';
import { CourierPickupDetails } from '../types';

export const CheckoutModal: React.FC = () => {
  const { 
    isCheckoutOpen, 
    closeCheckout, 
    cart, 
    cartSubtotal, 
    discountAmount, 
    discountCode, 
    cartTotal, 
    pointsToEarn, 
    customer, 
    placeOrder 
  } = useStore();

  const [step, setStep] = useState<1 | 2 | 3>(1);

  // Form Fields tailored for India
  const [formData, setFormData] = useState({
    name: customer.name || 'Ananya Deshmukh',
    email: customer.email || 'ananya.deshmukh@coastalwaves.in',
    phone: customer.phone || '+91 98201 44521',
    address: customer.address || '42 Carter Road, Bandra West',
    city: customer.city || 'Mumbai',
    state: customer.state || 'Maharashtra',
    postalCode: customer.postalCode || '400050',
    country: 'India',
    pickupNotes: 'Leave with society security desk if not home. Recycled packaging.'
  });

  // Indian Courier selection
  const [selectedCarrier, setSelectedCarrier] = useState<CourierPickupDetails['carrier']>('BlueDart Ocean Express');

  // Indian Payment Methods (UPI first!)
  const [paymentMethod, setPaymentMethod] = useState<'upi' | 'card' | 'cod'>('upi');
  const [upiId, setUpiId] = useState('ananya@okhdfcbank');
  const [upiApp, setUpiApp] = useState<'gpay' | 'phonepe' | 'paytm' | 'id'>('gpay');

  const [cardDetails, setCardDetails] = useState({
    number: '4242 •••• •••• 4242',
    expiry: '12/28',
    cvv: '891',
    holder: customer.name || 'Ananya Deshmukh'
  });

  const [isProcessing, setIsProcessing] = useState(false);
  const [errorMsg, setErrorMsg] = useState('');

  if (!isCheckoutOpen) return null;

  const shippingFee = cartSubtotal >= 999 ? 0 : 99;
  const gstAmount = Math.round(cartTotal * 0.18); // 18% GST in India
  const finalTotal = cartTotal + shippingFee + gstAmount;

  const handleInputChange = (field: string, value: string) => {
    setFormData(prev => ({ ...prev, [field]: value }));
  };

  const handleCompleteOrder = async () => {
    if (!formData.name || !formData.email || !formData.address || !formData.postalCode) {
      setErrorMsg('Please complete all contact and PIN code details.');
      setStep(1);
      return;
    }

    setIsProcessing(true);
    setErrorMsg('');

    try {
      // Simulate real-time cryptographic tokenization & carrier pickup dispatch
      await new Promise(r => setTimeout(r, 1300));

      await placeOrder({
        customer: {
          name: formData.name,
          email: formData.email,
          phone: formData.phone,
          address: formData.address,
          city: formData.city,
          state: formData.state,
          postalCode: formData.postalCode,
          country: 'India'
        },
        paymentMethod,
        cardDetails: paymentMethod === 'card' ? cardDetails : undefined,
        upiId: paymentMethod === 'upi' ? upiId : undefined,
        carrier: selectedCarrier,
        pickupNotes: formData.pickupNotes
      });
    } catch (err: any) {
      setErrorMsg(err?.message || 'Transaction could not be completed. Please try again.');
    } finally {
      setIsProcessing(false);
    }
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-3 sm:p-6 bg-stone-950/75 backdrop-blur-md overflow-y-auto">
      <div 
        className="bg-white rounded-2xl shadow-2xl max-w-4xl w-full max-h-[94vh] flex flex-col overflow-hidden border border-stone-200"
        role="dialog"
        aria-modal="true"
        aria-labelledby="checkout-modal-title"
      >
        {/* Checkout Header with Security Seals */}
        <div className="bg-[#0f282f] text-white p-5 sm:p-6 flex items-center justify-between border-b border-[#1c4752]">
          <div className="flex items-center gap-3">
            <div className="w-9 h-9 rounded-xl bg-white/10 flex items-center justify-center text-[#8ce0d7]">
              <Lock className="w-5 h-5" />
            </div>
            <div>
              <div className="flex items-center gap-2">
                <h2 id="checkout-modal-title" className="font-serif text-xl sm:text-2xl font-bold">
                  Ukusha Sprays Encrypted Checkout
                </h2>
                <span className="hidden sm:inline-block text-[10px] font-mono uppercase bg-emerald-950 text-emerald-300 border border-emerald-700/60 px-2 py-0.5 rounded">
                  UPI &amp; AES-256 Active
                </span>
              </div>
              <p className="text-xs text-stone-300">
                NPCI &amp; RBI Compliant Encrypted Gateway · Pan-India Warehouse Courier Pickup
              </p>
            </div>
          </div>

          <button
            onClick={closeCheckout}
            className="p-1.5 text-stone-300 hover:text-white rounded-lg hover:bg-white/10 transition-colors"
            aria-label="Close checkout"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Step Progression Bar */}
        <div className="bg-stone-50 border-b border-stone-200 px-6 py-3 flex items-center justify-between text-xs font-semibold">
          <button 
            onClick={() => setStep(1)}
            className={`flex items-center gap-1.5 transition-colors ${
              step >= 1 ? 'text-[#133c46] font-bold' : 'text-stone-400'
            }`}
          >
            <span className={`w-5 h-5 rounded-full flex items-center justify-center text-[10px] ${
              step >= 1 ? 'bg-[#133c46] text-white' : 'bg-stone-200 text-stone-600'
            }`}>
              1
            </span>
            <span>1. Delivery Destination</span>
          </button>

          <span className="text-stone-300">&rarr;</span>

          <button 
            onClick={() => setStep(2)}
            className={`flex items-center gap-1.5 transition-colors ${
              step >= 2 ? 'text-[#133c46] font-bold' : 'text-stone-400'
            }`}
          >
            <span className={`w-5 h-5 rounded-full flex items-center justify-center text-[10px] ${
              step >= 2 ? 'bg-[#133c46] text-white' : 'bg-stone-200 text-stone-600'
            }`}>
              2
            </span>
            <span>2. Courier Partner</span>
          </button>

          <span className="text-stone-300">&rarr;</span>

          <button 
            onClick={() => setStep(3)}
            className={`flex items-center gap-1.5 transition-colors ${
              step === 3 ? 'text-[#133c46] font-bold' : 'text-stone-400'
            }`}
          >
            <span className={`w-5 h-5 rounded-full flex items-center justify-center text-[10px] ${
              step === 3 ? 'bg-[#133c46] text-white' : 'bg-stone-200 text-stone-600'
            }`}>
              3
            </span>
            <span>3. UPI / Card / COD</span>
          </button>
        </div>

        {/* Error alert */}
        {errorMsg && (
          <div className="mx-6 mt-4 p-3 bg-rose-50 border border-rose-200 text-rose-800 rounded-xl text-xs flex items-center gap-2">
            <AlertCircle className="w-4 h-4 text-rose-600 shrink-0" />
            <span>{errorMsg}</span>
          </div>
        )}

        {/* Form & Summary */}
        <div className="flex-1 overflow-y-auto grid grid-cols-1 lg:grid-cols-12 divide-y lg:divide-y-0 lg:divide-x divide-stone-200">
          
          {/* Left: Step Form */}
          <div className="lg:col-span-7 p-6 sm:p-8 space-y-6">
            
            {/* Step 1: Customer & Delivery Address */}
            {step === 1 && (
              <div className="space-y-4 animate-fade-in">
                <div className="border-b border-stone-100 pb-3">
                  <h3 className="font-serif text-lg font-bold text-stone-900">
                    Indian Delivery Address
                  </h3>
                  <p className="text-xs text-stone-500">
                    Enter your doorstep address anywhere across India for priority courier drop-off.
                  </p>
                </div>

                <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                  <div className="sm:col-span-2">
                    <label className="block text-xs font-semibold text-stone-700 mb-1">Full Name</label>
                    <input
                      type="text"
                      value={formData.name}
                      onChange={(e) => handleInputChange('name', e.target.value)}
                      placeholder="e.g. Ananya Deshmukh"
                      className="w-full px-3 py-2 text-xs bg-white border border-stone-300 rounded-xl focus:ring-1 focus:ring-[#133c46]"
                    />
                  </div>

                  <div>
                    <label className="block text-xs font-semibold text-stone-700 mb-1">Email (For Invoice &amp; Points)</label>
                    <input
                      type="email"
                      value={formData.email}
                      onChange={(e) => handleInputChange('email', e.target.value)}
                      placeholder="ananya@example.com"
                      className="w-full px-3 py-2 text-xs bg-white border border-stone-300 rounded-xl focus:ring-1 focus:ring-[#133c46]"
                    />
                  </div>

                  <div>
                    <label className="block text-xs font-semibold text-stone-700 mb-1">Mobile Phone (+91 for OTP / Courier SMS)</label>
                    <input
                      type="tel"
                      value={formData.phone}
                      onChange={(e) => handleInputChange('phone', e.target.value)}
                      placeholder="+91 98201 44521"
                      className="w-full px-3 py-2 text-xs bg-white border border-stone-300 rounded-xl focus:ring-1 focus:ring-[#133c46]"
                    />
                  </div>

                  <div className="sm:col-span-2">
                    <label className="block text-xs font-semibold text-stone-700 mb-1">Flat, House no., Building, Street</label>
                    <input
                      type="text"
                      value={formData.address}
                      onChange={(e) => handleInputChange('address', e.target.value)}
                      placeholder="42 Carter Road, Bandra West"
                      className="w-full px-3 py-2 text-xs bg-white border border-stone-300 rounded-xl focus:ring-1 focus:ring-[#133c46]"
                    />
                  </div>

                  <div>
                    <label className="block text-xs font-semibold text-stone-700 mb-1">City / District</label>
                    <input
                      type="text"
                      value={formData.city}
                      onChange={(e) => handleInputChange('city', e.target.value)}
                      placeholder="Mumbai"
                      className="w-full px-3 py-2 text-xs bg-white border border-stone-300 rounded-xl focus:ring-1 focus:ring-[#133c46]"
                    />
                  </div>

                  <div className="grid grid-cols-2 gap-2">
                    <div>
                      <label className="block text-xs font-semibold text-stone-700 mb-1">State</label>
                      <input
                        type="text"
                        value={formData.state}
                        onChange={(e) => handleInputChange('state', e.target.value)}
                        placeholder="Maharashtra"
                        className="w-full px-3 py-2 text-xs bg-white border border-stone-300 rounded-xl focus:ring-1 focus:ring-[#133c46]"
                      />
                    </div>
                    <div>
                      <label className="block text-xs font-semibold text-stone-700 mb-1">6-Digit PIN Code</label>
                      <input
                        type="text"
                        maxLength={6}
                        value={formData.postalCode}
                        onChange={(e) => handleInputChange('postalCode', e.target.value)}
                        placeholder="400050"
                        className="w-full px-3 py-2 text-xs font-mono bg-white border border-stone-300 rounded-xl focus:ring-1 focus:ring-[#133c46]"
                      />
                    </div>
                  </div>
                </div>

                <div className="pt-4 flex justify-end">
                  <button
                    onClick={() => {
                      if (!formData.name || !formData.address || !formData.postalCode) {
                        setErrorMsg('Please enter your full name, delivery address, and PIN code.');
                        return;
                      }
                      setErrorMsg('');
                      setStep(2);
                    }}
                    className="px-5 py-2.5 text-xs font-bold text-white bg-[#133c46] hover:bg-[#0e2a30] rounded-xl flex items-center gap-2 shadow-sm"
                  >
                    <span>Proceed to Indian Courier Delivery</span>
                    <ArrowRight className="w-3.5 h-3.5" />
                  </button>
                </div>
              </div>
            )}

            {/* Step 2: Indian Courier Pickup Logistics */}
            {step === 2 && (
              <div className="space-y-4 animate-fade-in">
                <div className="border-b border-stone-100 pb-3">
                  <h3 className="font-serif text-lg font-bold text-stone-900">
                    Automated Merchant Pickup &amp; Doorstep Delivery
                  </h3>
                  <p className="text-xs text-stone-500">
                    How it works: Once your purchase is confirmed, our automated system schedules an immediate courier pickup directly from Ukusha's Mumbai warehouse and drops off at your doorstep.
                  </p>
                </div>

                {/* Logistics Flow Explanation Box */}
                <div className="p-3.5 bg-[#f0f8f7] rounded-xl border border-[#c4e6e2] space-y-2">
                  <div className="flex items-center gap-2 text-xs font-bold text-[#133c46]">
                    <Truck className="w-4 h-4 text-[#133c46]" />
                    <span>Direct Merchant-to-Customer Dispatch Protocol (India)</span>
                  </div>
                  <div className="grid grid-cols-3 gap-2 text-center text-[11px] text-stone-600 pt-1">
                    <div className="p-2 bg-white rounded-lg border border-stone-200">
                      <div className="font-bold text-stone-900">1. Instant Pickup</div>
                      <div className="text-[10px] text-stone-500">Carrier dispatched to Mumbai Hub</div>
                    </div>
                    <div className="p-2 bg-white rounded-lg border border-stone-200">
                      <div className="font-bold text-stone-900">2. Secure Air Transit</div>
                      <div className="text-[10px] text-stone-500">Live barcode AWB scan</div>
                    </div>
                    <div className="p-2 bg-white rounded-lg border border-stone-200">
                      <div className="font-bold text-stone-900">3. Doorstep Drop</div>
                      <div className="text-[10px] text-stone-500">OTP / Contactless handover</div>
                    </div>
                  </div>
                </div>

                {/* Indian Carrier Options */}
                <div className="space-y-2.5">
                  <label className="block text-xs font-semibold text-stone-800">Select Courier Service</label>
                  
                  {[
                    {
                      name: 'BlueDart Ocean Express',
                      badge: 'Fastest Metro Air Dispatch',
                      est: '24-48 hours',
                      note: 'Direct daily courier pickup from Ukusha Mumbai Hub at 4:30 PM'
                    },
                    {
                      name: 'Delhivery Coastal Priority',
                      badge: 'Pan-India Reach',
                      est: '2-3 business days',
                      note: 'Extensive pin-code network with fragile glassware handling'
                    },
                    {
                      name: 'DTDC Green Express',
                      badge: 'Reliable Regional Fleet',
                      est: '3-4 business days',
                      note: 'Signature verification drop-off with SMS tracking'
                    }
                  ].map((carrier) => (
                    <div
                      key={carrier.name}
                      onClick={() => setSelectedCarrier(carrier.name as any)}
                      className={`p-3.5 rounded-xl border cursor-pointer transition-all ${
                        selectedCarrier === carrier.name
                          ? 'border-[#133c46] bg-[#f0f8f7] ring-1 ring-[#133c46]'
                          : 'border-stone-200 hover:border-stone-300 bg-white'
                      }`}
                    >
                      <div className="flex items-center justify-between">
                        <div className="flex items-center gap-2">
                          <input
                            type="radio"
                            name="courierOption"
                            checked={selectedCarrier === carrier.name}
                            onChange={() => setSelectedCarrier(carrier.name as any)}
                            className="text-[#133c46] focus:ring-[#133c46]"
                          />
                          <span className="text-xs font-bold text-stone-900">{carrier.name}</span>
                          <span className="text-[10px] text-[#133c46] font-medium bg-[#e6f4f2] px-1.5 py-0.5 rounded">
                            {carrier.badge}
                          </span>
                        </div>
                        <span className="text-xs font-semibold text-stone-700">
                          {cartSubtotal >= 999 ? 'FREE' : '₹99'}
                        </span>
                      </div>
                      <p className="text-[11px] text-stone-500 mt-1 pl-5">
                        {carrier.note} · Est. arrival: <strong>{carrier.est}</strong>
                      </p>
                    </div>
                  ))}
                </div>

                <div>
                  <label className="block text-xs font-semibold text-stone-700 mb-1">
                    Courier Delivery Instructions / Landmark
                  </label>
                  <input
                    type="text"
                    value={formData.pickupNotes}
                    onChange={(e) => handleInputChange('pickupNotes', e.target.value)}
                    placeholder="e.g. Near Bandstand Promenade, call before delivery"
                    className="w-full px-3 py-2 text-xs bg-white border border-stone-300 rounded-xl"
                  />
                </div>

                <div className="pt-4 flex items-center justify-between">
                  <button
                    onClick={() => setStep(1)}
                    className="text-xs font-semibold text-stone-600 hover:text-stone-900"
                  >
                    &larr; Back to Address
                  </button>

                  <button
                    onClick={() => setStep(3)}
                    className="px-5 py-2.5 text-xs font-bold text-white bg-[#133c46] hover:bg-[#0e2a30] rounded-xl flex items-center gap-2 shadow-sm"
                  >
                    <span>Proceed to UPI / Card Payment</span>
                    <ArrowRight className="w-3.5 h-3.5" />
                  </button>
                </div>
              </div>
            )}

            {/* Step 3: Encrypted Payment (UPI, Cards, COD) */}
            {step === 3 && (
              <div className="space-y-4 animate-fade-in">
                <div className="border-b border-stone-100 pb-3 flex items-center justify-between">
                  <div>
                    <h3 className="font-serif text-lg font-bold text-stone-900">
                      Encrypted Payment Gateway (India)
                    </h3>
                    <p className="text-xs text-stone-500">
                      Zero credentials stored. Tokenized with AES-256 GCM client encryption &amp; NPCI protocols.
                    </p>
                  </div>
                  <div className="flex items-center gap-1 text-[11px] font-bold text-emerald-800 bg-emerald-50 px-2 py-1 rounded border border-emerald-200">
                    <ShieldCheck className="w-3.5 h-3.5 text-emerald-600" />
                    <span>RBI &amp; PCI Safe</span>
                  </div>
                </div>

                {/* Payment Methods Tabs */}
                <div className="grid grid-cols-3 gap-2">
                  <button
                    onClick={() => setPaymentMethod('upi')}
                    className={`p-3 rounded-xl border flex flex-col items-center justify-center gap-1 transition-all ${
                      paymentMethod === 'upi'
                        ? 'border-[#133c46] bg-[#f0f8f7] font-bold text-[#133c46] ring-1 ring-[#133c46]'
                        : 'border-stone-200 text-stone-600 hover:border-stone-300 bg-white'
                    }`}
                  >
                    <Smartphone className="w-4 h-4 text-emerald-600" />
                    <span className="text-[11px]">UPI (GPay/PhonePe)</span>
                  </button>

                  <button
                    onClick={() => setPaymentMethod('card')}
                    className={`p-3 rounded-xl border flex flex-col items-center justify-center gap-1 transition-all ${
                      paymentMethod === 'card'
                        ? 'border-[#133c46] bg-[#f0f8f7] font-bold text-[#133c46] ring-1 ring-[#133c46]'
                        : 'border-stone-200 text-stone-600 hover:border-stone-300 bg-white'
                    }`}
                  >
                    <CreditCard className="w-4 h-4" />
                    <span className="text-[11px]">RuPay / Cards</span>
                  </button>

                  <button
                    onClick={() => setPaymentMethod('cod')}
                    className={`p-3 rounded-xl border flex flex-col items-center justify-center gap-1 transition-all ${
                      paymentMethod === 'cod'
                        ? 'border-[#133c46] bg-[#f0f8f7] font-bold text-[#133c46] ring-1 ring-[#133c46]'
                        : 'border-stone-200 text-stone-600 hover:border-stone-300 bg-white'
                    }`}
                  >
                    <Banknote className="w-4 h-4" />
                    <span className="text-[11px]">Cash on Delivery</span>
                  </button>
                </div>

                {/* UPI Interface */}
                {paymentMethod === 'upi' && (
                  <div className="p-4 bg-stone-50 rounded-xl border border-stone-200 space-y-3">
                    <div className="text-xs font-bold text-stone-900">Select Instant UPI App:</div>
                    <div className="grid grid-cols-3 gap-2">
                      {[
                        { id: 'gpay', name: 'Google Pay' },
                        { id: 'phonepe', name: 'PhonePe' },
                        { id: 'paytm', name: 'Paytm UPI' }
                      ].map((app) => (
                        <button
                          key={app.id}
                          type="button"
                          onClick={() => setUpiApp(app.id as any)}
                          className={`p-2 rounded-lg border text-xs font-semibold transition-all ${
                            upiApp === app.id
                              ? 'bg-[#133c46] text-white border-[#133c46]'
                              : 'bg-white border-stone-200 text-stone-700 hover:border-stone-300'
                          }`}
                        >
                          {app.name}
                        </button>
                      ))}
                    </div>

                    <div>
                      <label className="block text-xs font-semibold text-stone-700 mb-1">
                        Or Enter UPI VPA ID
                      </label>
                      <input
                        type="text"
                        value={upiId}
                        onChange={(e) => setUpiId(e.target.value)}
                        placeholder="yourname@okhdfcbank or yourname@ybl"
                        className="w-full px-3 py-2 text-xs font-mono bg-white border border-stone-300 rounded-lg"
                      />
                    </div>

                    <div className="p-3 bg-emerald-50 text-emerald-900 rounded-lg border border-emerald-200 text-[11px] flex items-center gap-2">
                      <QrCode className="w-4 h-4 text-emerald-600 shrink-0" />
                      <span>Instant 1-Click NPCI payment request will be sent to your UPI app upon authorization.</span>
                    </div>
                  </div>
                )}

                {/* Card Fields */}
                {paymentMethod === 'card' && (
                  <div className="p-4 bg-stone-50 rounded-xl border border-stone-200 space-y-3">
                    <div>
                      <label className="block text-xs font-semibold text-stone-700 mb-1">Cardholder Name</label>
                      <input
                        type="text"
                        value={cardDetails.holder}
                        onChange={(e) => setCardDetails(prev => ({ ...prev, holder: e.target.value }))}
                        className="w-full px-3 py-2 text-xs bg-white border border-stone-300 rounded-lg"
                      />
                    </div>

                    <div>
                      <label className="block text-xs font-semibold text-stone-700 mb-1">Encrypted Card Number</label>
                      <div className="relative">
                        <input
                          type="text"
                          value={cardDetails.number}
                          onChange={(e) => setCardDetails(prev => ({ ...prev, number: e.target.value }))}
                          placeholder="4242 4242 4242 4242"
                          className="w-full px-3 py-2 text-xs font-mono bg-white border border-stone-300 rounded-lg pr-20"
                        />
                        <span className="absolute right-3 top-1/2 -translate-y-1/2 text-[10px] font-bold uppercase text-stone-500">
                          RuPay / Visa
                        </span>
                      </div>
                    </div>

                    <div className="grid grid-cols-2 gap-3">
                      <div>
                        <label className="block text-xs font-semibold text-stone-700 mb-1">Expiry Date</label>
                        <input
                          type="text"
                          value={cardDetails.expiry}
                          onChange={(e) => setCardDetails(prev => ({ ...prev, expiry: e.target.value }))}
                          placeholder="MM/YY"
                          className="w-full px-3 py-2 text-xs font-mono bg-white border border-stone-300 rounded-lg"
                        />
                      </div>
                      <div>
                        <label className="block text-xs font-semibold text-stone-700 mb-1">CVV (Encrypted)</label>
                        <input
                          type="password"
                          maxLength={4}
                          value={cardDetails.cvv}
                          onChange={(e) => setCardDetails(prev => ({ ...prev, cvv: e.target.value }))}
                          placeholder="•••"
                          className="w-full px-3 py-2 text-xs font-mono bg-white border border-stone-300 rounded-lg"
                        />
                      </div>
                    </div>

                    <div className="pt-1 flex items-center justify-between text-[11px] text-stone-500">
                      <span className="flex items-center gap-1 text-emerald-800">
                        <Lock className="w-3 h-3 text-emerald-600" />
                        2-Factor OTP Authentication Supported
                      </span>
                      <span className="font-mono text-[10px]">TLS 1.3 / AES-256</span>
                    </div>
                  </div>
                )}

                {paymentMethod === 'cod' && (
                  <div className="p-4 bg-amber-50 border border-amber-200 rounded-xl text-amber-900 space-y-2">
                    <div className="text-xs font-bold flex items-center gap-1.5">
                      <Banknote className="w-4 h-4 text-amber-700" />
                      <span>Cash on Courier Delivery across India</span>
                    </div>
                    <p className="text-xs text-amber-800">
                      Exact total of ₹{finalTotal} payable to the courier driver (Cash or UPI on delivery) upon doorstep dropoff. Verification OTP will be sent to {formData.phone || '+91'}.
                    </p>
                  </div>
                )}

                <div className="pt-4 flex items-center justify-between">
                  <button
                    onClick={() => setStep(2)}
                    className="text-xs font-semibold text-stone-600 hover:text-stone-900"
                  >
                    &larr; Back to Courier
                  </button>

                  <button
                    onClick={handleCompleteOrder}
                    disabled={isProcessing}
                    className="px-6 py-3 text-sm font-bold text-white bg-[#133c46] hover:bg-[#0e2a30] rounded-xl flex items-center gap-2 shadow-md transition-all hover:translate-y-[-1px] disabled:opacity-50"
                  >
                    {isProcessing ? (
                      <span className="flex items-center gap-2">
                        <div className="w-4 h-4 border-2 border-white border-t-transparent rounded-full animate-spin" />
                        <span>Tokenizing UPI &amp; Scheduling BlueDart...</span>
                      </span>
                    ) : (
                      <>
                        <ShieldCheck className="w-4 h-4" />
                        <span>Pay ₹{finalTotal} &amp; Dispatch Order</span>
                      </>
                    )}
                  </button>
                </div>
              </div>
            )}

          </div>

          {/* Right: Order Summary with Loyalty Points & Courier Badge */}
          <div className="lg:col-span-5 p-6 sm:p-8 bg-stone-50 space-y-5">
            <h3 className="font-serif text-lg font-bold text-stone-900 border-b border-stone-200 pb-3">
              Order Summary ({cart.length} items)
            </h3>

            {/* Items */}
            <div className="space-y-3 max-h-56 overflow-y-auto pr-1">
              {cart.map((item) => (
                <div key={item.id} className="flex items-center justify-between gap-3 text-xs">
                  <div className="flex items-center gap-2.5 min-w-0">
                    <img
                      src={item.product.image}
                      alt={item.product.name}
                      className="w-10 h-10 rounded-lg object-cover bg-stone-200 border border-stone-200 shrink-0"
                      referrerPolicy="no-referrer"
                    />
                    <div className="truncate">
                      <div className="font-bold text-stone-900 truncate">{item.product.name}</div>
                      <div className="text-stone-500 text-[11px]">{item.selectedVariant.size} × {item.quantity}</div>
                    </div>
                  </div>
                  <div className="font-serif font-bold text-stone-900 tabular-nums shrink-0">
                    ₹{item.selectedVariant.price * item.quantity}
                  </div>
                </div>
              ))}
            </div>

            {/* Loyalty points to earn */}
            <div className="p-3 bg-[#eef7f6] rounded-xl border border-[#c2e5e1] flex items-center justify-between text-xs text-[#133c46]">
              <div className="flex items-center gap-2">
                <Award className="w-4 h-4" />
                <span className="font-medium">Ukusha Loyalty Reward:</span>
              </div>
              <span className="font-bold tabular-nums">+{pointsToEarn} points</span>
            </div>

            {/* Selected Courier Badge */}
            <div className="p-3 bg-white rounded-xl border border-stone-200 text-xs space-y-1">
              <div className="flex items-center justify-between font-semibold text-stone-800">
                <span className="flex items-center gap-1.5">
                  <Truck className="w-3.5 h-3.5 text-[#133c46]" />
                  <span>Indian Courier Partner:</span>
                </span>
                <span className="text-[#133c46] font-bold">{selectedCarrier}</span>
              </div>
              <div className="text-[11px] text-stone-500">
                Dispatched from Mumbai Hub &rarr; Doorstep delivery to {formData.city || 'your address'}
              </div>
            </div>

            {/* Financial Breakdown */}
            <div className="space-y-1.5 text-xs text-stone-600 border-t border-stone-200 pt-3">
              <div className="flex justify-between">
                <span>Subtotal</span>
                <span className="tabular-nums font-medium text-stone-900">₹{cartSubtotal}</span>
              </div>
              {discountAmount > 0 && (
                <div className="flex justify-between text-emerald-800 font-medium">
                  <span>Voucher ({discountCode})</span>
                  <span className="tabular-nums">-₹{discountAmount}</span>
                </div>
              )}
              <div className="flex justify-between">
                <span>Courier Shipping (Pan-India)</span>
                <span className="tabular-nums font-medium text-stone-900">
                  {shippingFee === 0 ? 'FREE' : `₹${shippingFee}`}
                </span>
              </div>
              <div className="flex justify-between">
                <span>GST (18% CGST + SGST)</span>
                <span className="tabular-nums font-medium text-stone-900">₹{gstAmount}</span>
              </div>

              <div className="flex justify-between pt-2 border-t border-stone-300 text-base font-bold text-stone-900">
                <span>Total Payable</span>
                <span className="font-serif text-xl text-[#133c46] tabular-nums">
                  ₹{finalTotal}
                </span>
              </div>
            </div>

            {/* Security checklist */}
            <div className="pt-2 text-[11px] text-stone-500 space-y-1">
              <div className="flex items-center gap-1.5">
                <CheckCircle2 className="w-3.5 h-3.5 text-emerald-600 shrink-0" />
                <span>UPI Autopay &amp; 256-Bit Tokenized Encryption</span>
              </div>
              <div className="flex items-center gap-1.5">
                <CheckCircle2 className="w-3.5 h-3.5 text-emerald-600 shrink-0" />
                <span>Automated courier pickup scheduled immediately</span>
              </div>
              <div className="flex items-center gap-1.5">
                <CheckCircle2 className="w-3.5 h-3.5 text-emerald-600 shrink-0" />
                <span>30-Day Ocean Texture satisfaction guarantee</span>
              </div>
            </div>

          </div>

        </div>
      </div>
    </div>
  );
};
