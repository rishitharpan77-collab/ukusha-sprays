import React from 'react';
import { Droplets, ShieldCheck, Sparkles, Truck, Award, CheckCircle } from 'lucide-react';
import { PRODUCT_IMG_1 } from '../data/mockData';

export const CoastalStory: React.FC = () => {
  return (
    <section id="sourcing" className="py-16 sm:py-24 bg-white border-t border-b border-stone-200">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        
        {/* Story Grid */}
        <div className="grid grid-cols-1 lg:grid-cols-12 gap-12 items-center">
          
          {/* Left Column: Macro Product Imagery with sea salt crystals */}
          <div className="lg:col-span-5 relative">
            <div className="relative rounded-2xl overflow-hidden shadow-xl border border-stone-200 aspect-4/3 bg-stone-100">
              <img
                src={PRODUCT_IMG_1}
                alt="Ukusha Sprays artisanal frosted glass sea salt spray with pink mineral crystals"
                className="w-full h-full object-cover"
                referrerPolicy="no-referrer"
              />
            </div>
            
            {/* Sourcing credential card */}
            <div className="mt-4 p-4 bg-[#f0f8f7] rounded-xl border border-[#c4e6e2] flex items-center justify-between">
              <div>
                <div className="text-xs font-bold text-[#133c46]">Arabian Sea &amp; Tuticorin Coastlines</div>
                <div className="text-[11px] text-stone-600">Solar-evaporated unrefined marine mineral extraction</div>
              </div>
              <span className="text-[10px] uppercase font-bold text-[#133c46] bg-white px-2 py-1 rounded border border-[#b8ded9]">
                Wild Harvested
              </span>
            </div>
          </div>

          {/* Right Column: Formulation & Courier Dispatch Promise */}
          <div className="lg:col-span-7 space-y-6">
            <div className="flex items-center gap-2 text-xs font-semibold text-[#184650] uppercase tracking-wider">
              <Droplets className="w-4 h-4" />
              <span>Marine Bioferment &amp; Ayurveda</span>
              <span aria-hidden="true">·</span>
              <span>Monsoon &amp; Humidity Proof</span>
            </div>

            <h2 className="font-serif text-3xl sm:text-4xl font-bold text-stone-900 tracking-tight leading-tight">
              Why ordinary salt sprays dry Indian hair, and why Ukusha doesn't.
            </h2>

            <p className="text-sm sm:text-base text-stone-600 leading-relaxed">
              India's tropical humidity and coastal weather often cause standard hair sprays to collapse into frizzy, sticky buildup. Ukusha Sprays balances raw magnesium-rich sea salt crystals with pure kelp bioferment, organic aloe vera leaf juice, and Ayurvedic vetiver &amp; jojoba extracts.
            </p>

            <div className="grid grid-cols-1 sm:grid-cols-2 gap-4 pt-2">
              <div className="p-4 bg-stone-50 rounded-xl border border-stone-200">
                <div className="flex items-center gap-2 font-bold text-stone-900 text-xs">
                  <CheckCircle className="w-4 h-4 text-emerald-600" />
                  <span>Humidity &amp; Frizz Shield</span>
                </div>
                <p className="text-xs text-stone-600 mt-1.5 leading-relaxed">
                  Locks in moisture and prevents limp curls during heavy monsoons in Mumbai, Goa, Chennai, and Kochi.
                </p>
              </div>

              <div className="p-4 bg-stone-50 rounded-xl border border-stone-200">
                <div className="flex items-center gap-2 font-bold text-stone-900 text-xs">
                  <CheckCircle className="w-4 h-4 text-emerald-600" />
                  <span>Infinitely Recyclable Glass</span>
                </div>
                <p className="text-xs text-stone-600 mt-1.5 leading-relaxed">
                  UV-filtering dark amber glass preserves delicate essential oils without plastic chemical leaching.
                </p>
              </div>
            </div>

          </div>

        </div>

        {/* Courier Pickup to Customer Delivery Section */}
        <div id="dispatch-process" className="mt-16 pt-12 border-t border-stone-200">
          <div className="max-w-3xl mb-8">
            <div className="flex items-center gap-2 text-xs font-semibold text-[#184650] uppercase tracking-wider mb-2">
              <Truck className="w-4 h-4" />
              <span>Pan-India Courier Fulfillment</span>
            </div>
            <h3 className="font-serif text-2xl sm:text-3xl font-bold text-stone-900">
              Direct Courier Pickup from Our Mumbai Hub to Your Doorstep
            </h3>
            <p className="text-sm text-stone-600 mt-2">
              When an order is placed, an automated pickup request is instantly sent to our logistics partners (BlueDart, Delhivery, or DTDC). The courier collects the packaged bottles directly from our Bandra, Mumbai fulfillment center and drops them off safely at your home across India.
            </p>
          </div>

          <div className="grid grid-cols-1 sm:grid-cols-3 gap-6">
            <div className="p-5 bg-[#faf9f6] rounded-xl border border-stone-200 relative">
              <span className="font-serif text-3xl font-bold text-stone-300">01</span>
              <h4 className="font-serif text-base font-bold text-stone-900 mt-2">Instant Carrier Dispatch</h4>
              <p className="text-xs text-stone-600 mt-1 leading-relaxed">
                As soon as your checkout tokenizes, courier airway bills are automatically generated and queued for daily warehouse pickup.
              </p>
            </div>

            <div className="p-5 bg-[#faf9f6] rounded-xl border border-stone-200 relative">
              <span className="font-serif text-3xl font-bold text-stone-300">02</span>
              <h4 className="font-serif text-base font-bold text-stone-900 mt-2">Eco-Padded Glass Transit</h4>
              <p className="text-xs text-stone-600 mt-1 leading-relaxed">
                Courier drivers collect packages packed in biodegradable marine-algae cushioning with barcode verification.
              </p>
            </div>

            <div className="p-5 bg-[#faf9f6] rounded-xl border border-stone-200 relative">
              <span className="font-serif text-3xl font-bold text-stone-300">03</span>
              <h4 className="font-serif text-base font-bold text-stone-900 mt-2">Doorstep Drop-off &amp; SMS</h4>
              <p className="text-xs text-stone-600 mt-1 leading-relaxed">
                Receive live SMS notifications as the driver approaches your address with safe contactless doorstep drop-off.
              </p>
            </div>
          </div>
        </div>

      </div>
    </section>
  );
};
