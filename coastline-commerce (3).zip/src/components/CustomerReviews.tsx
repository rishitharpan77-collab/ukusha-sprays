import React from 'react';
import { Star, ShieldCheck, CheckCircle2 } from 'lucide-react';

export const CustomerReviews: React.FC = () => {
  const reviews = [
    {
      id: 1,
      author: 'Pooja Kashyap',
      role: 'Editorial Hair Artist & Salon Creative Head',
      location: 'Bandra West, Mumbai',
      rating: 5,
      date: 'October 18, 2026',
      productName: 'Ukusha Original Sea Salt Mist (200ml)',
      quote: 'Mumbai monsoons and humidity usually destroy hairstyles within an hour. Ukusha is the only sea salt texturizer that gives my clients effortless matte beach waves without turning hair frizzy or crunchy. Delivery via BlueDart was super fast too!',
      verified: true
    },
    {
      id: 2,
      author: 'Sameer Sen',
      role: 'Surf Instructor & Outdoor Photographer',
      location: 'Anjuna Beach, Goa',
      rating: 5,
      date: 'October 12, 2026',
      productName: 'Driftwood & Cedarwood Ocean Mist',
      quote: 'The gritty hold on this formula is unbeatable in tropical coastal heat. Three spritzes into damp hair and you get that natural windswept volume that lasts all day. Plus, UPI payment and automated doorstep delivery worked seamlessly.',
      verified: true
    },
    {
      id: 3,
      author: 'Diya Balakrishnan',
      role: 'Styling Specialist',
      location: 'Indiranagar, Bengaluru',
      rating: 5,
      date: 'September 29, 2026',
      productName: 'Wave Whisper Salon Texture Mist',
      quote: 'I have fine straight hair that goes limp under regular imported sea salt sprays. Wave Whisper gives weightless root lift and definition without any stickiness. Also earned 140 loyalty points on my very first bottle!',
      verified: true
    }
  ];

  return (
    <section id="reviews" className="py-16 sm:py-24 bg-[#faf9f6]">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        
        {/* Header */}
        <div className="text-center max-w-2xl mx-auto mb-12">
          <div className="flex items-center justify-center gap-1.5 text-amber-500 mb-2">
            {[...Array(5)].map((_, i) => (
              <Star key={i} className="w-4 h-4 fill-amber-400 text-amber-400" />
            ))}
            <span className="text-xs font-bold text-stone-900 ml-1.5 tabular-nums">4.9 / 5.0 Global Rating</span>
          </div>
          <h2 className="font-serif text-3xl sm:text-4xl font-bold text-stone-900 tracking-tight">
            Verified Customer Impressions
          </h2>
          <p className="text-sm text-stone-600 mt-2">
            Real feedback from stylists, daily wave enthusiasts, and fine-hair clients.
          </p>
        </div>

        {/* 3 Review Cards */}
        <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
          {reviews.map((rev) => (
            <div 
              key={rev.id}
              className="p-6 bg-white rounded-2xl border border-stone-200 shadow-xs flex flex-col justify-between space-y-4"
            >
              <div className="space-y-3">
                <div className="flex items-center justify-between">
                  <div className="flex items-center text-amber-400">
                    {[...Array(rev.rating)].map((_, i) => (
                      <Star key={i} className="w-3.5 h-3.5 fill-amber-400" />
                    ))}
                  </div>
                  <span className="text-[11px] text-stone-400">{rev.date}</span>
                </div>

                <p className="text-xs sm:text-sm text-stone-700 leading-relaxed italic">
                  "{rev.quote}"
                </p>
              </div>

              <div className="pt-4 border-t border-stone-100">
                <div className="flex items-center justify-between">
                  <div>
                    <div className="text-xs font-bold text-stone-900 flex items-center gap-1.5">
                      <span>{rev.author}</span>
                      {rev.verified && (
                        <span title="Verified Buyer">
                          <CheckCircle2 className="w-3.5 h-3.5 text-emerald-600" />
                        </span>
                      )}
                    </div>
                    <div className="text-[11px] text-stone-500">{rev.role} · {rev.location}</div>
                  </div>
                </div>
                <div className="text-[11px] text-[#133c46] font-medium mt-1 truncate">
                  Purchased: {rev.productName}
                </div>
              </div>
            </div>
          ))}
        </div>

      </div>
    </section>
  );
};
