import React from 'react';
import { ShieldCheck, Truck, Award, LayoutDashboard, Lock } from 'lucide-react';
import { useStore } from '../context/StoreContext';

export const Footer: React.FC = () => {
  const { openLoyaltyModal, openTracker, toggleAdmin, openOwnerLoginModal, isOwnerAuthenticated } = useStore();

  return (
    <footer className="bg-[#0b1c20] text-stone-300 border-t border-[#16363e]">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-14">
        <div className="grid grid-cols-1 md:grid-cols-4 gap-8">
          
          {/* Brand Info */}
          <div className="space-y-3 md:col-span-1">
            <span className="font-serif text-2xl font-bold text-white tracking-tight">
              Ukusha Sprays
            </span>
            <p className="text-xs text-stone-400 leading-relaxed">
              Artisanal ocean texturizing mists crafted for Indian hair and coastal weather. Blended with unrefined Arabian Sea minerals, kelp bioferment, and soothing Ayurvedic botanicals.
            </p>
            <div className="text-[11px] text-stone-400 pt-1">
              Fulfillment Hub: Bandra Coastal Dock, Mumbai, Maharashtra 400050
            </div>
          </div>

          {/* Formulas */}
          <div className="space-y-2.5">
            <h4 className="text-xs font-bold uppercase tracking-wider text-white">Formulas</h4>
            <ul className="space-y-1.5 text-xs text-stone-400">
              <li><a href="#products" className="hover:text-white transition-colors">Ukusha Original Mist (₹1,499)</a></li>
              <li><a href="#products" className="hover:text-white transition-colors">Driftwood &amp; Cedarwood Mist (₹1,699)</a></li>
              <li><a href="#products" className="hover:text-white transition-colors">Wave Whisper Salon Mist (₹1,399)</a></li>
              <li><a href="#products" className="hover:text-white transition-colors">The Coastal Trilogy Vault (₹3,699)</a></li>
            </ul>
          </div>

          {/* Customer & Loyalty */}
          <div className="space-y-2.5">
            <h4 className="text-xs font-bold uppercase tracking-wider text-white">Customer Care</h4>
            <ul className="space-y-1.5 text-xs text-stone-400">
              <li>
                <button onClick={openLoyaltyModal} className="hover:text-white transition-colors flex items-center gap-1.5">
                  <Award className="w-3.5 h-3.5 text-[#8ce0d7]" />
                  <span>Ukusha Rewards Circle</span>
                </button>
              </li>
              <li>
                <button 
                  onClick={() => openTracker()}
                  className="hover:text-white transition-colors text-left"
                >
                  Pan-India Courier Pickup &amp; Tracking
                </button>
              </li>
              <li><span className="text-stone-400">Doorstep Delivery (BlueDart / Delhivery)</span></li>
              <li><span className="text-stone-400">30-Day Ocean Texture Warranty</span></li>
            </ul>
          </div>

          {/* Standards & Security */}
          <div className="space-y-3">
            <h4 className="text-xs font-bold uppercase tracking-wider text-white">Standards &amp; Security</h4>
            <div className="space-y-2 text-xs text-stone-400">
              <div className="flex items-center gap-2">
                <ShieldCheck className="w-4 h-4 text-emerald-400" />
                <span>UPI Autopay &amp; 256-Bit SSL Encrypted</span>
              </div>
              <div className="flex items-center gap-2">
                <Truck className="w-4 h-4 text-[#8ce0d7]" />
                <span>Automated Mumbai Warehouse Courier Pickup</span>
              </div>
              <div className="flex items-center gap-2 text-stone-400">
                <span className="w-1.5 h-1.5 rounded-full bg-teal-400 inline-block"></span>
                <span>Cruelty-Free &amp; Pure Arabian Marine Minerals</span>
              </div>
              <div className="flex items-center gap-2 text-stone-400">
                <span className="w-1.5 h-1.5 rounded-full bg-teal-400 inline-block"></span>
                <span>Doorstep Delivery via BlueDart &amp; Delhivery</span>
              </div>
            </div>
          </div>

        </div>

        {/* Bottom Bar */}
        <div className="mt-12 pt-6 border-t border-stone-800 text-xs text-stone-400 flex flex-col sm:flex-row items-center justify-between gap-4">
          <div>
            &copy; {new Date().getFullYear()} Ukusha Sprays. All rights reserved. Handcrafted coastal texturizers.
          </div>
          <div className="flex flex-wrap items-center gap-4 text-[11px]">
            <span>Privacy Policy</span>
            <span aria-hidden="true">·</span>
            <span>Terms of Service</span>
            <span aria-hidden="true">·</span>
            <span>PCI-DSS Level 1 Verified</span>
            <span aria-hidden="true">·</span>
            {isOwnerAuthenticated ? (
              <button
                onClick={toggleAdmin}
                className="text-amber-400 hover:text-amber-300 font-semibold transition-colors flex items-center gap-1"
                title="Store Owner Dashboard"
              >
                <LayoutDashboard className="w-3 h-3" />
                <span>Owner Mode</span>
              </button>
            ) : (
              <button
                onClick={openOwnerLoginModal}
                className="text-stone-500 hover:text-stone-400 transition-colors flex items-center gap-1"
                title="Restricted Store Owner Access"
              >
                <Lock className="w-3 h-3" />
                <span>Merchant Access</span>
              </button>
            )}
          </div>
        </div>
      </div>
    </footer>
  );
};
