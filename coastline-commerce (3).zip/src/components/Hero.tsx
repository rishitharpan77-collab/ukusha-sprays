import React from 'react';
import { ArrowRight, ShieldCheck, Truck, Sparkles, Award } from 'lucide-react';
import { HERO_IMAGE } from '../data/mockData';
import { useStore } from '../context/StoreContext';

export const Hero: React.FC = () => {
  const { openProductModal, products, openLoyaltyModal } = useStore();
  const bestSeller = products.find(p => p.isBestSeller) || products[0];

  return (
    <section className="relative bg-[#f6f5f1] border-b border-stone-200 overflow-hidden">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-12 lg:py-20">
        <div className="grid grid-cols-1 lg:grid-cols-12 gap-10 lg:gap-12 items-center">
          
          {/* Left Column: Brand Story & Call to Action */}
          <div className="lg:col-span-6 space-y-6">
            <div className="flex items-center gap-2 text-xs font-semibold text-[#1c4b55] uppercase tracking-wider">
              <span>Pure Coastal Sea Minerals</span>
              <span aria-hidden="true">·</span>
              <span>Monsoon &amp; Humidity Proof</span>
            </div>

            <h1 className="font-serif text-4xl sm:text-5xl lg:text-6xl font-bold tracking-tight text-stone-900 leading-[1.08] text-balance">
              Lived-in beach texture, crafted for Indian hair.
            </h1>

            <p className="text-base sm:text-lg text-stone-600 leading-relaxed max-w-xl">
              Ukusha Sprays creates artisanal ocean texturizing mists formulated with pure Arabian Sea mineral salts, organic kelp bioferment, and soothing Ayurvedic botanicals. Engineered to tame tropical humidity while delivering weightless, touchable volume with zero sticky buildup.
            </p>

            {/* CTAs */}
            <div className="flex flex-wrap items-center gap-4 pt-2">
              <button
                onClick={() => openProductModal(bestSeller)}
                className="px-6 py-3.5 text-sm font-semibold text-white bg-[#133c46] hover:bg-[#0f2e36] rounded-xl shadow-sm transition-all hover:translate-y-[-1px] flex items-center gap-2 whitespace-nowrap"
              >
                <span>Shop Original Mist — ₹1,499</span>
                <ArrowRight className="w-4 h-4" />
              </button>

              <a
                href="#products"
                className="px-5 py-3.5 text-sm font-semibold text-stone-700 bg-white hover:bg-stone-50 border border-stone-300 rounded-xl transition-all whitespace-nowrap"
              >
                Explore All Formulas
              </a>

              <button
                onClick={openLoyaltyModal}
                className="px-4 py-3.5 text-xs font-semibold text-[#184650] hover:bg-[#eaf4f4] border border-[#a8d3cf] rounded-xl transition-colors flex items-center gap-1.5 whitespace-nowrap"
              >
                <Award className="w-4 h-4 text-[#2a5b67]" />
                <span>Earn Coastal Rewards</span>
              </button>
            </div>

            {/* Trust Markers Bar */}
            <div className="grid grid-cols-3 gap-4 pt-6 border-t border-stone-200/80 text-stone-600">
              <div className="flex items-start gap-2.5">
                <ShieldCheck className="w-4 h-4 text-[#1c4b55] shrink-0 mt-0.5" />
                <div>
                  <div className="text-xs font-bold text-stone-900">256-Bit Encrypted</div>
                  <div className="text-[11px] text-stone-500">PCI-DSS Safe Checkout</div>
                </div>
              </div>

              <div className="flex items-start gap-2.5">
                <Truck className="w-4 h-4 text-[#1c4b55] shrink-0 mt-0.5" />
                <div>
                  <div className="text-xs font-bold text-stone-900">Courier Doorstep</div>
                  <div className="text-[11px] text-stone-500">Fast Warehouse Pickup</div>
                </div>
              </div>

              <div className="flex items-start gap-2.5">
                <Sparkles className="w-4 h-4 text-[#1c4b55] shrink-0 mt-0.5" />
                <div>
                  <div className="text-xs font-bold text-stone-900">Zero Stickiness</div>
                  <div className="text-[11px] text-stone-500">Hydrated Natural Matte</div>
                </div>
              </div>
            </div>

          </div>

          {/* Right Column: Hero High-Res Imagery */}
          <div className="lg:col-span-6 relative">
            <div className="relative rounded-2xl overflow-hidden shadow-2xl border border-stone-200 bg-stone-100 aspect-16/10 lg:aspect-16/11 group">
              <img
                src={HERO_IMAGE}
                alt="Ukusha Sprays luxury amber sea salt spray bottle on coastal rock with crashing waves"
                className="w-full h-full object-cover transition-transform duration-700 group-hover:scale-102"
                referrerPolicy="no-referrer"
              />
              <div className="absolute inset-0 bg-gradient-to-t from-stone-950/60 via-transparent to-transparent pointer-events-none" />
              
              {/* Floating product showcase snippet on image */}
              <div className="absolute bottom-4 left-4 right-4 sm:left-6 sm:right-6 p-4 bg-white/90 backdrop-blur-md rounded-xl border border-white/60 shadow-lg flex items-center justify-between gap-4">
                <div>
                  <div className="text-xs font-bold uppercase tracking-wider text-[#1c4b55]">Featured Signature</div>
                  <div className="font-serif text-lg font-bold text-stone-900">Ukusha Original Sea Salt Mist</div>
                  <div className="text-xs text-stone-600">Atlantic sea minerals · Kelp bioferment · Lavender</div>
                </div>
                <button
                  onClick={() => openProductModal(bestSeller)}
                  className="px-4 py-2 text-xs font-bold text-white bg-[#133c46] hover:bg-[#0f2e36] rounded-lg transition-colors whitespace-nowrap shrink-0"
                >
                  Quick View
                </button>
              </div>
            </div>
          </div>

        </div>
      </div>
    </section>
  );
};
