import React, { useState } from 'react';
import { X, Award, CheckCircle2, Gift, ArrowRight, Sparkles, Coins, ShoppingBag } from 'lucide-react';
import { useStore } from '../context/StoreContext';
import { LoyaltyReward } from '../types';

export const LoyaltyModal: React.FC = () => {
  const { 
    isLoyaltyModalOpen, 
    closeLoyaltyModal, 
    customer, 
    loyaltyRewards, 
    redeemReward,
    addBonusPoints,
    openCart
  } = useStore();

  const [activeTab, setActiveTab] = useState<'rewards' | 'history' | 'earn'>('rewards');
  const [redeemFeedback, setRedeemFeedback] = useState<{ message: string; success: boolean } | null>(null);

  if (!isLoyaltyModalOpen) return null;

  const handleRedeem = (reward: LoyaltyReward) => {
    const res = redeemReward(reward);
    setRedeemFeedback(res);
    if (res.success) {
      setTimeout(() => {
        setRedeemFeedback(null);
      }, 5000);
    }
  };

  const nextTierPoints = customer.tier === 'Coastal Seeker' ? 400 : customer.tier === 'Tide Explorer' ? 1000 : 2500;
  const progressPercent = Math.min(100, Math.round((customer.lifetimePointsEarned / nextTierPoints) * 100));

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-stone-900/60 backdrop-blur-sm animate-fade-in">
      <div 
        className="bg-white rounded-2xl shadow-2xl max-w-2xl w-full max-h-[90vh] flex flex-col overflow-hidden border border-stone-200"
        role="dialog"
        aria-modal="true"
        aria-labelledby="loyalty-modal-title"
      >
        {/* Header with Coastal Gradient */}
        <div className="bg-gradient-to-r from-[#0d2a31] via-[#143e49] to-[#1c5563] text-white p-6 relative">
          <button
            onClick={closeLoyaltyModal}
            className="absolute top-5 right-5 p-1.5 text-white/80 hover:text-white hover:bg-white/10 rounded-lg transition-colors"
            aria-label="Close Rewards Club"
          >
            <X className="w-5 h-5" />
          </button>

          <div className="flex items-center gap-2 text-xs font-semibold uppercase tracking-widest text-[#8ce0d7]">
            <Award className="w-4 h-4" />
            <span>Ukusha Ocean Rewards Circle</span>
          </div>

          <div className="mt-4 flex flex-col sm:flex-row sm:items-end justify-between gap-4">
            <div>
              <h2 id="loyalty-modal-title" className="font-serif text-2xl sm:text-3xl font-bold">
                Hello, {customer.name.split(' ')[0]}
              </h2>
              <p className="text-xs sm:text-sm text-stone-200 mt-1">
                Member Tier: <span className="font-semibold text-[#8ce0d7]">{customer.tier}</span> · Earn 1 pt per ₹10 spent
              </p>
            </div>

            {/* Current Balance Card */}
            <div className="bg-white/15 backdrop-blur-md px-5 py-3 rounded-xl border border-white/20 text-right">
              <div className="text-[11px] uppercase tracking-wider text-stone-200 font-medium">Available Balance</div>
              <div className="flex items-baseline justify-end gap-1.5">
                <span className="font-serif text-3xl font-bold text-white tabular-nums">{customer.pointsBalance}</span>
                <span className="text-xs text-[#8ce0d7] font-semibold">pts</span>
              </div>
              <div className="text-[11px] text-stone-300">
                ≈ ₹{Math.floor(customer.pointsBalance * 1.25)} discount power
              </div>
            </div>
          </div>

          {/* Tier Progress */}
          <div className="mt-5 bg-white/10 rounded-xl p-3 border border-white/10">
            <div className="flex justify-between text-xs text-stone-200 mb-1.5 font-medium">
              <span>Tier Progress: {customer.lifetimePointsEarned} / {nextTierPoints} lifetime pts</span>
              <span>{progressPercent}% to Next Tier</span>
            </div>
            <div className="w-full bg-white/20 h-2 rounded-full overflow-hidden">
              <div 
                className="bg-[#8ce0d7] h-full rounded-full transition-all duration-500" 
                style={{ width: `${progressPercent}%` }}
              />
            </div>
          </div>
        </div>

        {/* Navigation Tabs */}
        <div className="flex border-b border-stone-200 px-6 bg-stone-50">
          <button
            onClick={() => setActiveTab('rewards')}
            className={`py-3 px-4 text-xs font-semibold border-b-2 transition-colors ${
              activeTab === 'rewards'
                ? 'border-[#133c46] text-[#133c46]'
                : 'border-transparent text-stone-600 hover:text-stone-900'
            }`}
          >
            Redeem Rewards ({loyaltyRewards.length})
          </button>
          <button
            onClick={() => setActiveTab('history')}
            className={`py-3 px-4 text-xs font-semibold border-b-2 transition-colors ${
              activeTab === 'history'
                ? 'border-[#133c46] text-[#133c46]'
                : 'border-transparent text-stone-600 hover:text-stone-900'
            }`}
          >
            Points Activity ({customer.loyaltyHistory.length})
          </button>
          <button
            onClick={() => setActiveTab('earn')}
            className={`py-3 px-4 text-xs font-semibold border-b-2 transition-colors ${
              activeTab === 'earn'
                ? 'border-[#133c46] text-[#133c46]'
                : 'border-transparent text-stone-600 hover:text-stone-900'
            }`}
          >
            How to Earn
          </button>
        </div>

        {/* Feedback Alert */}
        {redeemFeedback && (
          <div className={`mx-6 mt-4 p-3 rounded-xl text-xs font-medium flex items-center justify-between ${
            redeemFeedback.success 
              ? 'bg-emerald-50 text-emerald-900 border border-emerald-200' 
              : 'bg-amber-50 text-amber-900 border border-amber-200'
          }`}>
            <div className="flex items-center gap-2">
              {redeemFeedback.success ? <CheckCircle2 className="w-4 h-4 text-emerald-600" /> : <Gift className="w-4 h-4 text-amber-600" />}
              <span>{redeemFeedback.message}</span>
            </div>
            {redeemFeedback.success && (
              <button
                onClick={() => {
                  closeLoyaltyModal();
                  openCart();
                }}
                className="font-bold underline ml-2 hover:opacity-80 flex items-center gap-1"
              >
                <span>View Cart</span>
                <ArrowRight className="w-3.5 h-3.5" />
              </button>
            )}
          </div>
        )}

        {/* Modal Body */}
        <div className="p-6 overflow-y-auto space-y-4 flex-1">
          {activeTab === 'rewards' && (
            <div className="space-y-3">
              <div className="text-xs text-stone-600">
                Redeem your points for instant discount vouchers. When redeemed, the voucher code is automatically copied and applied to your checkout cart!
              </div>

              <div className="grid grid-cols-1 sm:grid-cols-2 gap-3 pt-1">
                {loyaltyRewards.map((reward) => {
                  const canRedeem = customer.pointsBalance >= reward.pointsCost;
                  return (
                    <div 
                      key={reward.id}
                      className={`p-4 rounded-xl border transition-all flex flex-col justify-between ${
                        canRedeem 
                          ? 'bg-white border-stone-200 hover:border-[#133c46] hover:shadow-md' 
                          : 'bg-stone-50 border-stone-200 opacity-70'
                      }`}
                    >
                      <div>
                        <div className="flex items-start justify-between gap-2">
                          <h4 className="font-serif text-base font-bold text-stone-900">{reward.title}</h4>
                          <span className="text-xs font-bold text-[#133c46] bg-[#e6f4f3] px-2 py-0.5 rounded tabular-nums whitespace-nowrap">
                            {reward.pointsCost} pts
                          </span>
                        </div>
                        <p className="text-xs text-stone-600 mt-1 leading-relaxed">
                          {reward.description}
                        </p>
                        {reward.minOrderValue && (
                          <div className="text-[11px] text-stone-500 mt-2">
                            Min. purchase ₹{reward.minOrderValue}
                          </div>
                        )}
                      </div>

                      <div className="mt-4 pt-3 border-t border-stone-100 flex items-center justify-between">
                        <span className="text-[11px] font-mono font-semibold text-stone-500">
                          Code: {reward.code}
                        </span>

                        <button
                          onClick={() => handleRedeem(reward)}
                          disabled={!canRedeem}
                          className={`px-3 py-1.5 text-xs font-semibold rounded-lg transition-colors flex items-center gap-1 whitespace-nowrap ${
                            canRedeem
                              ? 'bg-[#133c46] hover:bg-[#0e2a30] text-white shadow-sm'
                              : 'bg-stone-200 text-stone-500 cursor-not-allowed'
                          }`}
                        >
                          {canRedeem ? (
                            <>
                              <span>Redeem</span>
                              <ArrowRight className="w-3.5 h-3.5" />
                            </>
                          ) : (
                            <span>Need {reward.pointsCost - customer.pointsBalance} more</span>
                          )}
                        </button>
                      </div>
                    </div>
                  );
                })}
              </div>
            </div>
          )}

          {activeTab === 'history' && (
            <div className="space-y-3">
              <div className="text-xs text-stone-600">
                Full chronological ledger of your earned and redeemed ocean points:
              </div>

              <div className="border border-stone-200 rounded-xl overflow-hidden divide-y divide-stone-100 bg-white">
                {customer.loyaltyHistory.length === 0 ? (
                  <div className="p-8 text-center text-sm text-stone-500">
                    No points transactions recorded yet.
                  </div>
                ) : (
                  customer.loyaltyHistory.map((tx) => (
                    <div key={tx.id} className="p-3.5 flex items-center justify-between gap-4">
                      <div>
                        <div className="text-xs font-semibold text-stone-900">{tx.description}</div>
                        <div className="text-[11px] text-stone-500">{tx.date}</div>
                      </div>
                      <div className={`font-mono text-xs font-bold tabular-nums ${
                        tx.pointsChange > 0 ? 'text-emerald-700' : 'text-amber-700'
                      }`}>
                        {tx.pointsChange > 0 ? `+${tx.pointsChange}` : tx.pointsChange} pts
                      </div>
                    </div>
                  ))
                )}
              </div>
            </div>
          )}

          {activeTab === 'earn' && (
            <div className="space-y-4">
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                <div className="p-4 bg-stone-50 rounded-xl border border-stone-200 flex items-start gap-3">
                  <Coins className="w-5 h-5 text-[#133c46] shrink-0 mt-0.5" />
                  <div>
                    <h5 className="text-xs font-bold text-stone-900">1 Point per ₹10 Spent</h5>
                    <p className="text-xs text-stone-600 mt-1">
                      Every ₹10 spent on Ukusha Sprays automatically awards 1 coastal loyalty point upon checkout completion across India.
                    </p>
                  </div>
                </div>

                <div className="p-4 bg-stone-50 rounded-xl border border-stone-200 flex items-start gap-3">
                  <Gift className="w-5 h-5 text-[#133c46] shrink-0 mt-0.5" />
                  <div>
                    <h5 className="text-xs font-bold text-stone-900">Welcome Bonus</h5>
                    <p className="text-xs text-stone-600 mt-1">
                      Instant 100 points credited when you join the Ukusha Ocean Rewards Circle.
                    </p>
                  </div>
                </div>

                <div className="p-4 bg-stone-50 rounded-xl border border-stone-200 flex items-start gap-3">
                  <Sparkles className="w-5 h-5 text-[#133c46] shrink-0 mt-0.5" />
                  <div>
                    <h5 className="text-xs font-bold text-stone-900">Review &amp; Share</h5>
                    <p className="text-xs text-stone-600 mt-1">
                      Get 50 points when leaving a verified photo review of your hair before &amp; after.
                    </p>
                  </div>
                </div>

                <div className="p-4 bg-stone-50 rounded-xl border border-stone-200 flex items-start gap-3">
                  <Award className="w-5 h-5 text-[#133c46] shrink-0 mt-0.5" />
                  <div>
                    <h5 className="text-xs font-bold text-stone-900">High Tide VIP Status</h5>
                    <p className="text-xs text-stone-600 mt-1">
                      Unlock early access to seasonal batches, custom sandalwood combs, and exclusive ₹1,500 vouchers.
                    </p>
                  </div>
                </div>
              </div>

              {/* Demo helper to test earning points */}
              <div className="p-4 bg-[#f0f9f8] rounded-xl border border-[#b2e1dc] flex items-center justify-between">
                <div>
                  <div className="text-xs font-bold text-[#133c46]">Interactive Demonstration Tool</div>
                  <div className="text-[11px] text-[#2c6571]">Simulate earning bonus points right now to test redemption</div>
                </div>
                <button
                  onClick={() => addBonusPoints(100, 'Demo Bonus Points Awarded')}
                  className="px-3 py-1.5 text-xs font-bold bg-[#133c46] hover:bg-[#0e2a30] text-white rounded-lg transition-colors whitespace-nowrap shadow-sm"
                >
                  +100 Bonus Pts
                </button>
              </div>
            </div>
          )}
        </div>

        {/* Footer */}
        <div className="p-4 bg-stone-50 border-t border-stone-200 flex items-center justify-between">
          <div className="text-[11px] text-stone-500">
            Points never expire. 1 reward code usable per order.
          </div>
          <button
            onClick={() => {
              closeLoyaltyModal();
              openCart();
            }}
            className="px-4 py-2 text-xs font-bold text-[#133c46] hover:bg-stone-200/60 rounded-lg transition-colors flex items-center gap-1.5"
          >
            <ShoppingBag className="w-3.5 h-3.5" />
            <span>Open Cart</span>
          </button>
        </div>

      </div>
    </div>
  );
};
