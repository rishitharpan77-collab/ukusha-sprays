import React, { useState } from 'react';
import { ShoppingBag, Award, ShieldCheck, LayoutDashboard, Menu, X } from 'lucide-react';
import { useStore } from '../context/StoreContext';

export const Navbar: React.FC = () => {
  const { 
    cart, 
    openCart, 
    customer, 
    openLoyaltyModal, 
    openTracker,
    toggleAdmin, 
    isAdminOpen,
    isOwnerAuthenticated 
  } = useStore();

  const [mobileMenuOpen, setMobileMenuOpen] = useState(false);

  const totalItems = cart.reduce((sum, item) => sum + item.quantity, 0);

  return (
    <>
      {/* Top Notification Bar - Minimal, informative */}
      <aside aria-label="Announcement" className="bg-[#0f282f] text-[#d1e7dd] text-xs py-1.5 px-4 text-center font-medium tracking-wide border-b border-[#1b3d46]">
        <div className="max-w-7xl mx-auto flex items-center justify-center gap-2">
          <span>Complimentary courier pickup &amp; delivery across India on orders over ₹999</span>
          <span aria-hidden="true" className="text-[#5a8692]">·</span>
          <span className="text-[#86e2d5] font-semibold">Earn 1 pt per ₹10 spent</span>
        </div>
      </aside>

      {/* Top Bar Contract: Zone 1 (Wordmark) — Zone 2 (4-5 Nav Links) — Zone 3 (Primary Actions) */}
      <header className="sticky top-0 z-40 bg-white/95 backdrop-blur-md border-b border-stone-200">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 h-18 flex items-center justify-between gap-8">
          
          {/* Zone 1: Single text element wordmark */}
          <a href="#" className="flex items-center gap-2 shrink-0 group">
            <span className="font-serif text-2xl sm:text-3xl font-bold tracking-tight text-stone-900 group-hover:text-[#184650] transition-colors whitespace-nowrap">
              Ukusha Sprays
            </span>
            <span className="text-[10px] tracking-widest uppercase font-semibold text-[#2a5b67] border border-[#2a5b67]/30 px-1.5 py-0.5 rounded">
              Coastal
            </span>
          </a>

          {/* Zone 2: 4–5 clean single-line text navigation links */}
          <nav className="hidden md:flex items-center gap-8 text-sm font-medium text-stone-600">
            <a href="#products" className="hover:text-stone-950 transition-colors whitespace-nowrap shrink-0">
              Formulas
            </a>
            <a href="#sourcing" className="hover:text-stone-950 transition-colors whitespace-nowrap shrink-0">
              Coastal Minerals
            </a>
            <button 
              onClick={() => openTracker()}
              className="text-stone-600 hover:text-stone-950 transition-colors whitespace-nowrap shrink-0 flex items-center gap-1.5"
            >
              <span>Track Order</span>
            </button>
            <button 
              onClick={openLoyaltyModal}
              className="text-stone-600 hover:text-stone-950 transition-colors whitespace-nowrap shrink-0 flex items-center gap-1.5"
            >
              <Award className="w-4 h-4 text-[#2a5b67]" />
              <span>Rewards Club</span>
            </button>
            <a href="#reviews" className="hover:text-stone-950 transition-colors whitespace-nowrap shrink-0">
              Reviews
            </a>
          </nav>

          {/* Zone 3: Primary Actions (Loyalty Pill, Admin Portal, Cart) */}
          <div className="flex items-center gap-3 shrink-0">
            {/* Loyalty points quick badge */}
            <button
              onClick={openLoyaltyModal}
              className="hidden sm:flex items-center gap-1.5 px-3 py-1.5 text-xs font-medium text-[#133c46] bg-[#eef7f6] hover:bg-[#deeeec] border border-[#c3e5e2] rounded-lg transition-colors whitespace-nowrap"
              title="View your Ukusha Coastal Points and rewards"
            >
              <Award className="w-3.5 h-3.5 text-[#22616f]" />
              <span className="font-bold tabular-nums">{customer.pointsBalance}</span>
              <span className="text-[#366874]">pts</span>
            </button>

            {/* Store Owner Admin Button - ONLY visible when owner is logged in */}
            {isOwnerAuthenticated && (
              <button
                onClick={toggleAdmin}
                className={`flex items-center gap-1.5 px-3 py-1.5 text-xs font-semibold rounded-lg border transition-all whitespace-nowrap ${
                  isAdminOpen 
                    ? 'bg-amber-600 text-white border-amber-700 shadow-sm' 
                    : 'bg-amber-50 hover:bg-amber-100 text-amber-900 border-amber-300'
                }`}
                title="Store Owner Admin: Manage Orders, Inventory, Courier Pickups, Analytics"
              >
                <LayoutDashboard className="w-3.5 h-3.5 text-amber-700" />
                <span className="hidden sm:inline">Owner Dashboard</span>
                <span className="sm:hidden">Owner</span>
              </button>
            )}

            {/* Shopping Bag Button */}
            <button
              onClick={openCart}
              className="relative p-2.5 text-stone-800 hover:text-[#133c46] hover:bg-stone-100 rounded-lg transition-colors"
              aria-label="Open Shopping Bag"
            >
              <ShoppingBag className="w-5 h-5" />
              {totalItems > 0 && (
                <span className="absolute -top-1 -right-1 bg-[#133c46] text-white text-[11px] font-bold w-5 h-5 rounded-full flex items-center justify-center border-2 border-white shadow-sm tabular-nums">
                  {totalItems}
                </span>
              )}
            </button>

            {/* Mobile menu trigger */}
            <button
              onClick={() => setMobileMenuOpen(prev => !prev)}
              className="md:hidden p-2 text-stone-700 hover:text-stone-900"
              aria-label="Toggle Navigation"
            >
              {mobileMenuOpen ? <X className="w-6 h-6" /> : <Menu className="w-6 h-6" />}
            </button>
          </div>
        </div>

        {/* Mobile dropdown navigation */}
        {mobileMenuOpen && (
          <div className="md:hidden bg-white border-b border-stone-200 px-4 py-4 space-y-3">
            <a 
              href="#products" 
              onClick={() => setMobileMenuOpen(false)}
              className="block py-2 text-base font-medium text-stone-800 hover:text-[#133c46]"
            >
              Formulas &amp; Sprays
            </a>
            <a 
              href="#sourcing" 
              onClick={() => setMobileMenuOpen(false)}
              className="block py-2 text-base font-medium text-stone-800 hover:text-[#133c46]"
            >
              Atlantic Mineral Sourcing
            </a>
            <button 
              onClick={() => {
                setMobileMenuOpen(false);
                openTracker();
              }}
              className="block w-full text-left py-2 text-base font-medium text-stone-800 hover:text-[#133c46]"
            >
              Track Order Real-Time (AWB)
            </button>
            <a 
              href="#reviews" 
              onClick={() => setMobileMenuOpen(false)}
              className="block py-2 text-base font-medium text-stone-800 hover:text-[#133c46]"
            >
              Customer Reviews
            </a>
            <div className="pt-2 border-t border-stone-100 flex items-center justify-between">
              <button
                onClick={() => {
                  setMobileMenuOpen(false);
                  openLoyaltyModal();
                }}
                className="flex items-center gap-2 text-sm font-semibold text-[#133c46]"
              >
                <Award className="w-4 h-4 text-[#22616f]" />
                <span>Rewards: {customer.pointsBalance} pts</span>
              </button>
              <div className="flex items-center gap-1 text-xs text-emerald-700">
                <ShieldCheck className="w-3.5 h-3.5" />
                <span>256-Bit SSL Encrypted</span>
              </div>
            </div>
          </div>
        )}
      </header>
    </>
  );
};
