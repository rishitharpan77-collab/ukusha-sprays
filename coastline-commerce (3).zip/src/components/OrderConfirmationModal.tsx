import React from 'react';
import { 
  X, 
  CheckCircle2, 
  Truck, 
  ShieldCheck, 
  Award, 
  Package, 
  MapPin, 
  ExternalLink,
  Barcode,
  ArrowRight
} from 'lucide-react';
import { useStore } from '../context/StoreContext';

export const OrderConfirmationModal: React.FC = () => {
  const { 
    activeOrder, 
    isOrderModalOpen, 
    closeOrderModal, 
    openLoyaltyModal, 
    toggleAdmin,
    setAdminTab
  } = useStore();

  if (!isOrderModalOpen || !activeOrder) return null;

  const { customer, items, total, pointsEarned, courierPickup, payment } = activeOrder;

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-3 sm:p-6 bg-stone-950/75 backdrop-blur-md overflow-y-auto">
      <div 
        className="bg-white rounded-2xl shadow-2xl max-w-2xl w-full max-h-[92vh] flex flex-col overflow-hidden border border-stone-200 animate-fade-in"
        role="dialog"
        aria-modal="true"
        aria-labelledby="order-confirmation-title"
      >
        {/* Coastal Success Header */}
        <div className="bg-gradient-to-r from-[#0d2a31] via-[#143e49] to-[#1d5766] text-white p-6 relative">
          <button
            onClick={closeOrderModal}
            className="absolute top-5 right-5 p-1.5 text-white/80 hover:text-white hover:bg-white/10 rounded-lg transition-colors"
            aria-label="Close confirmation"
          >
            <X className="w-5 h-5" />
          </button>

          <div className="flex items-center gap-2 text-xs font-semibold uppercase tracking-widest text-[#8ce0d7]">
            <CheckCircle2 className="w-4 h-4 text-emerald-400" />
            <span>Order Confirmed &amp; Courier Dispatched</span>
          </div>

          <h2 id="order-confirmation-title" className="font-serif text-2xl sm:text-3xl font-bold mt-2">
            Thank you, {customer.name}!
          </h2>
          <p className="text-xs sm:text-sm text-stone-200 mt-1">
            Order <span className="font-mono font-bold text-[#8ce0d7]">#{activeOrder.orderNumber}</span> has been securely processed and scheduled for courier pickup.
          </p>

          {/* Points Award Badge */}
          <div className="mt-4 p-3 bg-white/10 rounded-xl border border-white/15 flex items-center justify-between text-xs">
            <div className="flex items-center gap-2">
              <Award className="w-4 h-4 text-[#8ce0d7]" />
              <span>You earned <strong>+{pointsEarned} Ukusha Ocean Points</strong> on this order!</span>
            </div>
            <button
              onClick={() => {
                closeOrderModal();
                openLoyaltyModal();
              }}
              className="text-[#8ce0d7] font-bold underline hover:opacity-80 text-[11px]"
            >
              View Rewards
            </button>
          </div>
        </div>

        {/* Modal Scrollable Body */}
        <div className="p-6 overflow-y-auto space-y-6 flex-1">
          
          {/* Automated Courier Pickup to Customer Delivery Live Timeline */}
          <div className="p-4 bg-stone-50 rounded-2xl border border-stone-200 space-y-4">
            <div className="flex items-center justify-between">
              <div className="flex items-center gap-2">
                <Truck className="w-4 h-4 text-[#133c46]" />
                <h3 className="font-serif text-sm font-bold text-stone-900">
                  Courier Pickup &amp; Drop-off Timeline
                </h3>
              </div>
              <span className="text-[11px] font-mono font-bold text-[#133c46] bg-[#e3f4f2] px-2 py-0.5 rounded">
                AWB: {courierPickup.trackingNumber}
              </span>
            </div>

            {/* Stepper */}
            <div className="relative pl-6 space-y-5 before:absolute before:left-2 before:top-2 before:bottom-2 before:w-0.5 before:bg-[#133c46]/30">
              
              {/* Step 1: Confirmed */}
              <div className="relative">
                <div className="absolute -left-6 top-0.5 w-4 h-4 rounded-full bg-emerald-500 border-2 border-white shadow-sm flex items-center justify-center">
                  <CheckCircle2 className="w-3 h-3 text-white" />
                </div>
                <div className="text-xs font-bold text-stone-900">1. Payment Tokenized &amp; Verified</div>
                <div className="text-[11px] text-stone-500">
                  Cryptographic transaction token: <span className="font-mono">{payment.encryptedTransactionToken.slice(0, 24)}...</span>
                </div>
              </div>

              {/* Step 2: Courier Scheduled */}
              <div className="relative">
                <div className="absolute -left-6 top-0.5 w-4 h-4 rounded-full bg-[#133c46] border-2 border-white shadow-sm flex items-center justify-center">
                  <Package className="w-2.5 h-2.5 text-white" />
                </div>
                <div className="text-xs font-bold text-stone-900">
                  2. Courier Pickup Scheduled: <span className="text-[#133c46]">{courierPickup.carrier}</span>
                </div>
                <div className="text-[11px] text-stone-600">
                  Courier assigned to collect package from: <strong>{courierPickup.pickupWarehouse}</strong>
                </div>
                <div className="text-[11px] text-stone-500 mt-0.5">
                  Scheduled Window: {courierPickup.pickupScheduledTime}
                </div>
              </div>

              {/* Step 3: In Transit */}
              <div className="relative">
                <div className="absolute -left-6 top-0.5 w-4 h-4 rounded-full bg-stone-300 border-2 border-white" />
                <div className="text-xs font-medium text-stone-700">3. Express Air &amp; Surface Transit</div>
                <div className="text-[11px] text-stone-500">
                  Direct route to destination distribution hub with continuous barcode scans.
                </div>
              </div>

              {/* Step 4: Dropoff */}
              <div className="relative">
                <div className="absolute -left-6 top-0.5 w-4 h-4 rounded-full bg-stone-300 border-2 border-white" />
                <div className="text-xs font-medium text-stone-700">4. Doorstep Drop-off to Customer</div>
                <div className="text-[11px] text-stone-500">
                  Drop-off destination: {customer.address}, {customer.city}, {customer.state} {customer.postalCode}
                </div>
              </div>

            </div>

            {/* Simulated Digital Barcode & Tracking Card */}
            <div className="mt-3 p-3 bg-white rounded-xl border border-stone-200 flex items-center justify-between">
              <div className="flex items-center gap-2">
                <Barcode className="w-6 h-6 text-stone-700" />
                <div>
                  <div className="text-[10px] uppercase font-bold text-stone-400">Carrier Airway Bill</div>
                  <div className="font-mono text-xs font-bold text-stone-900">{courierPickup.trackingNumber}</div>
                </div>
              </div>
              <div className="text-right text-[11px] text-stone-500">
                Carrier: <strong>{courierPickup.carrier.split(' ')[0]}</strong>
              </div>
            </div>
          </div>

          {/* Itemized Order Details */}
          <div>
            <h4 className="text-xs font-bold text-stone-800 uppercase tracking-wider mb-2">
              Purchased Items
            </h4>
            <div className="divide-y divide-stone-100 border border-stone-200 rounded-xl overflow-hidden bg-white">
              {items.map((item) => (
                <div key={item.id} className="p-3 flex items-center justify-between text-xs">
                  <div className="flex items-center gap-3">
                    <img
                      src={item.product.image}
                      alt={item.product.name}
                      className="w-10 h-10 rounded-lg object-cover bg-stone-100"
                      referrerPolicy="no-referrer"
                    />
                    <div>
                      <div className="font-bold text-stone-900">{item.product.name}</div>
                      <div className="text-stone-500 text-[11px]">{item.selectedVariant.size} × {item.quantity}</div>
                    </div>
                  </div>
                  <div className="font-serif font-bold text-stone-900 tabular-nums">
                    ₹{item.selectedVariant.price * item.quantity}
                  </div>
                </div>
              ))}
            </div>
          </div>

          {/* Financial summary receipt */}
          <div className="p-4 bg-stone-50 rounded-xl border border-stone-200 space-y-1.5 text-xs">
            <div className="flex justify-between text-stone-600">
              <span>Subtotal</span>
              <span className="tabular-nums">₹{activeOrder.subtotal}</span>
            </div>
            {activeOrder.discountAmount > 0 && (
              <div className="flex justify-between text-emerald-800">
                <span>Voucher Discount</span>
                <span className="tabular-nums">-₹{activeOrder.discountAmount}</span>
              </div>
            )}
            <div className="flex justify-between text-stone-600">
              <span>Courier Delivery (Merchant Pickup &rarr; Dropoff)</span>
              <span className="tabular-nums">{activeOrder.shippingFee === 0 ? 'FREE' : `₹${activeOrder.shippingFee}`}</span>
            </div>
            <div className="flex justify-between text-stone-600">
              <span>GST (18% CGST + SGST)</span>
              <span className="tabular-nums">₹{activeOrder.taxAmount}</span>
            </div>
            <div className="flex justify-between font-bold text-sm text-stone-900 pt-2 border-t border-stone-200">
              <span>Total Paid</span>
              <span className="font-serif text-base text-[#133c46] tabular-nums">₹{total}</span>
            </div>
          </div>

          {/* Security guarantee note */}
          <div className="flex items-center gap-2 p-3 bg-emerald-50 text-emerald-900 rounded-xl border border-emerald-200 text-xs">
            <ShieldCheck className="w-4 h-4 text-emerald-700 shrink-0" />
            <span>
              Encrypted transaction recorded with PCI Level 1 tokenization. An email confirmation has been sent to <strong>{customer.email}</strong>.
            </span>
          </div>

        </div>

        {/* Modal Footer with quick link to Admin Store Owner view */}
        <div className="p-4 bg-stone-50 border-t border-stone-200 flex flex-col sm:flex-row items-center justify-between gap-3">
          <button
            onClick={() => {
              closeOrderModal();
              toggleAdmin();
              setAdminTab('orders');
            }}
            className="text-xs font-semibold text-[#133c46] hover:underline flex items-center gap-1.5"
          >
            <span>View this order in Store Owner Admin</span>
            <ExternalLink className="w-3.5 h-3.5" />
          </button>

          <button
            onClick={closeOrderModal}
            className="w-full sm:w-auto px-5 py-2.5 text-xs font-bold text-white bg-[#133c46] hover:bg-[#0e2a30] rounded-xl transition-colors shadow-sm"
          >
            Continue Browsing
          </button>
        </div>

      </div>
    </div>
  );
};
