import React, { useState, useEffect } from 'react';
import { 
  X, 
  Search, 
  Truck, 
  CheckCircle2, 
  Clock, 
  MapPin, 
  Barcode, 
  ShieldCheck, 
  Award, 
  ArrowRight,
  PackageCheck,
  RefreshCw,
  AlertCircle
} from 'lucide-react';
import { useStore } from '../context/StoreContext';
import { Order, OrderStatus } from '../types';

export const OrderTrackerModal: React.FC = () => {
  const { 
    isTrackerOpen, 
    closeTracker, 
    orders, 
    trackerInitialOrderNumber,
    updateOrderStatus
  } = useStore();

  const [orderQuery, setOrderQuery] = useState('');
  const [matchedOrder, setMatchedOrder] = useState<Order | null>(null);
  const [searchAttempted, setSearchAttempted] = useState(false);

  // Auto-search if an initial order number was passed
  useEffect(() => {
    if (trackerInitialOrderNumber) {
      setOrderQuery(trackerInitialOrderNumber);
      handleSearch(trackerInitialOrderNumber);
    } else if (orders.length > 0) {
      // Default to most recent order for immediate convenience
      setMatchedOrder(orders[0]);
      setOrderQuery(orders[0].orderNumber);
    }
  }, [trackerInitialOrderNumber, orders, isTrackerOpen]);

  if (!isTrackerOpen) return null;

  const handleSearch = (queryOverride?: string) => {
    const q = (queryOverride || orderQuery).trim().toUpperCase();
    setSearchAttempted(true);

    if (!q) {
      setMatchedOrder(null);
      return;
    }

    // Clean query (strip # if customer entered #UK-1042)
    const cleanQ = q.replace(/^#/, '');

    const found = orders.find(
      (o) =>
        o.orderNumber.toUpperCase() === cleanQ ||
        o.id.toUpperCase() === cleanQ ||
        o.courierPickup.trackingNumber.toUpperCase().includes(cleanQ) ||
        o.customer.phone.replace(/\D/g, '').includes(cleanQ.replace(/\D/g, ''))
    );

    setMatchedOrder(found || null);
  };

  const getStatusStepIndex = (status: OrderStatus) => {
    switch (status) {
      case 'payment_confirmed': return 1;
      case 'pickup_scheduled': return 2;
      case 'carrier_picked_up': return 3;
      case 'in_transit': return 4;
      case 'out_for_delivery': return 5;
      case 'delivered': return 6;
      default: return 2;
    }
  };

  const currentStep = matchedOrder ? getStatusStepIndex(matchedOrder.status) : 2;

  // Real-time status simulation helper for customer
  const advanceStatusDemo = () => {
    if (!matchedOrder) return;
    const nextStatusMap: Record<OrderStatus, OrderStatus> = {
      'payment_confirmed': 'pickup_scheduled',
      'pickup_scheduled': 'carrier_picked_up',
      'carrier_picked_up': 'in_transit',
      'in_transit': 'out_for_delivery',
      'out_for_delivery': 'delivered',
      'delivered': 'pickup_scheduled'
    };
    const next = nextStatusMap[matchedOrder.status] || 'pickup_scheduled';
    updateOrderStatus(matchedOrder.id, next);
    setMatchedOrder({
      ...matchedOrder,
      status: next,
      courierPickup: {
        ...matchedOrder.courierPickup,
        status: next === 'delivered' ? 'Delivered' : next === 'in_transit' || next === 'out_for_delivery' ? 'In Transit to Customer' : next === 'carrier_picked_up' ? 'Picked Up from Merchant' : 'Carrier En Route to Merchant'
      }
    });
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-3 sm:p-6 bg-stone-950/75 backdrop-blur-md overflow-y-auto animate-fade-in">
      <div 
        className="bg-white rounded-2xl shadow-2xl max-w-3xl w-full max-h-[92vh] flex flex-col overflow-hidden border border-stone-200"
        role="dialog"
        aria-modal="true"
        aria-labelledby="tracker-title"
      >
        {/* Header */}
        <div className="bg-[#0f282f] text-white p-5 sm:p-6 flex items-center justify-between border-b border-[#1b434d]">
          <div className="flex items-center gap-3">
            <div className="w-9 h-9 rounded-xl bg-[#8ce0d7]/20 text-[#8ce0d7] flex items-center justify-center font-bold">
              <Truck className="w-5 h-5" />
            </div>
            <div>
              <div className="flex items-center gap-2">
                <h2 id="tracker-title" className="font-serif text-xl sm:text-2xl font-bold">
                  Track Your Courier Delivery
                </h2>
                <span className="text-[10px] font-mono uppercase bg-emerald-900/60 text-emerald-300 border border-emerald-600/50 px-2 py-0.5 rounded">
                  Live Pan-India GPS &amp; AWB
                </span>
              </div>
              <p className="text-xs text-stone-300">
                Door-to-door courier tracking from Ukusha Mumbai Hub to your address in Indian Rupees (₹)
              </p>
            </div>
          </div>

          <button
            onClick={closeTracker}
            className="p-1.5 text-stone-300 hover:text-white rounded-lg hover:bg-white/10 transition-colors"
            aria-label="Close tracking modal"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Search Bar & Quick Demo Chips */}
        <div className="p-4 sm:p-6 bg-stone-50 border-b border-stone-200 space-y-3">
          <form
            onSubmit={(e) => {
              e.preventDefault();
              handleSearch();
            }}
            className="flex gap-2"
          >
            <div className="relative flex-1">
              <Search className="w-4 h-4 text-stone-400 absolute left-3 top-1/2 -translate-y-1/2" />
              <input
                type="text"
                placeholder="Enter Order ID (e.g. UK-1042) or AWB Tracking No..."
                value={orderQuery}
                onChange={(e) => setOrderQuery(e.target.value)}
                className="w-full pl-9 pr-4 py-2.5 text-xs sm:text-sm bg-white border border-stone-300 rounded-xl focus:outline-none focus:ring-2 focus:ring-[#133c46] focus:border-transparent uppercase font-mono font-bold"
              />
            </div>
            <button
              type="submit"
              className="px-5 py-2.5 text-xs sm:text-sm font-bold text-white bg-[#133c46] hover:bg-[#0e2a30] rounded-xl transition-colors shadow-sm flex items-center gap-1.5 whitespace-nowrap"
            >
              <span>Track Order</span>
              <ArrowRight className="w-4 h-4" />
            </button>
          </form>

          {/* Quick Demo Order Chips for testing */}
          <div className="flex flex-wrap items-center gap-2 pt-1 text-xs text-stone-500">
            <span className="font-semibold text-stone-700">Quick Test Lookups:</span>
            {orders.slice(0, 3).map((demoOrd) => (
              <button
                key={demoOrd.id}
                type="button"
                onClick={() => {
                  setOrderQuery(demoOrd.orderNumber);
                  handleSearch(demoOrd.orderNumber);
                }}
                className={`px-2.5 py-1 rounded-lg text-xs font-mono font-semibold transition-all border ${
                  matchedOrder?.id === demoOrd.id
                    ? 'bg-[#133c46] text-white border-[#133c46]'
                    : 'bg-white hover:bg-stone-200 text-stone-800 border-stone-300'
                }`}
              >
                #{demoOrd.orderNumber} ({demoOrd.customer.city})
              </button>
            ))}
          </div>
        </div>

        {/* Content Body */}
        <div className="flex-1 overflow-y-auto p-4 sm:p-6 space-y-6">
          {!matchedOrder ? (
            <div className="text-center py-12 bg-white rounded-2xl border border-dashed border-stone-300 p-8 space-y-3">
              <AlertCircle className="w-10 h-10 text-stone-400 mx-auto" />
              <h3 className="font-serif text-lg font-bold text-stone-800">
                {searchAttempted ? 'Order Not Found' : 'Enter an Order Number to Track'}
              </h3>
              <p className="text-xs text-stone-500 max-w-sm mx-auto">
                {searchAttempted
                  ? `No order found matching "${orderQuery}". Please verify your order confirmation email or try one of the demo chips above.`
                  : 'Enter your 6-digit order ID sent to your mobile phone via SMS or email to view live courier transit.'}
              </p>
            </div>
          ) : (
            <div className="space-y-6 animate-fade-in">
              
              {/* Order Status Summary Card */}
              <div className="p-5 bg-gradient-to-br from-[#f0f8f7] to-[#e4f3f1] rounded-2xl border border-[#c2e4e0] flex flex-col sm:flex-row sm:items-center justify-between gap-4">
                <div>
                  <div className="flex items-center gap-2">
                    <span className="font-mono text-xs font-bold text-[#133c46] bg-white px-2.5 py-1 rounded-md border border-[#c2e4e0]">
                      #{matchedOrder.orderNumber}
                    </span>
                    <span className="text-xs font-bold text-stone-600">
                      {new Date(matchedOrder.createdAt).toLocaleDateString('en-IN', {
                        day: 'numeric',
                        month: 'short',
                        year: 'numeric'
                      })}
                    </span>
                  </div>

                  <h3 className="font-serif text-2xl font-bold text-stone-900 mt-2">
                    {matchedOrder.status === 'delivered' ? (
                      <span className="text-emerald-800">Delivered Successfully</span>
                    ) : matchedOrder.status === 'out_for_delivery' ? (
                      <span className="text-blue-900">Out for Doorstep Delivery Today</span>
                    ) : matchedOrder.status === 'in_transit' ? (
                      <span className="text-[#133c46]">In Express Transit</span>
                    ) : matchedOrder.status === 'carrier_picked_up' ? (
                      <span className="text-[#133c46]">Collected from Mumbai Warehouse</span>
                    ) : (
                      <span className="text-amber-800">Courier Pickup Scheduled</span>
                    )}
                  </h3>

                  <p className="text-xs text-stone-600 mt-1">
                    Carrier Partner: <strong className="text-stone-900">{matchedOrder.courierPickup.carrier}</strong> · Destination: <strong className="text-stone-900">{matchedOrder.customer.city}, {matchedOrder.customer.state}</strong>
                  </p>
                </div>

                {/* Amount in Indian Rupees */}
                <div className="bg-white p-4 rounded-xl border border-[#c2e4e0] text-right shrink-0">
                  <div className="text-[11px] text-stone-500 uppercase tracking-wider font-semibold">
                    Total Order Value (INR)
                  </div>
                  <div className="font-serif text-2xl font-bold text-[#133c46] tabular-nums">
                    ₹{matchedOrder.total}
                  </div>
                  <div className="text-[10px] text-emerald-700 font-semibold mt-0.5">
                    Paid via {matchedOrder.payment.method === 'upi' ? `UPI (${matchedOrder.payment.upiId})` : matchedOrder.payment.cardBrand}
                  </div>
                </div>
              </div>

              {/* Real-time 5-Step Visual Timeline */}
              <div className="p-5 bg-white rounded-2xl border border-stone-200 shadow-xs space-y-4">
                <div className="flex items-center justify-between border-b border-stone-100 pb-3">
                  <div className="flex items-center gap-2">
                    <Truck className="w-4 h-4 text-[#133c46]" />
                    <h4 className="font-serif text-base font-bold text-stone-900">
                      Live Courier Dispatch &amp; Doorstep Tracking
                    </h4>
                  </div>
                  <button
                    onClick={advanceStatusDemo}
                    className="text-xs font-semibold text-[#133c46] hover:bg-stone-100 px-2.5 py-1 rounded-lg border border-stone-200 flex items-center gap-1 transition-colors"
                    title="Simulate courier moving to next transit milestone"
                  >
                    <RefreshCw className="w-3 h-3 text-[#133c46]" />
                    <span>Simulate Next Step</span>
                  </button>
                </div>

                {/* Progress Stepper Bar */}
                <div className="relative pt-2 pb-4">
                  <div className="grid grid-cols-4 gap-2 text-center">
                    
                    {/* Stage 1: Order Tokenized */}
                    <div className="space-y-1.5">
                      <div className={`w-8 h-8 mx-auto rounded-full flex items-center justify-center text-xs font-bold transition-all ${
                        currentStep >= 1 ? 'bg-emerald-600 text-white shadow-sm' : 'bg-stone-200 text-stone-500'
                      }`}>
                        <CheckCircle2 className="w-4 h-4" />
                      </div>
                      <div className="text-xs font-bold text-stone-900">Order Placed</div>
                      <div className="text-[10px] text-stone-500">AES-256 Tokenized</div>
                    </div>

                    {/* Stage 2: Warehouse Pickup */}
                    <div className="space-y-1.5">
                      <div className={`w-8 h-8 mx-auto rounded-full flex items-center justify-center text-xs font-bold transition-all ${
                        currentStep >= 3 ? 'bg-emerald-600 text-white shadow-sm' : currentStep >= 2 ? 'bg-[#133c46] text-white ring-4 ring-[#133c46]/20' : 'bg-stone-200 text-stone-500'
                      }`}>
                        <PackageCheck className="w-4 h-4" />
                      </div>
                      <div className="text-xs font-bold text-stone-900">Mumbai Hub Pickup</div>
                      <div className="text-[10px] text-stone-500">Driver At Bandra Bay</div>
                    </div>

                    {/* Stage 3: Air Transit */}
                    <div className="space-y-1.5">
                      <div className={`w-8 h-8 mx-auto rounded-full flex items-center justify-center text-xs font-bold transition-all ${
                        currentStep >= 4 ? 'bg-emerald-600 text-white shadow-sm' : 'bg-stone-200 text-stone-500'
                      }`}>
                        <Truck className="w-4 h-4" />
                      </div>
                      <div className="text-xs font-bold text-stone-900">In Express Transit</div>
                      <div className="text-[10px] text-stone-500">Direct Route to Hub</div>
                    </div>

                    {/* Stage 4: Doorstep Delivery */}
                    <div className="space-y-1.5">
                      <div className={`w-8 h-8 mx-auto rounded-full flex items-center justify-center text-xs font-bold transition-all ${
                        currentStep >= 6 ? 'bg-emerald-600 text-white shadow-sm' : currentStep === 5 ? 'bg-blue-600 text-white ring-4 ring-blue-600/20' : 'bg-stone-200 text-stone-500'
                      }`}>
                        <MapPin className="w-4 h-4" />
                      </div>
                      <div className="text-xs font-bold text-stone-900">Doorstep Drop-off</div>
                      <div className="text-[10px] text-stone-500">OTP / Contactless Handover</div>
                    </div>

                  </div>
                </div>

                {/* Logistics Route Bar */}
                <div className="p-3.5 bg-stone-50 rounded-xl border border-stone-200 grid grid-cols-1 sm:grid-cols-2 gap-3 text-xs">
                  <div>
                    <div className="text-[10px] font-bold uppercase tracking-wider text-stone-400">Merchant Pickup Origin</div>
                    <div className="font-semibold text-stone-900 mt-0.5">
                      Ukusha Sprays Fulfillment Hub
                    </div>
                    <div className="text-stone-500 text-[11px]">Bandra Coastal Dock, Mumbai, Maharashtra 400050</div>
                  </div>

                  <div>
                    <div className="text-[10px] font-bold uppercase tracking-wider text-stone-400">Customer Delivery Address</div>
                    <div className="font-semibold text-stone-900 mt-0.5">
                      {matchedOrder.customer.name}
                    </div>
                    <div className="text-stone-500 text-[11px]">
                      {matchedOrder.customer.address}, {matchedOrder.customer.city}, {matchedOrder.customer.state} ({matchedOrder.customer.postalCode})
                    </div>
                  </div>
                </div>

                {/* Digital AWB Barcode Details */}
                <div className="p-3 bg-white rounded-xl border border-stone-200 flex items-center justify-between">
                  <div className="flex items-center gap-3">
                    <Barcode className="w-8 h-8 text-stone-800 shrink-0" />
                    <div>
                      <div className="text-[10px] uppercase font-bold text-stone-400">Airway Bill (AWB) Barcode</div>
                      <div className="font-mono text-xs font-bold text-stone-900">{matchedOrder.courierPickup.trackingNumber}</div>
                    </div>
                  </div>

                  <div className="text-right text-xs">
                    <span className="text-stone-500 text-[11px]">Courier: </span>
                    <strong className="text-[#133c46] font-bold">{matchedOrder.courierPickup.carrier.split(' ')[0]}</strong>
                  </div>
                </div>
              </div>

              {/* Order Items & Rupee Receipt */}
              <div className="grid grid-cols-1 md:grid-cols-12 gap-6">
                
                {/* Items */}
                <div className="md:col-span-7 space-y-2">
                  <h4 className="text-xs font-bold text-stone-800 uppercase tracking-wider">
                    Purchased Texturizers ({matchedOrder.items.length})
                  </h4>
                  <div className="divide-y divide-stone-100 border border-stone-200 rounded-xl overflow-hidden bg-white">
                    {matchedOrder.items.map((item) => (
                      <div key={item.id} className="p-3 flex items-center justify-between text-xs">
                        <div className="flex items-center gap-3">
                          <img
                            src={item.product.image}
                            alt={item.product.name}
                            className="w-10 h-10 rounded-lg object-cover bg-stone-100 border border-stone-200"
                            referrerPolicy="no-referrer"
                          />
                          <div>
                            <div className="font-bold text-stone-900">{item.product.name}</div>
                            <div className="text-stone-500 text-[11px]">{item.selectedVariant.size} × {item.quantity}</div>
                          </div>
                        </div>
                        <div className="font-serif font-bold text-stone-900 tabular-nums">
                          ₹{item.selectedVariant.price * item.quantity}
                        </div>
                      </div>
                    ))}
                  </div>
                </div>

                {/* Cost Breakdown in ₹ */}
                <div className="md:col-span-5 space-y-2">
                  <h4 className="text-xs font-bold text-stone-800 uppercase tracking-wider">
                    Invoice Details (INR)
                  </h4>
                  <div className="p-3.5 bg-stone-50 rounded-xl border border-stone-200 space-y-1.5 text-xs">
                    <div className="flex justify-between text-stone-600">
                      <span>Subtotal</span>
                      <span className="tabular-nums font-medium">₹{matchedOrder.subtotal}</span>
                    </div>
                    {matchedOrder.discountAmount > 0 && (
                      <div className="flex justify-between text-emerald-800 font-medium">
                        <span>Voucher ({matchedOrder.discountCode})</span>
                        <span className="tabular-nums">-₹{matchedOrder.discountAmount}</span>
                      </div>
                    )}
                    <div className="flex justify-between text-stone-600">
                      <span>Courier Delivery (Pan-India)</span>
                      <span className="tabular-nums font-medium">
                        {matchedOrder.shippingFee === 0 ? 'FREE' : `₹${matchedOrder.shippingFee}`}
                      </span>
                    </div>
                    <div className="flex justify-between text-stone-600">
                      <span>GST (18% CGST + SGST)</span>
                      <span className="tabular-nums font-medium">₹{matchedOrder.taxAmount}</span>
                    </div>
                    <div className="flex justify-between font-bold text-sm text-stone-900 pt-2 border-t border-stone-200">
                      <span>Total Paid</span>
                      <span className="font-serif text-base text-[#133c46] tabular-nums">₹{matchedOrder.total}</span>
                    </div>
                  </div>

                  {/* Points Earned */}
                  <div className="p-2.5 bg-[#eef7f6] rounded-xl border border-[#c2e4e0] flex items-center justify-between text-xs text-[#133c46]">
                    <div className="flex items-center gap-1.5">
                      <Award className="w-3.5 h-3.5" />
                      <span className="font-semibold">Loyalty Points Earned:</span>
                    </div>
                    <span className="font-bold tabular-nums">+{matchedOrder.pointsEarned} pts</span>
                  </div>
                </div>

              </div>

            </div>
          )}
        </div>

        {/* Footer */}
        <div className="p-4 bg-stone-50 border-t border-stone-200 flex items-center justify-between">
          <div className="text-[11px] text-stone-500">
            Automated courier driver pickup directly from Mumbai fulfillment hub to customer.
          </div>
          <button
            onClick={closeTracker}
            className="px-5 py-2 text-xs font-bold text-white bg-[#133c46] hover:bg-[#0e2a30] rounded-xl transition-colors shadow-sm"
          >
            Close Tracker
          </button>
        </div>

      </div>
    </div>
  );
};
