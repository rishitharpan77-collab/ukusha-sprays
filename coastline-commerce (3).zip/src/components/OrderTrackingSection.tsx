import React, { useState } from 'react';
import { Search, Truck, ArrowRight, Barcode, ShieldCheck, CheckCircle2, Clock } from 'lucide-react';
import { useStore } from '../context/StoreContext';

export const OrderTrackingSection: React.FC = () => {
  const { openTracker, orders } = useStore();
  const [inputVal, setInputVal] = useState('');

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    openTracker(inputVal.trim() || undefined);
  };

  return (
    <section className="py-12 bg-gradient-to-b from-white to-[#f4f7f6] border-b border-stone-200">
      <div className="max-w-5xl mx-auto px-4 sm:px-6 lg:px-8">
        
        <div className="p-6 sm:p-8 bg-[#0f282f] text-white rounded-3xl shadow-xl border border-[#1b434d] flex flex-col md:flex-row md:items-center justify-between gap-6">
          <div className="space-y-2 max-w-md">
            <div className="flex items-center gap-2 text-xs font-semibold uppercase tracking-wider text-[#8ce0d7]">
              <Truck className="w-4 h-4" />
              <span>Real-Time Pan-India Courier Tracking</span>
            </div>
            <h3 className="font-serif text-2xl sm:text-3xl font-bold">
              Track Your Order &amp; Courier Pickup
            </h3>
            <p className="text-xs sm:text-sm text-stone-300 leading-relaxed">
              Enter your Ukusha Order ID (e.g. <span className="font-mono text-[#8ce0d7]">UK-1042</span>) to view live BlueDart / Delhivery courier pickup and doorstep delivery status in Indian Rupees (₹).
            </p>
          </div>

          <div className="w-full md:w-auto md:min-w-[340px]">
            <form onSubmit={handleSubmit} className="flex gap-2">
              <div className="relative flex-1">
                <Search className="w-4 h-4 text-stone-400 absolute left-3 top-1/2 -translate-y-1/2" />
                <input
                  type="text"
                  placeholder="Order ID (e.g. UK-1042)"
                  value={inputVal}
                  onChange={(e) => setInputVal(e.target.value)}
                  className="w-full pl-9 pr-3 py-3 text-xs font-mono font-bold uppercase bg-white/10 hover:bg-white/15 focus:bg-white focus:text-stone-900 border border-white/20 rounded-xl focus:outline-none focus:ring-2 focus:ring-[#8ce0d7] text-white placeholder:text-stone-400 transition-colors"
                />
              </div>
              <button
                type="submit"
                className="px-5 py-3 text-xs font-bold text-[#0f282f] bg-[#8ce0d7] hover:bg-[#76cdc4] rounded-xl transition-all shadow-md flex items-center gap-1.5 shrink-0"
              >
                <span>Track Now</span>
                <ArrowRight className="w-3.5 h-3.5" />
              </button>
            </form>

            <div className="flex items-center justify-between mt-2.5 text-[11px] text-stone-400 px-1">
              <span>Try demo order:</span>
              <button
                type="button"
                onClick={() => openTracker('UK-1042')}
                className="text-[#8ce0d7] font-mono hover:underline font-bold"
              >
                #UK-1042 (Pickup Scheduled)
              </button>
              <button
                type="button"
                onClick={() => openTracker('UK-1039')}
                className="text-[#8ce0d7] font-mono hover:underline font-bold"
              >
                #UK-1039 (In Transit)
              </button>
            </div>
          </div>
        </div>

      </div>
    </section>
  );
};
