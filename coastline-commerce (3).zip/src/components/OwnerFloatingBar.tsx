import React from 'react';
import { LayoutDashboard, LogOut, ShieldCheck, ExternalLink } from 'lucide-react';
import { useStore } from '../context/StoreContext';

export const OwnerFloatingBar: React.FC = () => {
  const { 
    isOwnerAuthenticated, 
    logoutOwner, 
    toggleAdmin, 
    isAdminOpen 
  } = useStore();

  if (!isOwnerAuthenticated) return null;

  return (
    <aside 
      aria-label="Store Owner Controls"
      className="fixed bottom-4 right-4 z-40 bg-[#0f282f] text-white px-4 py-2.5 rounded-2xl shadow-2xl border border-[#24525d] flex items-center gap-3 text-xs animate-slide-up"
    >
      <div className="flex items-center gap-2 pr-3 border-r border-[#24525d]">
        <span className="flex h-2 w-2 relative">
          <span className="animate-ping absolute inline-flex h-full w-full rounded-full bg-emerald-400 opacity-75"></span>
          <span className="relative inline-flex rounded-full h-2 w-2 bg-emerald-500"></span>
        </span>
        <div className="font-semibold text-stone-100 flex items-center gap-1.5">
          <ShieldCheck className="w-3.5 h-3.5 text-amber-400" />
          <span>Owner Mode</span>
        </div>
      </div>

      <div className="flex items-center gap-2">
        <button
          onClick={toggleAdmin}
          className={`px-3 py-1.5 rounded-lg font-semibold flex items-center gap-1.5 transition-all ${
            isAdminOpen 
              ? 'bg-amber-500 text-stone-950 shadow-sm' 
              : 'bg-white/10 hover:bg-white/20 text-white'
          }`}
          title="Open Store Owner Admin Dashboard"
        >
          <LayoutDashboard className="w-3.5 h-3.5" />
          <span>{isAdminOpen ? 'Close Dashboard' : 'Admin Dashboard'}</span>
        </button>

        <button
          onClick={logoutOwner}
          className="p-1.5 text-stone-400 hover:text-rose-400 hover:bg-white/10 rounded-lg transition-colors"
          title="Log Out (Preview store exactly as customers see it)"
          aria-label="Log out of Owner Mode"
        >
          <LogOut className="w-4 h-4" />
        </button>
      </div>
    </aside>
  );
};
