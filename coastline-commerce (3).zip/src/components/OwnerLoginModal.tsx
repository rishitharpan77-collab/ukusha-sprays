import React, { useState } from 'react';
import { Lock, X, ShieldAlert, KeyRound, CheckCircle2, Eye, EyeOff, AlertCircle } from 'lucide-react';
import { useStore } from '../context/StoreContext';

export const OwnerLoginModal: React.FC = () => {
  const { 
    isOwnerLoginModalOpen, 
    closeOwnerLoginModal, 
    loginOwner, 
    isOwnerAuthenticated 
  } = useStore();

  const [passcode, setPasscode] = useState('');
  const [showPassword, setShowPassword] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const [isSubmitting, setIsSubmitting] = useState(false);

  if (!isOwnerLoginModalOpen || isOwnerAuthenticated) return null;

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    setError(null);
    setIsSubmitting(true);

    setTimeout(() => {
      const success = loginOwner(passcode);
      setIsSubmitting(false);
      if (success) {
        setPasscode('');
      } else {
        setError('Incorrect owner passcode. Please check your credentials or use the default passcode ukusha2026.');
      }
    }, 300);
  };

  const handleQuickFill = () => {
    setPasscode('ukusha2026');
    setError(null);
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-stone-950/80 backdrop-blur-md animate-fade-in">
      <div 
        className="bg-white rounded-2xl shadow-2xl max-w-md w-full overflow-hidden border border-stone-200"
        role="dialog"
        aria-modal="true"
        aria-labelledby="owner-login-title"
      >
        {/* Header */}
        <div className="bg-[#0f282f] text-white p-6 border-b border-[#1b434d]">
          <div className="flex items-center justify-between">
            <div className="flex items-center gap-3">
              <div className="w-10 h-10 rounded-xl bg-amber-500/20 text-amber-400 flex items-center justify-center border border-amber-500/30">
                <Lock className="w-5 h-5" />
              </div>
              <div>
                <h3 id="owner-login-title" className="font-serif text-lg font-bold text-white tracking-wide">
                  Store Owner Access
                </h3>
                <p className="text-xs text-[#8ce0d7] font-medium">
                  Ukusha Sprays Merchant Portal
                </p>
              </div>
            </div>

            <button
              onClick={closeOwnerLoginModal}
              className="p-1.5 text-stone-400 hover:text-white rounded-lg hover:bg-white/10 transition-colors"
              aria-label="Close"
            >
              <X className="w-5 h-5" />
            </button>
          </div>
        </div>

        {/* Form Body */}
        <form onSubmit={handleSubmit} className="p-6 space-y-5">
          <div className="p-3.5 bg-amber-50 border border-amber-200/80 rounded-xl flex items-start gap-3 text-xs text-amber-900 leading-relaxed">
            <ShieldAlert className="w-4 h-4 text-amber-700 shrink-0 mt-0.5" />
            <div>
              <strong className="font-semibold block text-amber-950">Restricted Merchant Area</strong>
              This dashboard is private to the store owner (<span className="font-mono font-medium">rishitharpan77@gmail.com</span>). Customers cannot access or view orders, customer details, or pricing controls.
            </div>
          </div>

          {error && (
            <div className="p-3 bg-rose-50 border border-rose-200 rounded-xl flex items-center gap-2.5 text-xs text-rose-800">
              <AlertCircle className="w-4 h-4 text-rose-600 shrink-0" />
              <span>{error}</span>
            </div>
          )}

          <div className="space-y-1.5">
            <label className="block text-xs font-bold uppercase tracking-wider text-stone-700">
              Owner Passcode or Master Key
            </label>
            <div className="relative">
              <input
                type={showPassword ? 'text' : 'password'}
                value={passcode}
                onChange={(e) => {
                  setPasscode(e.target.value);
                  if (error) setError(null);
                }}
                placeholder="Enter owner passcode"
                className="w-full pl-10 pr-10 py-2.5 text-sm bg-stone-50 border border-stone-300 rounded-xl focus:bg-white focus:outline-none focus:ring-2 focus:ring-[#133c46] focus:border-[#133c46] transition-all font-mono"
                autoFocus
                required
              />
              <KeyRound className="w-4 h-4 text-stone-400 absolute left-3.5 top-3" />
              <button
                type="button"
                onClick={() => setShowPassword(prev => !prev)}
                className="absolute right-3.5 top-3 text-stone-400 hover:text-stone-700"
              >
                {showPassword ? <EyeOff className="w-4 h-4" /> : <Eye className="w-4 h-4" />}
              </button>
            </div>
            
            {/* Quick Helper for Owner */}
            <div className="flex items-center justify-between pt-1 text-[11px] text-stone-500">
              <span>Owner PIN: <code className="bg-stone-100 px-1 py-0.5 rounded text-stone-800 font-mono font-semibold">ukusha2026</code></span>
              <button
                type="button"
                onClick={handleQuickFill}
                className="text-[#133c46] font-semibold hover:underline"
              >
                Auto-fill PIN
              </button>
            </div>
          </div>

          <div className="pt-2 flex flex-col gap-2">
            <button
              type="submit"
              disabled={isSubmitting}
              className="w-full py-3 px-4 bg-[#133c46] hover:bg-[#1a4f5c] text-white font-semibold text-sm rounded-xl transition-all shadow-md flex items-center justify-center gap-2 disabled:opacity-50"
            >
              {isSubmitting ? (
                <span>Verifying credentials...</span>
              ) : (
                <>
                  <CheckCircle2 className="w-4 h-4" />
                  <span>Unlock Admin Dashboard</span>
                </>
              )}
            </button>

            <button
              type="button"
              onClick={closeOwnerLoginModal}
              className="w-full py-2.5 px-4 text-xs font-semibold text-stone-600 hover:text-stone-900 transition-colors"
            >
              Cancel &amp; Return to Store
            </button>
          </div>

          {/* Shortcut note */}
          <div className="pt-2 border-t border-stone-100 text-center text-[11px] text-stone-400">
            Store Owner Shortcut: Press <kbd className="px-1.5 py-0.5 bg-stone-100 border border-stone-200 rounded font-mono text-[10px] text-stone-700">Ctrl + Shift + A</kbd> anywhere to open
          </div>
        </form>
      </div>
    </div>
  );
};
