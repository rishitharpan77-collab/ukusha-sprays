import React, { useState } from 'react';
import { Star, Eye, Plus, Check } from 'lucide-react';
import { Product } from '../types';
import { useStore } from '../context/StoreContext';

interface ProductCardProps {
  product: Product;
}

export const ProductCard: React.FC<ProductCardProps> = ({ product }) => {
  const { openProductModal, addToCart } = useStore();
  const [selectedVariantIndex, setSelectedVariantIndex] = useState(
    product.variants.length > 1 ? 1 : 0 // Default to signature 200ml if available
  );
  const [justAdded, setJustAdded] = useState(false);

  const activeVariant = product.variants[selectedVariantIndex] || product.variants[0];

  const handleQuickAdd = (e: React.MouseEvent) => {
    e.stopPropagation();
    addToCart(product, activeVariant, 1);
    setJustAdded(true);
    setTimeout(() => setJustAdded(false), 1800);
  };

  return (
    <div 
      onClick={() => openProductModal(product)}
      className="group bg-white rounded-2xl border border-stone-200 overflow-hidden hover:shadow-xl transition-all duration-300 hover:-translate-y-1 cursor-pointer flex flex-col justify-between"
    >
      {/* Visual Product Display (65-75% height) */}
      <div className="relative aspect-4/3 bg-stone-100 overflow-hidden">
        <img
          src={product.image}
          alt={product.name}
          className="w-full h-full object-cover object-center group-hover:scale-104 transition-transform duration-500"
          referrerPolicy="no-referrer"
        />

        {/* Subtle Editorial Tag (strictly max 1 quiet tag) */}
        {product.badge && (
          <div className="absolute top-3 left-3 bg-stone-900/80 backdrop-blur-md text-white text-[11px] font-medium tracking-wide uppercase px-2.5 py-1 rounded">
            {product.badge}
          </div>
        )}

        {/* Quick View Button overlay */}
        <div className="absolute bottom-3 right-3 opacity-0 group-hover:opacity-100 transition-opacity duration-200">
          <button
            onClick={(e) => {
              e.stopPropagation();
              openProductModal(product);
            }}
            className="p-2.5 bg-white/90 hover:bg-white text-stone-900 rounded-xl shadow-md backdrop-blur-sm transition-transform hover:scale-105"
            aria-label="Quick View Product Details"
          >
            <Eye className="w-4 h-4" />
          </button>
        </div>
      </div>

      {/* Product Information */}
      <div className="p-5 flex-1 flex flex-col justify-between">
        <div className="space-y-1.5">
          {/* Unboxed Metadata with typographic separator */}
          <div className="flex items-center gap-1.5 text-xs text-stone-500">
            <span>{product.holdLevel}</span>
            <span aria-hidden="true">·</span>
            <span>{product.finish}</span>
          </div>

          <h3 className="font-serif text-lg font-bold text-stone-900 leading-snug group-hover:text-[#133c46] transition-colors">
            {product.name}
          </h3>

          <p className="text-xs text-stone-600 line-clamp-2 leading-relaxed">
            {product.subtitle}
          </p>

          {/* Ratings & Reviews */}
          <div className="flex items-center gap-2 pt-1">
            <div className="flex items-center text-amber-500">
              <Star className="w-3.5 h-3.5 fill-amber-400 text-amber-400" />
              <span className="ml-1 text-xs font-bold text-stone-900 tabular-nums">{product.rating}</span>
            </div>
            <span className="text-xs text-stone-400 tabular-nums">({product.reviewsCount} reviews)</span>
          </div>
        </div>

        {/* Variants Selection & Add to Cart */}
        <div className="mt-4 pt-4 border-t border-stone-100 space-y-3">
          {/* Variant selector buttons */}
          {product.variants.length > 1 && (
            <div className="flex items-center gap-1.5 overflow-x-auto pb-1" onClick={(e) => e.stopPropagation()}>
              {product.variants.map((v, idx) => (
                <button
                  key={v.id}
                  onClick={() => setSelectedVariantIndex(idx)}
                  className={`px-2.5 py-1 text-[11px] font-medium rounded-md whitespace-nowrap transition-colors ${
                    selectedVariantIndex === idx
                      ? 'bg-stone-900 text-white font-semibold'
                      : 'bg-stone-100 text-stone-700 hover:bg-stone-200'
                  }`}
                >
                  {v.size.split(' ')[0]} {v.volumeMl ? `(${v.volumeMl}ml)` : ''}
                </button>
              ))}
            </div>
          )}

          {/* Pricing & Add to Cart Bar */}
          <div className="flex items-center justify-between gap-3">
            <div className="flex items-baseline gap-1.5">
              <span className="font-serif text-xl font-bold text-stone-900 tabular-nums">
                ₹{activeVariant.price}
              </span>
              {activeVariant.originalPrice && (
                <span className="text-xs text-stone-400 line-through tabular-nums">
                  ₹{activeVariant.originalPrice}
                </span>
              )}
            </div>

            <button
              onClick={handleQuickAdd}
              disabled={!product.inStock}
              className={`px-3.5 py-2 text-xs font-semibold rounded-xl transition-all flex items-center gap-1.5 whitespace-nowrap ${
                justAdded
                  ? 'bg-emerald-700 text-white'
                  : product.inStock
                  ? 'bg-[#133c46] hover:bg-[#0e2a30] text-white shadow-sm hover:translate-y-[-1px]'
                  : 'bg-stone-200 text-stone-400 cursor-not-allowed'
              }`}
            >
              {justAdded ? (
                <>
                  <Check className="w-3.5 h-3.5" />
                  <span>Added</span>
                </>
              ) : product.inStock ? (
                <>
                  <Plus className="w-3.5 h-3.5" />
                  <span>Add to Bag</span>
                </>
              ) : (
                <span>Out of Stock</span>
              )}
            </button>
          </div>
        </div>

      </div>
    </div>
  );
};
