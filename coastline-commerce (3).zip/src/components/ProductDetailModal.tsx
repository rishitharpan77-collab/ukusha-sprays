import React, { useState } from 'react';
import { 
  X, 
  Star, 
  ShieldCheck, 
  Truck, 
  Sparkles, 
  Check, 
  Plus, 
  Minus, 
  ShoppingBag, 
  Award,
  Droplets,
  Wind,
  Layers
} from 'lucide-react';
import { useStore } from '../context/StoreContext';

export const ProductDetailModal: React.FC = () => {
  const { 
    selectedProduct, 
    closeProductModal, 
    addToCart, 
    openCart, 
    openLoyaltyModal 
  } = useStore();

  const [activeImageIndex, setActiveImageIndex] = useState(0);
  const [selectedVariantIndex, setSelectedVariantIndex] = useState(0);
  const [quantity, setQuantity] = useState(1);
  const [addedSuccess, setAddedSuccess] = useState(false);
  const [activeDetailTab, setActiveDetailTab] = useState<'benefits' | 'ingredients' | 'howTo' | 'scent'>('benefits');

  if (!selectedProduct) return null;

  const activeVariant = selectedProduct.variants[selectedVariantIndex] || selectedProduct.variants[0];
  const images = selectedProduct.gallery && selectedProduct.gallery.length > 0 
    ? selectedProduct.gallery 
    : [selectedProduct.image];

  const handleAddToCart = () => {
    addToCart(selectedProduct, activeVariant, quantity);
    setAddedSuccess(true);
    setTimeout(() => {
      setAddedSuccess(false);
    }, 2500);
  };

  const pointsForThis = Math.floor((activeVariant.price * quantity) / 10);

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-3 sm:p-6 bg-stone-950/70 backdrop-blur-sm overflow-y-auto">
      <div 
        className="bg-white rounded-2xl shadow-2xl max-w-4xl w-full max-h-[92vh] flex flex-col overflow-hidden border border-stone-200 relative animate-fade-in"
        role="dialog"
        aria-modal="true"
        aria-labelledby="product-detail-title"
      >
        {/* Close Button */}
        <button
          onClick={closeProductModal}
          className="absolute top-4 right-4 z-20 p-2 bg-white/80 hover:bg-white text-stone-700 hover:text-stone-950 rounded-full shadow-sm backdrop-blur-md transition-colors"
          aria-label="Close modal"
        >
          <X className="w-5 h-5" />
        </button>

        {/* Modal Main Content */}
        <div className="overflow-y-auto flex-1 grid grid-cols-1 md:grid-cols-12 divide-y md:divide-y-0 md:divide-x divide-stone-200">
          
          {/* Left Column: Image Gallery */}
          <div className="md:col-span-6 p-6 sm:p-8 flex flex-col justify-between bg-stone-50">
            <div>
              {/* Primary Active Image Display */}
              <div className="relative aspect-4/3 rounded-xl overflow-hidden shadow-inner border border-stone-200 bg-white">
                <img
                  src={images[activeImageIndex] || selectedProduct.image}
                  alt={selectedProduct.name}
                  className="w-full h-full object-cover transition-all duration-300"
                  referrerPolicy="no-referrer"
                />

                {selectedProduct.badge && (
                  <div className="absolute top-3 left-3 bg-stone-900/85 backdrop-blur-sm text-white text-[11px] font-semibold px-2.5 py-1 rounded">
                    {selectedProduct.badge}
                  </div>
                )}
              </div>

              {/* Thumbnails */}
              {images.length > 1 && (
                <div className="flex items-center gap-2 mt-4 overflow-x-auto pb-1">
                  {images.map((img, idx) => (
                    <button
                      key={idx}
                      onClick={() => setActiveImageIndex(idx)}
                      className={`w-16 h-16 rounded-lg overflow-hidden border-2 transition-all shrink-0 ${
                        activeImageIndex === idx ? 'border-[#133c46] shadow-md scale-102' : 'border-stone-200 opacity-70 hover:opacity-100'
                      }`}
                    >
                      <img src={img} alt="thumbnail" className="w-full h-full object-cover" referrerPolicy="no-referrer" />
                    </button>
                  ))}
                </div>
              )}
            </div>

            {/* Scent Pyramid Capsule */}
            <div className="mt-6 p-4 bg-white rounded-xl border border-stone-200">
              <div className="text-[11px] font-bold uppercase tracking-wider text-[#184650] flex items-center gap-1.5 mb-2">
                <Wind className="w-3.5 h-3.5" />
                <span>Coastal Scent Notes</span>
              </div>
              <div className="grid grid-cols-3 gap-2 text-center text-xs">
                <div className="p-2 bg-stone-50 rounded-lg">
                  <div className="text-[10px] uppercase font-bold text-stone-600">Top</div>
                  <div className="font-medium text-stone-900 text-[11px] mt-0.5">{selectedProduct.scentProfile.top}</div>
                </div>
                <div className="p-2 bg-stone-50 rounded-lg">
                  <div className="text-[10px] uppercase font-bold text-stone-600">Heart</div>
                  <div className="font-medium text-stone-900 text-[11px] mt-0.5">{selectedProduct.scentProfile.heart}</div>
                </div>
                <div className="p-2 bg-stone-50 rounded-lg">
                  <div className="text-[10px] uppercase font-bold text-stone-600">Base</div>
                  <div className="font-medium text-stone-900 text-[11px] mt-0.5">{selectedProduct.scentProfile.base}</div>
                </div>
              </div>
            </div>

          </div>

          {/* Right Column: Contiguous Purchase Module */}
          <div className="md:col-span-6 p-6 sm:p-8 flex flex-col justify-between space-y-6">
            <div className="space-y-4">
              
              {/* Hold & Finish Badges */}
              <div className="flex items-center gap-2 text-xs text-stone-500 font-medium">
                <span>{selectedProduct.holdLevel}</span>
                <span aria-hidden="true">·</span>
                <span>{selectedProduct.finish}</span>
                <span aria-hidden="true">·</span>
                <span className="text-emerald-700 font-semibold flex items-center gap-1">
                  <Check className="w-3 h-3" />
                  In Stock ({activeVariant.stock} bottles)
                </span>
              </div>

              <div>
                <h1 id="product-detail-title" className="font-serif text-2xl sm:text-3xl font-bold text-stone-900 leading-tight">
                  {selectedProduct.name}
                </h1>
                <p className="text-xs sm:text-sm text-stone-600 mt-1">
                  {selectedProduct.tagline}
                </p>
              </div>

              {/* Price & Rating Row */}
              <div className="flex items-center justify-between pb-3 border-b border-stone-100">
                <div className="flex items-baseline gap-2">
                  <span className="font-serif text-3xl font-bold text-stone-900 tabular-nums">
                    ₹{activeVariant.price}
                  </span>
                  {activeVariant.originalPrice && (
                    <span className="text-sm text-stone-400 line-through tabular-nums">
                      ₹{activeVariant.originalPrice}
                    </span>
                  )}
                  {activeVariant.originalPrice && (
                    <span className="text-xs font-semibold text-emerald-800 bg-emerald-50 px-2 py-0.5 rounded">
                      Save ₹{activeVariant.originalPrice - activeVariant.price}
                    </span>
                  )}
                </div>

                <div className="flex items-center gap-1 text-xs text-stone-600">
                  <div className="flex items-center text-amber-500">
                    <Star className="w-4 h-4 fill-amber-400 text-amber-400" />
                    <span className="ml-1 font-bold text-stone-900 tabular-nums">{selectedProduct.rating}</span>
                  </div>
                  <span className="text-stone-400">({selectedProduct.reviewsCount} reviews)</span>
                </div>
              </div>

              {/* Variant Selector */}
              <div>
                <div className="text-xs font-bold text-stone-800 uppercase tracking-wider mb-2 flex items-center justify-between">
                  <span>Select Size &amp; Pack</span>
                  <span className="text-stone-500 font-normal lowercase">{activeVariant.volumeMl}ml</span>
                </div>
                <div className="grid grid-cols-1 sm:grid-cols-3 gap-2">
                  {selectedProduct.variants.map((v, idx) => (
                    <button
                      key={v.id}
                      onClick={() => setSelectedVariantIndex(idx)}
                      className={`p-2.5 rounded-xl border text-left transition-all ${
                        selectedVariantIndex === idx
                          ? 'border-[#133c46] bg-[#f0f8f7] ring-1 ring-[#133c46]'
                          : 'border-stone-200 hover:border-stone-300 bg-white'
                      }`}
                    >
                      <div className="text-xs font-bold text-stone-900 truncate">{v.size}</div>
                      <div className="text-xs font-semibold text-[#133c46] mt-0.5 tabular-nums">₹{v.price}</div>
                    </button>
                  ))}
                </div>
              </div>

              {/* Loyalty Reward preview callout */}
              <div 
                onClick={openLoyaltyModal}
                className="p-3 bg-[#eef7f6] rounded-xl border border-[#c5e6e2] flex items-center justify-between cursor-pointer hover:bg-[#e4f3f1] transition-colors"
              >
                <div className="flex items-center gap-2">
                  <Award className="w-4 h-4 text-[#184650] shrink-0" />
                  <span className="text-xs font-semibold text-[#184650]">
                    Earn <span className="tabular-nums font-bold">{pointsForThis}</span> Ukusha Ocean Points with this bottle
                  </span>
                </div>
                <span className="text-[11px] font-bold text-[#184650] underline shrink-0">
                  View Rewards
                </span>
              </div>

              {/* Quantity Stepper & Add to Cart */}
              <div className="flex items-center gap-3 pt-2">
                <div className="flex items-center border border-stone-300 rounded-xl bg-white px-2 py-1.5 shrink-0">
                  <button
                    onClick={() => setQuantity(prev => Math.max(1, prev - 1))}
                    className="p-1 text-stone-500 hover:text-stone-900 disabled:opacity-40"
                    disabled={quantity <= 1}
                    aria-label="Decrease quantity"
                  >
                    <Minus className="w-3.5 h-3.5" />
                  </button>
                  <span className="px-3 text-xs font-bold text-stone-900 tabular-nums">
                    {quantity}
                  </span>
                  <button
                    onClick={() => setQuantity(prev => prev + 1)}
                    className="p-1 text-stone-500 hover:text-stone-900"
                    aria-label="Increase quantity"
                  >
                    <Plus className="w-3.5 h-3.5" />
                  </button>
                </div>

                <button
                  onClick={handleAddToCart}
                  disabled={!selectedProduct.inStock}
                  className={`flex-1 py-3 px-6 text-sm font-bold rounded-xl transition-all shadow-sm flex items-center justify-center gap-2 ${
                    addedSuccess
                      ? 'bg-emerald-700 text-white'
                      : selectedProduct.inStock
                      ? 'bg-[#133c46] hover:bg-[#0f2e36] text-white hover:translate-y-[-1px]'
                      : 'bg-stone-200 text-stone-400 cursor-not-allowed'
                  }`}
                >
                  {addedSuccess ? (
                    <>
                      <Check className="w-4 h-4" />
                      <span>Added to Bag!</span>
                    </>
                  ) : (
                    <>
                      <ShoppingBag className="w-4 h-4" />
                      <span>Add to Bag — ₹{activeVariant.price * quantity}</span>
                    </>
                  )}
                </button>
              </div>

              {/* Fast action if added */}
              {addedSuccess && (
                <div className="text-center pt-1 animate-fade-in">
                  <button
                    onClick={() => {
                      closeProductModal();
                      openCart();
                    }}
                    className="text-xs font-bold text-[#133c46] underline hover:opacity-80"
                  >
                    View Bag &amp; Proceed to Encrypted Checkout &rarr;
                  </button>
                </div>
              )}

              {/* Tabs for details */}
              <div className="pt-4 border-t border-stone-200">
                <div className="flex border-b border-stone-200 gap-4 text-xs font-semibold">
                  <button
                    onClick={() => setActiveDetailTab('benefits')}
                    className={`pb-2 border-b-2 transition-colors ${
                      activeDetailTab === 'benefits' ? 'border-[#133c46] text-[#133c46]' : 'border-transparent text-stone-500 hover:text-stone-800'
                    }`}
                  >
                    Benefits
                  </button>
                  <button
                    onClick={() => setActiveDetailTab('ingredients')}
                    className={`pb-2 border-b-2 transition-colors ${
                      activeDetailTab === 'ingredients' ? 'border-[#133c46] text-[#133c46]' : 'border-transparent text-stone-500 hover:text-stone-800'
                    }`}
                  >
                    Ingredients
                  </button>
                  <button
                    onClick={() => setActiveDetailTab('howTo')}
                    className={`pb-2 border-b-2 transition-colors ${
                      activeDetailTab === 'howTo' ? 'border-[#133c46] text-[#133c46]' : 'border-transparent text-stone-500 hover:text-stone-800'
                    }`}
                  >
                    How to Style
                  </button>
                </div>

                <div className="py-3 text-xs text-stone-600 leading-relaxed min-h-[90px]">
                  {activeDetailTab === 'benefits' && (
                    <p>{selectedProduct.description}</p>
                  )}

                  {activeDetailTab === 'ingredients' && (
                    <ul className="space-y-1.5 list-disc list-inside">
                      {selectedProduct.keyIngredients.map((ing, i) => (
                        <li key={i}>{ing}</li>
                      ))}
                    </ul>
                  )}

                  {activeDetailTab === 'howTo' && (
                    <ol className="space-y-1.5 list-decimal list-inside">
                      {selectedProduct.howToUse.map((step, i) => (
                        <li key={i}>{step}</li>
                      ))}
                    </ol>
                  )}
                </div>
              </div>

              {/* Security & Logistics Trust Seal */}
              <div className="grid grid-cols-2 gap-3 pt-3 border-t border-stone-100 text-[11px] text-stone-500">
                <div className="flex items-center gap-1.5">
                  <ShieldCheck className="w-3.5 h-3.5 text-[#133c46]" />
                  <span>256-Bit Encrypted Checkout</span>
                </div>
                <div className="flex items-center gap-1.5">
                  <Truck className="w-3.5 h-3.5 text-[#133c46]" />
                  <span>Courier Pickup from Warehouse</span>
                </div>
              </div>

            </div>
          </div>

        </div>
      </div>
    </div>
  );
};
