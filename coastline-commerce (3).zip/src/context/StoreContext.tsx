import React, { createContext, useContext, useState, useEffect } from 'react';
import { 
  Product, 
  ProductVariant, 
  CartItem, 
  Order, 
  OrderStatus,
  CourierPickupDetails, 
  InventoryItem, 
  CustomerProfile, 
  LoyaltyReward 
} from '../types';
import { 
  INITIAL_PRODUCTS, 
  INITIAL_ORDERS, 
  INITIAL_INVENTORY, 
  INITIAL_CUSTOMERS, 
  INITIAL_LOYALTY_REWARDS,
  DEFAULT_CUSTOMER 
} from '../data/mockData';

interface StoreContextType {
  // Products
  products: Product[];
  selectedProduct: Product | null;
  openProductModal: (product: Product) => void;
  closeProductModal: () => void;
  updateProduct: (productId: string, updatedFields: Partial<Product>) => void;
  updateProductVariant: (productId: string, variantId: string, updatedFields: Partial<ProductVariant>) => void;

  // Cart
  cart: CartItem[];
  isCartOpen: boolean;
  openCart: () => void;
  closeCart: () => void;
  addToCart: (product: Product, variant: ProductVariant, quantity?: number) => void;
  removeFromCart: (cartItemId: string) => void;
  updateQuantity: (cartItemId: string, newQty: number) => void;
  clearCart: () => void;
  cartSubtotal: number;
  discountCode: string;
  discountAmount: number;
  applyPromoCode: (code: string) => { success: boolean; message: string };
  removePromoCode: () => void;
  cartTotal: number;
  pointsToEarn: number;

  // Loyalty Program
  customer: CustomerProfile;
  loyaltyRewards: LoyaltyReward[];
  isLoyaltyModalOpen: boolean;
  openLoyaltyModal: () => void;
  closeLoyaltyModal: () => void;
  redeemReward: (reward: LoyaltyReward) => { success: boolean; message: string; code?: string };
  addBonusPoints: (points: number, reason: string) => void;

  // Checkout & Orders
  isCheckoutOpen: boolean;
  openCheckout: () => void;
  closeCheckout: () => void;
  placeOrder: (orderPayload: {
    customer: Order['customer'];
    paymentMethod: 'card' | 'upi' | 'apple_pay' | 'google_pay' | 'cod';
    cardDetails?: { number: string; expiry: string; cvv: string; holder: string };
    upiId?: string;
    carrier: CourierPickupDetails['carrier'];
    pickupNotes?: string;
  }) => Promise<Order>;
  activeOrder: Order | null;
  isOrderModalOpen: boolean;
  openOrderModal: (order: Order) => void;
  closeOrderModal: () => void;
  orders: Order[];
  // Order Tracker Modal
  isTrackerOpen: boolean;
  openTracker: (initialOrderNumber?: string) => void;
  closeTracker: () => void;
  trackerInitialOrderNumber: string;

  // Owner Authentication & Admin (Restricted - Customers Cannot Access)
  isOwnerAuthenticated: boolean;
  isOwnerLoginModalOpen: boolean;
  openOwnerLoginModal: () => void;
  closeOwnerLoginModal: () => void;
  loginOwner: (passcode: string) => boolean;
  logoutOwner: () => void;
  isAdminOpen: boolean;
  toggleAdmin: () => void;
  adminTab: 'products' | 'orders' | 'inventory' | 'analytics' | 'customers' | 'dispatch';
  setAdminTab: (tab: 'products' | 'orders' | 'inventory' | 'analytics' | 'customers' | 'dispatch') => void;
  updateOrderStatus: (orderId: string, status: OrderStatus) => void;
  scheduleCourierPickup: (orderId: string, carrier: CourierPickupDetails['carrier'], pickupTime: string, notes?: string) => void;
  inventory: InventoryItem[];
  updateInventoryStock: (variantId: string, delta: number) => void;
  setInventoryStock: (variantId: string, newStock: number) => void;
  customers: CustomerProfile[];
}

const StoreContext = createContext<StoreContextType | undefined>(undefined);

export const StoreProvider: React.FC<{ children: React.ReactNode }> = ({ children }) => {
  // Products state with localStorage persistence and INR migration check
  const [products, setProducts] = useState<Product[]>(() => {
    try {
      const saved = localStorage.getItem('ukusha_products');
      if (saved) {
        const parsed = JSON.parse(saved);
        if (parsed.length > 0 && parsed[0].price < 100) {
          localStorage.removeItem('ukusha_products');
          return INITIAL_PRODUCTS;
        }
        return parsed;
      }
      return INITIAL_PRODUCTS;
    } catch {
      return INITIAL_PRODUCTS;
    }
  });
  const [selectedProduct, setSelectedProduct] = useState<Product | null>(null);

  // Save products to localStorage on change
  useEffect(() => {
    try {
      localStorage.setItem('ukusha_products', JSON.stringify(products));
    } catch {
      // ignore
    }
  }, [products]);

  const updateProduct = (productId: string, updatedFields: Partial<Product>) => {
    setProducts(prev =>
      prev.map(p => {
        if (p.id === productId) {
          const updated = { ...p, ...updatedFields };
          // If selected product is open, keep in sync
          if (selectedProduct && selectedProduct.id === productId) {
            setSelectedProduct(updated);
          }
          return updated;
        }
        return p;
      })
    );
  };

  const updateProductVariant = (productId: string, variantId: string, updatedFields: Partial<ProductVariant>) => {
    setProducts(prev =>
      prev.map(p => {
        if (p.id === productId) {
          const nextVariants = p.variants.map(v => (v.id === variantId ? { ...v, ...updatedFields } : v));
          // If first variant price changed, update base product price
          const updated = {
            ...p,
            variants: nextVariants,
            price: nextVariants[0]?.price ?? p.price,
            totalStock: nextVariants.reduce((sum, v) => sum + v.stock, 0)
          };
          if (selectedProduct && selectedProduct.id === productId) {
            setSelectedProduct(updated);
          }
          return updated;
        }
        return p;
      })
    );
  };

  // Cart
  const [cart, setCart] = useState<CartItem[]>(() => {
    try {
      const saved = localStorage.getItem('ukusha_cart');
      if (saved) {
        const parsed = JSON.parse(saved);
        if (parsed.length > 0 && parsed[0].selectedVariant?.price < 100) {
          localStorage.removeItem('ukusha_cart');
          return [];
        }
        return parsed;
      }
      return [];
    } catch {
      return [];
    }
  });
  const [isCartOpen, setIsCartOpen] = useState(false);
  const [discountCode, setDiscountCode] = useState<string>('');
  const [discountAmount, setDiscountAmount] = useState<number>(0);

  // Loyalty Program
  const [customer, setCustomer] = useState<CustomerProfile>(() => {
    try {
      const saved = localStorage.getItem('ukusha_customer');
      if (saved) {
        const parsed = JSON.parse(saved);
        if (parsed.country !== 'India' || parsed.totalSpend < 500) {
          localStorage.removeItem('ukusha_customer');
          return DEFAULT_CUSTOMER;
        }
        return parsed;
      }
      return DEFAULT_CUSTOMER;
    } catch {
      return DEFAULT_CUSTOMER;
    }
  });
  const [loyaltyRewards] = useState<LoyaltyReward[]>(INITIAL_LOYALTY_REWARDS);
  const [isLoyaltyModalOpen, setIsLoyaltyModalOpen] = useState(false);

  // Orders
  const [orders, setOrders] = useState<Order[]>(() => {
    try {
      const saved = localStorage.getItem('ukusha_orders');
      if (saved) {
        const parsed = JSON.parse(saved);
        if (parsed.length > 0 && parsed[0].total < 500) {
          localStorage.removeItem('ukusha_orders');
          return INITIAL_ORDERS;
        }
        return parsed;
      }
      return INITIAL_ORDERS;
    } catch {
      return INITIAL_ORDERS;
    }
  });
  const [activeOrder, setActiveOrder] = useState<Order | null>(null);
  const [isOrderModalOpen, setIsOrderModalOpen] = useState(false);
  const [isCheckoutOpen, setIsCheckoutOpen] = useState(false);

  // Dedicated Order Tracker Modal State
  const [isTrackerOpen, setIsTrackerOpen] = useState(false);
  const [trackerInitialOrderNumber, setTrackerInitialOrderNumber] = useState('');

  const openTracker = (initialOrderNumber?: string) => {
    if (initialOrderNumber) {
      setTrackerInitialOrderNumber(initialOrderNumber);
    }
    setIsTrackerOpen(true);
  };

  const closeTracker = () => {
    setIsTrackerOpen(false);
  };

  // Inventory
  const [inventory, setInventory] = useState<InventoryItem[]>(() => {
    try {
      const saved = localStorage.getItem('ukusha_inventory');
      if (saved) {
        const parsed = JSON.parse(saved);
        if (parsed.length > 0 && parsed[0].retailPrice < 100) {
          localStorage.removeItem('ukusha_inventory');
          return INITIAL_INVENTORY;
        }
        return parsed;
      }
      return INITIAL_INVENTORY;
    } catch {
      return INITIAL_INVENTORY;
    }
  });

  // Admin Dashboard State & Store Owner Authentication
  const [isAdminOpen, setIsAdminOpen] = useState(false);
  const [adminTab, setAdminTab] = useState<'products' | 'orders' | 'inventory' | 'analytics' | 'customers' | 'dispatch'>('products');
  
  // Store Owner Authentication State (persisted so store owner stays logged in on their device)
  const [isOwnerAuthenticated, setIsOwnerAuthenticated] = useState<boolean>(() => {
    try {
      return localStorage.getItem('ukusha_owner_auth') === 'true';
    } catch {
      return false;
    }
  });
  const [isOwnerLoginModalOpen, setIsOwnerLoginModalOpen] = useState(false);

  const openOwnerLoginModal = () => setIsOwnerLoginModalOpen(true);
  const closeOwnerLoginModal = () => setIsOwnerLoginModalOpen(false);

  const loginOwner = (passcode: string): boolean => {
    const trimmed = passcode.trim();
    // Accept owner PIN 'ukusha2026', 'admin123', or owner email 'rishitharpan77@gmail.com'
    if (trimmed === 'ukusha2026' || trimmed === 'admin123' || trimmed.toLowerCase() === 'rishitharpan77@gmail.com') {
      setIsOwnerAuthenticated(true);
      try {
        localStorage.setItem('ukusha_owner_auth', 'true');
      } catch {
        // ignore
      }
      setIsOwnerLoginModalOpen(false);
      setIsAdminOpen(true);
      return true;
    }
    return false;
  };

  const logoutOwner = () => {
    setIsOwnerAuthenticated(false);
    try {
      localStorage.removeItem('ukusha_owner_auth');
    } catch {
      // ignore
    }
    setIsAdminOpen(false);
  };

  const toggleAdmin = () => {
    if (isOwnerAuthenticated) {
      setIsAdminOpen(prev => !prev);
    } else {
      setIsOwnerLoginModalOpen(true);
    }
  };

  // Keyboard shortcut listener: Ctrl+Shift+A or Alt+Shift+A
  useEffect(() => {
    const handleKeyDown = (e: KeyboardEvent) => {
      if ((e.ctrlKey || e.metaKey || e.altKey) && e.shiftKey && (e.key === 'A' || e.key === 'a')) {
        e.preventDefault();
        if (isOwnerAuthenticated) {
          setIsAdminOpen(prev => !prev);
        } else {
          setIsOwnerLoginModalOpen(true);
        }
      }
    };

    window.addEventListener('keydown', handleKeyDown);
    return () => window.removeEventListener('keydown', handleKeyDown);
  }, [isOwnerAuthenticated]);

  // URL trigger check: if url has ?owner=true or #owner-login
  useEffect(() => {
    try {
      const searchParams = new URLSearchParams(window.location.search);
      if (searchParams.get('owner') === 'true' || window.location.hash === '#owner' || window.location.hash === '#admin') {
        if (isOwnerAuthenticated) {
          setIsAdminOpen(true);
        } else {
          setIsOwnerLoginModalOpen(true);
        }
      }
    } catch {
      // ignore
    }
  }, [isOwnerAuthenticated]);

  const [customers, setCustomers] = useState<CustomerProfile[]>(() => {
    try {
      const saved = localStorage.getItem('ukusha_all_customers');
      return saved ? JSON.parse(saved) : INITIAL_CUSTOMERS;
    } catch {
      return INITIAL_CUSTOMERS;
    }
  });

  // Save changes to localStorage
  useEffect(() => {
    try {
      localStorage.setItem('ukusha_cart', JSON.stringify(cart));
    } catch {
      // ignore
    }
  }, [cart]);

  useEffect(() => {
    try {
      localStorage.setItem('ukusha_orders', JSON.stringify(orders));
    } catch {
      // ignore
    }
  }, [orders]);

  useEffect(() => {
    try {
      localStorage.setItem('ukusha_customer', JSON.stringify(customer));
    } catch {
      // ignore
    }
  }, [customer]);

  useEffect(() => {
    try {
      localStorage.setItem('ukusha_inventory', JSON.stringify(inventory));
    } catch {
      // ignore
    }
  }, [inventory]);

  // Cart Calculations
  const cartSubtotal = cart.reduce((sum, item) => sum + item.selectedVariant.price * item.quantity, 0);

  // Recalculate discount based on current subtotal and code (in INR)
  useEffect(() => {
    if (!discountCode) {
      setDiscountAmount(0);
      return;
    }
    const code = discountCode.toUpperCase().trim();
    if (code === 'COASTAL15') {
      setDiscountAmount(Math.round(cartSubtotal * 0.15));
    } else if (code === 'WAVES20') {
      setDiscountAmount(Math.round(cartSubtotal * 0.20));
    } else if (code === 'UKUSHA250') {
      setDiscountAmount(Math.min(250, cartSubtotal));
    } else if (code === 'UKUSHA600') {
      setDiscountAmount(Math.min(600, cartSubtotal));
    } else if (code === 'FREEPOCKET') {
      setDiscountAmount(Math.min(899, cartSubtotal));
    } else if (code === 'UKUSHAVAULT1500') {
      setDiscountAmount(Math.min(1500, cartSubtotal));
    }
  }, [cartSubtotal, discountCode]);

  const cartTotal = Math.max(0, cartSubtotal - discountAmount);
  // Earn 1 point per ₹10 spent in India
  const pointsToEarn = Math.floor(cartTotal / 10);

  const openProductModal = (product: Product) => setSelectedProduct(product);
  const closeProductModal = () => setSelectedProduct(null);

  const openCart = () => setIsCartOpen(true);
  const closeCart = () => setIsCartOpen(false);

  const openLoyaltyModal = () => setIsLoyaltyModalOpen(true);
  const closeLoyaltyModal = () => setIsLoyaltyModalOpen(false);

  const openCheckout = () => {
    setIsCartOpen(false);
    setIsCheckoutOpen(true);
  };
  const closeCheckout = () => setIsCheckoutOpen(false);

  const openOrderModal = (order: Order) => {
    setActiveOrder(order);
    setIsOrderModalOpen(true);
  };
  const closeOrderModal = () => {
    setIsOrderModalOpen(false);
  };

  const addToCart = (product: Product, variant: ProductVariant, quantity: number = 1) => {
    setCart(prev => {
      const existingIndex = prev.findIndex(
        item => item.productId === product.id && item.selectedVariant.id === variant.id
      );
      if (existingIndex > -1) {
        const next = [...prev];
        next[existingIndex] = {
          ...next[existingIndex],
          quantity: next[existingIndex].quantity + quantity
        };
        return next;
      } else {
        const newItem: CartItem = {
          id: `item-${Date.now()}-${Math.random().toString(36).substr(2, 4)}`,
          productId: product.id,
          product,
          selectedVariant: variant,
          quantity
        };
        return [...prev, newItem];
      }
    });
    setIsCartOpen(true);
  };

  const removeFromCart = (cartItemId: string) => {
    setCart(prev => prev.filter(item => item.id !== cartItemId));
  };

  const updateQuantity = (cartItemId: string, newQty: number) => {
    if (newQty <= 0) {
      removeFromCart(cartItemId);
      return;
    }
    setCart(prev =>
      prev.map(item => (item.id === cartItemId ? { ...item, quantity: newQty } : item))
    );
  };

  const clearCart = () => {
    setCart([]);
    setDiscountCode('');
    setDiscountAmount(0);
  };

  const applyPromoCode = (code: string): { success: boolean; message: string } => {
    const cleanCode = code.trim().toUpperCase();
    if (!cleanCode) return { success: false, message: 'Please enter a voucher or promo code.' };

    if (cleanCode === 'COASTAL15') {
      setDiscountCode('COASTAL15');
      return { success: true, message: 'Coastal15 applied! 15% discount activated.' };
    }
    if (cleanCode === 'WAVES20') {
      setDiscountCode('WAVES20');
      return { success: true, message: 'Waves20 applied! 20% seasonal monsoon texturizer discount.' };
    }
    if (cleanCode === 'UKUSHA250') {
      setDiscountCode('UKUSHA250');
      return { success: true, message: 'Ukusha Rewards ₹250 discount applied!' };
    }
    if (cleanCode === 'UKUSHA600') {
      setDiscountCode('UKUSHA600');
      return { success: true, message: 'Ukusha Rewards ₹600 discount applied!' };
    }
    if (cleanCode === 'FREEPOCKET') {
      setDiscountCode('FREEPOCKET');
      return { success: true, message: 'Free 100ml pocket spray reward applied (₹899 off)!' };
    }
    if (cleanCode === 'UKUSHAVAULT1500') {
      setDiscountCode('UKUSHAVAULT1500');
      return { success: true, message: 'Ukusha Vault ₹1,500 VIP reward applied!' };
    }

    return { success: false, message: 'Invalid code. Try "COASTAL15" or redeem your points!' };
  };

  const removePromoCode = () => {
    setDiscountCode('');
    setDiscountAmount(0);
  };

  const redeemReward = (reward: LoyaltyReward): { success: boolean; message: string; code?: string } => {
    if (customer.pointsBalance < reward.pointsCost) {
      return { 
        success: false, 
        message: `You need ${reward.pointsCost - customer.pointsBalance} more points to redeem this reward.` 
      };
    }

    // Deduct points from customer profile
    const newBalance = customer.pointsBalance - reward.pointsCost;
    const newTx = {
      id: `tx-${Date.now()}`,
      date: new Date().toISOString().split('T')[0],
      description: `Redeemed ${reward.title} (${reward.code})`,
      pointsChange: -reward.pointsCost,
      type: 'redeemed_reward' as const
    };

    setCustomer(prev => ({
      ...prev,
      pointsBalance: newBalance,
      loyaltyHistory: [newTx, ...prev.loyaltyHistory]
    }));

    // Auto-apply promo code
    applyPromoCode(reward.code);

    return {
      success: true,
      message: `Successfully redeemed! Voucher code ${reward.code} has been applied to your cart.`,
      code: reward.code
    };
  };

  const addBonusPoints = (points: number, reason: string) => {
    const newTx = {
      id: `tx-${Date.now()}`,
      date: new Date().toISOString().split('T')[0],
      description: reason,
      pointsChange: points,
      type: 'admin_adjustment' as const
    };

    setCustomer(prev => ({
      ...prev,
      pointsBalance: prev.pointsBalance + points,
      lifetimePointsEarned: prev.lifetimePointsEarned + points,
      loyaltyHistory: [newTx, ...prev.loyaltyHistory]
    }));
  };

  // Place Order with automated courier pickup dispatch simulation
  const placeOrder = async (orderPayload: {
    customer: Order['customer'];
    paymentMethod: 'card' | 'upi' | 'apple_pay' | 'google_pay' | 'cod';
    cardDetails?: { number: string; expiry: string; cvv: string; holder: string };
    upiId?: string;
    carrier: CourierPickupDetails['carrier'];
    pickupNotes?: string;
  }): Promise<Order> => {
    const randomOrderNum = Math.floor(1000 + Math.random() * 9000);
    const orderId = `ord-${Date.now()}`;
    const orderNumber = `UK-${randomOrderNum}`;
    const shippingFee = cartSubtotal >= 999 ? 0 : 99; // Free shipping over ₹999 across India
    const taxAmount = Math.round(cartTotal * 0.18); // 18% GST (CGST 9% + SGST 9%)
    const total = cartTotal + shippingFee + taxAmount;
    const earnedPts = Math.floor(total / 10);

    // Generate real-looking client-side AES-256-GCM transaction token
    const tokenHex = Array.from({ length: 32 }, () => Math.floor(Math.random() * 16).toString(16)).join('');
    const encryptedToken = `AES-256-GCM::tok_in_${tokenHex.slice(0, 16)}`;

    // Generate automated Indian courier pickup request
    const pickupCarrier = orderPayload.carrier || 'BlueDart Ocean Express';
    const trackingPrefix = pickupCarrier.includes('BlueDart') ? 'BD' : pickupCarrier.includes('Delhivery') ? 'DLV' : 'DTDC';
    const trackingNum = `${trackingPrefix}-${Math.floor(1000 + Math.random() * 9000)}-${Math.floor(1000 + Math.random() * 9000)}-IND`;

    const newOrder: Order = {
      id: orderId,
      orderNumber,
      createdAt: new Date().toISOString(),
      customer: orderPayload.customer,
      items: [...cart],
      subtotal: cartSubtotal,
      discountAmount,
      discountCode: discountCode || undefined,
      shippingFee,
      taxAmount,
      total,
      pointsEarned: earnedPts,
      status: 'pickup_scheduled',
      payment: {
        method: orderPayload.paymentMethod,
        last4: orderPayload.cardDetails ? orderPayload.cardDetails.number.replace(/\s+/g, '').slice(-4) : undefined,
        upiId: orderPayload.upiId,
        cardBrand: orderPayload.paymentMethod === 'card' ? 'RuPay / Visa / Mastercard' : orderPayload.paymentMethod === 'upi' ? 'UPI (Instant NPCI Autopay)' : orderPayload.paymentMethod === 'apple_pay' ? 'Apple Pay' : orderPayload.paymentMethod === 'google_pay' ? 'Google Pay' : 'Cash on Delivery (Verified OTP)',
        encryptedTransactionToken: encryptedToken,
        pciComplianceVerified: true,
        timestamp: new Date().toISOString(),
        ipHash: 'sha256-' + tokenHex.slice(16, 28)
      },
      courierPickup: {
        carrier: pickupCarrier,
        pickupRequestId: `PKP-${trackingPrefix}-${Math.floor(10000 + Math.random() * 90000)}`,
        pickupWarehouse: 'Ukusha Sprays Fulfillment Hub - Bandra Coastal Dock, Mumbai 400050',
        pickupScheduledTime: 'Today at 4:30 PM (BlueDart / Delhivery driver queued)',
        trackingNumber: trackingNum,
        estimatedCustomerDropoff: 'Within 2-3 business days across India',
        status: 'Carrier En Route to Merchant',
        pickupNotes: orderPayload.pickupNotes || 'Eco-padded marine carton with fragile glass amber texturizers.'
      }
    };

    // Update customer points & lifetime spend
    const pointsTx = {
      id: `tx-ord-${orderNumber}`,
      date: new Date().toISOString().split('T')[0],
      description: `Earned from Order #${orderNumber}`,
      pointsChange: earnedPts,
      type: 'earned_purchase' as const,
      relatedOrderId: orderId
    };

    setCustomer(prev => {
      const newPts = prev.pointsBalance + earnedPts;
      const newLifetime = prev.lifetimePointsEarned + earnedPts;
      const newSpend = Math.round((prev.totalSpend + total) * 100) / 100;
      let newTier = prev.tier;
      if (newLifetime >= 1000) newTier = 'High Tide VIP';
      else if (newLifetime >= 400) newTier = 'Tide Explorer';

      return {
        ...prev,
        name: orderPayload.customer.name || prev.name,
        email: orderPayload.customer.email || prev.email,
        phone: orderPayload.customer.phone || prev.phone,
        address: orderPayload.customer.address || prev.address,
        city: orderPayload.customer.city || prev.city,
        state: orderPayload.customer.state || prev.state,
        postalCode: orderPayload.customer.postalCode || prev.postalCode,
        pointsBalance: newPts,
        lifetimePointsEarned: newLifetime,
        totalSpend: newSpend,
        ordersCount: prev.ordersCount + 1,
        tier: newTier,
        loyaltyHistory: [pointsTx, ...prev.loyaltyHistory]
      };
    });

    // Update inventory (decrement ordered quantities)
    setInventory(prev => {
      const updated = [...prev];
      cart.forEach(cartItem => {
        const itemIdx = updated.findIndex(inv => inv.variantId === cartItem.selectedVariant.id);
        if (itemIdx > -1) {
          updated[itemIdx] = {
            ...updated[itemIdx],
            availableStock: Math.max(0, updated[itemIdx].availableStock - cartItem.quantity),
            reservedStock: updated[itemIdx].reservedStock + cartItem.quantity
          };
        }
      });
      return updated;
    });

    // Append to orders
    setOrders(prev => [newOrder, ...prev]);

    // Also update CRM customer database
    setCustomers(prev => {
      const idx = prev.findIndex(c => c.email.toLowerCase() === orderPayload.customer.email.toLowerCase());
      if (idx > -1) {
        const updated = [...prev];
        updated[idx] = {
          ...updated[idx],
          totalSpend: updated[idx].totalSpend + total,
          ordersCount: updated[idx].ordersCount + 1,
          pointsBalance: updated[idx].pointsBalance + earnedPts
        };
        return updated;
      }
      return prev;
    });

    // Reset cart
    clearCart();
    setIsCheckoutOpen(false);

    // Open confirmation modal
    setActiveOrder(newOrder);
    setIsOrderModalOpen(true);

    return newOrder;
  };

  // Admin order status update
  const updateOrderStatus = (orderId: string, status: OrderStatus) => {
    setOrders(prev =>
      prev.map(ord => {
        if (ord.id === orderId) {
          let courierStatus = ord.courierPickup.status;
          if (status === 'pickup_scheduled') courierStatus = 'Carrier En Route to Merchant';
          if (status === 'carrier_picked_up') courierStatus = 'Picked Up from Merchant';
          if (status === 'in_transit') courierStatus = 'In Transit to Customer';
          if (status === 'out_for_delivery') courierStatus = 'In Transit to Customer';
          if (status === 'delivered') courierStatus = 'Delivered';

          return {
            ...ord,
            status,
            courierPickup: {
              ...ord.courierPickup,
              status: courierStatus
            }
          };
        }
        return ord;
      })
    );
  };

  // Store Owner: schedule courier pickup from merchant to customer
  const scheduleCourierPickup = (
    orderId: string, 
    carrier: CourierPickupDetails['carrier'], 
    pickupTime: string, 
    notes?: string
  ) => {
    setOrders(prev =>
      prev.map(ord => {
        if (ord.id === orderId) {
          const carrierPrefix = carrier.includes('FedEx') ? 'FX' : carrier.includes('BlueDart') ? 'BD' : 'DHL';
          const newTracking = `${carrierPrefix}-${Math.floor(1000 + Math.random() * 9000)}-${Math.floor(1000 + Math.random() * 9000)}-EXP`;
          return {
            ...ord,
            status: 'pickup_scheduled',
            courierPickup: {
              ...ord.courierPickup,
              carrier,
              pickupScheduledTime: pickupTime,
              trackingNumber: newTracking,
              status: 'Carrier En Route to Merchant',
              pickupNotes: notes || ord.courierPickup.pickupNotes
            }
          };
        }
        return ord;
      })
    );
  };

  // Inventory updates
  const updateInventoryStock = (variantId: string, delta: number) => {
    setInventory(prev =>
      prev.map(item =>
        item.variantId === variantId
          ? { ...item, availableStock: Math.max(0, item.availableStock + delta) }
          : item
      )
    );
  };

  const setInventoryStock = (variantId: string, newStock: number) => {
    setInventory(prev =>
      prev.map(item =>
        item.variantId === variantId
          ? { ...item, availableStock: Math.max(0, newStock) }
          : item
      )
    );
  };

  return (
    <StoreContext.Provider
      value={{
        products,
        selectedProduct,
        openProductModal,
        closeProductModal,
        updateProduct,
        updateProductVariant,
        cart,
        isCartOpen,
        openCart,
        closeCart,
        addToCart,
        removeFromCart,
        updateQuantity,
        clearCart,
        cartSubtotal,
        discountCode,
        discountAmount,
        applyPromoCode,
        removePromoCode,
        cartTotal,
        pointsToEarn,
        customer,
        loyaltyRewards,
        isLoyaltyModalOpen,
        openLoyaltyModal,
        closeLoyaltyModal,
        redeemReward,
        addBonusPoints,
        isCheckoutOpen,
        openCheckout,
        closeCheckout,
        placeOrder,
        activeOrder,
        isOrderModalOpen,
        openOrderModal,
        closeOrderModal,
        orders,
        isTrackerOpen,
        openTracker,
        closeTracker,
        trackerInitialOrderNumber,
        isOwnerAuthenticated,
        isOwnerLoginModalOpen,
        openOwnerLoginModal,
        closeOwnerLoginModal,
        loginOwner,
        logoutOwner,
        isAdminOpen,
        toggleAdmin,
        adminTab,
        setAdminTab,
        updateOrderStatus,
        scheduleCourierPickup,
        inventory,
        updateInventoryStock,
        setInventoryStock,
        customers
      }}
    >
      {children}
    </StoreContext.Provider>
  );
};

export const useStore = () => {
  const context = useContext(StoreContext);
  if (!context) {
    throw new Error('useStore must be used within a StoreProvider');
  }
  return context;
};
