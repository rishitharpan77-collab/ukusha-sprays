import { Product, LoyaltyReward, Order, InventoryItem, CustomerProfile } from '../types';

export const HERO_IMAGE = '/src/assets/images/hero_coastal_sea_salt_1793156668234.jpg';
export const PRODUCT_IMG_1 = '/src/assets/images/product_original_salt_spray_1793156669110.jpg';
export const PRODUCT_IMG_2 = '/src/assets/images/product_driftwood_cedar_spray_1793156670085.jpg';
export const PRODUCT_IMG_3 = '/src/assets/images/product_wave_light_spray_1793156669896.jpg';

export const INITIAL_PRODUCTS: Product[] = [
  {
    id: 'prod-original',
    name: 'Ukusha Original Sea Salt & Botanical Spray',
    subtitle: 'Wild Atlantic minerals & calming lavender mist',
    tagline: 'The iconic coastal texturizer that started it all.',
    category: 'original',
    price: 1499,
    originalPrice: 1899,
    rating: 4.9,
    reviewsCount: 382,
    image: PRODUCT_IMG_1,
    gallery: [PRODUCT_IMG_1, HERO_IMAGE, PRODUCT_IMG_2],
    description: 'Formulated by Ukusha Sprays from cold Atlantic tide pools, our Original Spray infuses magnesium-rich sea salt crystals with organic French lavender, aloe leaf juice, and nutrient-dense kelp bioferment. Delivers effortless, matte wind-blown separation without stiff or sticky residue.',
    holdLevel: 'Medium Textured',
    finish: 'Matte Beach Natural',
    scentProfile: {
      top: 'Crisp Bergamot & Salty Ocean Air',
      heart: 'Organic Wild French Lavender',
      base: 'Sun-Bleached Sandalwood & Amber'
    },
    keyIngredients: [
      'Unrefined Atlantic Sea Salt (Rich in Magnesium & Potassium)',
      'Organic Kelp Bioferment (Strengthens follicular elasticity)',
      'Cold-Pressed Aloe Vera Leaf Juice (Hydrates & counters dryness)',
      'Hydrolyzed Rice Protein (Natural volume & cuticle repair)'
    ],
    howToUse: [
      'Shake well before use to distribute natural mineral deposits.',
      'Mist evenly across damp or towel-dried hair from roots to ends (5-8 pumps).',
      'Scrunch upward with fingers to encourage natural wave formations.',
      'Allow to air-dry naturally for relaxed beach waves or diffuse for amplified volume.'
    ],
    variants: [
      { id: 'v-orig-100', size: 'Travel Pocket (100ml)', volumeMl: 100, price: 899, stock: 45 },
      { id: 'v-orig-200', size: 'Signature Bottle (200ml)', volumeMl: 200, price: 1499, originalPrice: 1899, stock: 120 },
      { id: 'v-orig-duo', size: 'Double Coast Bundle (2 x 200ml)', volumeMl: 400, price: 2499, originalPrice: 2999, stock: 38 }
    ],
    inStock: true,
    totalStock: 203,
    isBestSeller: true,
    badge: 'Award Winner'
  },
  {
    id: 'prod-driftwood',
    name: 'Ukusha Driftwood & Cedarwood Ocean Mist',
    subtitle: 'High-hold gritty volume with coastal cedar & pine needle',
    tagline: 'Deep mountain coastal pine meets the crashing surf.',
    category: 'driftwood',
    price: 1699,
    originalPrice: 1999,
    rating: 4.8,
    reviewsCount: 219,
    image: PRODUCT_IMG_2,
    gallery: [PRODUCT_IMG_2, HERO_IMAGE, PRODUCT_IMG_1],
    description: 'Engineered by Ukusha Sprays for thicker textures and anyone craving gritty, moldable grip. Rich amber glass protects our hand-distilled Alaskan cedarwood and coastal pine essential oils blended with heavy mineral grey sea salt.',
    holdLevel: 'Firm Gritty',
    finish: 'Wind-Blown Matte',
    scentProfile: {
      top: 'Crushed Pine Needle & Sea Foam',
      heart: 'Atlas Cedar & Coastal Cypress',
      base: 'Earthy Vetiver & Damp Driftwood'
    },
    keyIngredients: [
      'Brittany Grey Sea Salt (Rich trace mineral matrix)',
      'Wildcrafted Cedarwood & Cypress Needle Essential Oils',
      'Dead Sea Mineral Concentrate (Root-lifting structure)',
      'Golden Jojoba Oil (Weightless lipid balance)'
    ],
    howToUse: [
      'Spritz directly into damp roots for maximum structural lift.',
      'Work through mid-lengths for tactile gritty texture.',
      'Blow-dry on low heat for dramatic 3D volume or let ocean air set it.'
    ],
    variants: [
      { id: 'v-drift-100', size: 'Travel Flask (100ml)', volumeMl: 100, price: 999, stock: 32 },
      { id: 'v-drift-200', size: 'Signature Bottle (200ml)', volumeMl: 200, price: 1699, originalPrice: 1999, stock: 84 },
      { id: 'v-drift-duo', size: 'Duo Pack (2 x 200ml)', volumeMl: 400, price: 2799, originalPrice: 3399, stock: 22 }
    ],
    inStock: true,
    totalStock: 138,
    isBestSeller: false,
    badge: 'Maximum Hold'
  },
  {
    id: 'prod-wave-light',
    name: 'Ukusha Wave Whisper Salon Texture Mist',
    subtitle: 'Weightless micro-mist for fine hair & subtle definition',
    tagline: 'Light-as-air ocean spray formulated for weightless movement.',
    category: 'waves',
    price: 1399,
    originalPrice: 1699,
    rating: 4.9,
    reviewsCount: 164,
    image: PRODUCT_IMG_3,
    gallery: [PRODUCT_IMG_3, HERO_IMAGE, PRODUCT_IMG_1],
    description: 'Designed specifically for fine or delicate strands that get easily weighed down. Uses microscopic oceanic sea mineral dispersion with cucumber distillate and bamboo silica for soft, touchable waves with zero crunch.',
    holdLevel: 'Light Natural',
    finish: 'Satin Hydrated',
    scentProfile: {
      top: 'Chilled Cucumber & Ozone Breeze',
      heart: 'White Water Lily & Neroli',
      base: 'Clean Sheer Musk & Salt Petals'
    },
    keyIngredients: [
      'Micro-Atomized Deep Ocean Salts',
      'Organic Cucumber Distillate & Aloe',
      'Fermented Bamboo Leaf Silica (Natural elasticity)',
      'Green Tea Extract (Daily UV and pollution protection)'
    ],
    howToUse: [
      'Can be applied onto dry hair as an instant morning wave revival.',
      'Mist from 8-10 inches away over damp hair for light separation.',
      'Twist small sections around fingers and let dry for effortless curl ribbons.'
    ],
    variants: [
      { id: 'v-wave-100', size: 'Purse Size (100ml)', volumeMl: 100, price: 799, stock: 50 },
      { id: 'v-wave-200', size: 'Salon Bottle (200ml)', volumeMl: 200, price: 1399, originalPrice: 1699, stock: 95 }
    ],
    inStock: true,
    totalStock: 145,
    isBestSeller: false,
    badge: 'Zero Crunch'
  },
  {
    id: 'prod-vault-bundle',
    name: 'The Ukusha Mineral Trilogy Vault',
    subtitle: 'Full 3-bottle ritual set with artisan sandalwood comb',
    tagline: 'Complete coastal styling suite for every weather and mood.',
    category: 'bundle',
    price: 3699,
    originalPrice: 4499,
    rating: 5.0,
    reviewsCount: 94,
    image: HERO_IMAGE,
    gallery: [HERO_IMAGE, PRODUCT_IMG_1, PRODUCT_IMG_2, PRODUCT_IMG_3],
    description: 'Experience the entire Ukusha repertoire: Original Mist for daily beach body, Driftwood & Cedarwood for gritty windswept texture, and Wave Whisper for featherlight satin finish. Includes custom hand-carved organic sandalwood styling comb.',
    holdLevel: 'Medium Textured',
    finish: 'Matte Beach Natural',
    scentProfile: {
      top: 'Atlantic Bergamot & Ocean Ozone',
      heart: 'Cedarwood, French Lavender & Water Lily',
      base: 'Coastline Amber, Driftwood & Sheer Musk'
    },
    keyIngredients: [
      'Full spectrum of Atlantic, Grey, and Deep Ocean salts',
      '3 complete botanical extracts and essential oil blends',
      'Complimentary Hand-carved Sandalwood Wide-Tooth Comb'
    ],
    howToUse: [
      'Layer Wave Whisper on ends and Driftwood at roots for multi-dimensional volume.',
      'Keep Ukusha Original in gym or travel bag for quick resets.'
    ],
    variants: [
      { id: 'v-vault-std', size: 'Complete Trilogy Set (3 x 200ml + Comb)', volumeMl: 600, price: 3699, originalPrice: 4499, stock: 35 }
    ],
    inStock: true,
    totalStock: 35,
    isBestSeller: true,
    badge: 'Best Value (-20%)'
  }
];

export const INITIAL_LOYALTY_REWARDS: LoyaltyReward[] = [
  {
    id: 'rew-10-off',
    title: '₹250 Off Any Ukusha Spray',
    description: 'Redeem 200 points for an instant ₹250 discount voucher on your order.',
    pointsCost: 200,
    discountType: 'fixed',
    discountValue: 250,
    code: 'UKUSHA250',
    minOrderValue: 1000
  },
  {
    id: 'rew-25-off',
    title: '₹600 Off Signature Order',
    description: 'Redeem 400 points for ₹600 off any order over ₹2,000.',
    pointsCost: 400,
    discountType: 'fixed',
    discountValue: 600,
    code: 'UKUSHA600',
    minOrderValue: 2000
  },
  {
    id: 'rew-free-mist',
    title: 'Free Pocket Spray (100ml)',
    description: 'Redeem 600 points to receive a complimentary 100ml pocket spray (worth ₹899) and free courier delivery.',
    pointsCost: 600,
    discountType: 'free_product',
    discountValue: 899,
    code: 'FREEPOCKET',
    minOrderValue: 1200
  },
  {
    id: 'rew-60-vault',
    title: '₹1,500 Ukusha Vault Voucher',
    description: 'Exclusive tier perk: ₹1,500 off orders of ₹3,500 or more.',
    pointsCost: 1000,
    discountType: 'fixed',
    discountValue: 1500,
    code: 'UKUSHAVAULT1500',
    minOrderValue: 3500
  }
];

export const DEFAULT_CUSTOMER: CustomerProfile = {
  id: 'cust-demo-01',
  name: 'Ananya Deshmukh',
  email: 'ananya.deshmukh@coastalwaves.in',
  phone: '+91 98201 44521',
  address: '42 Carter Road, Bandra West',
  city: 'Mumbai',
  state: 'Maharashtra',
  postalCode: '400050',
  country: 'India',
  pointsBalance: 480,
  lifetimePointsEarned: 880,
  tier: 'Tide Explorer',
  totalSpend: 5497.00,
  ordersCount: 3,
  loyaltyHistory: [
    {
      id: 'tx-01',
      date: '2026-09-14',
      description: 'Welcome to Ukusha Coastal Rewards Circle',
      pointsChange: 100,
      type: 'welcome_bonus'
    },
    {
      id: 'tx-02',
      date: '2026-09-18',
      description: 'Earned from Order #UK-7741',
      pointsChange: 190,
      type: 'earned_purchase',
      relatedOrderId: 'ord-01'
    },
    {
      id: 'tx-03',
      date: '2026-10-04',
      description: 'Earned from Order #UK-8120',
      pointsChange: 190,
      type: 'earned_purchase',
      relatedOrderId: 'ord-02'
    }
  ]
};

export const INITIAL_ORDERS: Order[] = [
  {
    id: 'ord-1042',
    orderNumber: 'UK-1042',
    createdAt: '2026-10-27T18:32:00Z',
    customer: {
      name: 'Ananya Deshmukh',
      email: 'ananya.deshmukh@coastalwaves.in',
      phone: '+91 98201 44521',
      address: '42 Carter Road, Bandra West',
      city: 'Mumbai',
      state: 'Maharashtra',
      postalCode: '400050',
      country: 'India'
    },
    items: [
      {
        id: 'cart-init-1',
        productId: 'prod-original',
        product: INITIAL_PRODUCTS[0],
        selectedVariant: INITIAL_PRODUCTS[0].variants[1],
        quantity: 1
      },
      {
        id: 'cart-init-2',
        productId: 'prod-driftwood',
        product: INITIAL_PRODUCTS[1],
        selectedVariant: INITIAL_PRODUCTS[1].variants[1],
        quantity: 1
      }
    ],
    subtotal: 3198.00,
    discountAmount: 479.70,
    discountCode: 'COASTAL15',
    shippingFee: 0,
    taxAmount: 489.29,
    total: 3207.59,
    pointsEarned: 320,
    status: 'pickup_scheduled',
    payment: {
      method: 'upi',
      upiId: 'ananya@oksbi',
      encryptedTransactionToken: 'AES-256-GCM::upi_e4a8b79c3d1f021e',
      pciComplianceVerified: true,
      timestamp: '2026-10-27T18:32:15Z',
      ipHash: 'sha256-98fae2...'
    },
    courierPickup: {
      carrier: 'BlueDart Ocean Express',
      pickupRequestId: 'PKP-BD-99412',
      pickupWarehouse: 'Ukusha Sprays Fulfillment Hub - Bandra Coastal Dock, Mumbai',
      pickupScheduledTime: 'Tomorrow, Oct 28 between 10:00 AM - 1:00 PM',
      trackingNumber: 'BD-8841-9231-MUM',
      estimatedCustomerDropoff: 'Oct 30, 2026 by End of Day',
      status: 'Carrier En Route to Merchant',
      pickupNotes: 'Packed in eco-friendly sea-algae padded carton. Fragile glass bottles.'
    }
  },
  {
    id: 'ord-1039',
    orderNumber: 'UK-1039',
    createdAt: '2026-10-26T14:15:00Z',
    customer: {
      name: 'Rohan Mehra',
      email: 'rohan.mehra@goasurfing.in',
      phone: '+91 97654 32109',
      address: '14 Anjuna Coastal Road',
      city: 'Goa',
      state: 'Goa',
      postalCode: '403509',
      country: 'India'
    },
    items: [
      {
        id: 'cart-init-3',
        productId: 'prod-vault-bundle',
        product: INITIAL_PRODUCTS[3],
        selectedVariant: INITIAL_PRODUCTS[3].variants[0],
        quantity: 1
      }
    ],
    subtotal: 3699.00,
    discountAmount: 0,
    shippingFee: 0,
    taxAmount: 665.82,
    total: 4364.82,
    pointsEarned: 436,
    status: 'carrier_picked_up',
    payment: {
      method: 'card',
      last4: '1099',
      cardBrand: 'Visa (HDFC Bank)',
      encryptedTransactionToken: 'AES-256-GCM::card_token_8871320',
      pciComplianceVerified: true,
      timestamp: '2026-10-26T14:15:30Z',
      ipHash: 'sha256-11f8e4...'
    },
    courierPickup: {
      carrier: 'Delhivery Coastal Priority',
      pickupRequestId: 'PKP-DEL-77190',
      pickupWarehouse: 'Ukusha Sprays Fulfillment Hub - Bandra Coastal Dock, Mumbai',
      pickupScheduledTime: 'Oct 27, 2026 at 11:30 AM (Completed)',
      trackingNumber: 'DLV-9041-5521-GOA',
      estimatedCustomerDropoff: 'Oct 28, 2026',
      status: 'In Transit to Customer',
      pickupNotes: 'Package collected from merchant dispatch bay by driver Rajesh Kumar.'
    }
  },
  {
    id: 'ord-1025',
    orderNumber: 'UK-1025',
    createdAt: '2026-10-24T09:40:00Z',
    customer: {
      name: 'Kavita Nair',
      email: 'kavita.nair@beachybliss.in',
      phone: '+91 94471 88290',
      address: '88 Marine Drive',
      city: 'Kochi',
      state: 'Kerala',
      postalCode: '682011',
      country: 'India'
    },
    items: [
      {
        id: 'cart-init-4',
        productId: 'prod-wave-light',
        product: INITIAL_PRODUCTS[2],
        selectedVariant: INITIAL_PRODUCTS[2].variants[1],
        quantity: 2
      }
    ],
    subtotal: 2798.00,
    discountAmount: 250.00,
    discountCode: 'UKUSHA250',
    shippingFee: 0,
    taxAmount: 458.64,
    total: 3006.64,
    pointsEarned: 300,
    pointsRedeemed: 200,
    status: 'delivered',
    payment: {
      method: 'upi',
      upiId: 'kavita@paytm',
      encryptedTransactionToken: 'AES-256-GCM::upi_kav_4412098',
      pciComplianceVerified: true,
      timestamp: '2026-10-24T09:40:44Z',
      ipHash: 'sha256-77e2d9...'
    },
    courierPickup: {
      carrier: 'BlueDart Ocean Express',
      pickupRequestId: 'PKP-BD-33109',
      pickupWarehouse: 'Ukusha Sprays Fulfillment Hub - Bandra Coastal Dock, Mumbai',
      pickupScheduledTime: 'Oct 24, 2026 at 2:00 PM',
      trackingNumber: 'BD-9921-0012-KOC',
      estimatedCustomerDropoff: 'Oct 26, 2026',
      status: 'Delivered',
      pickupNotes: 'Delivered to recipient with digital OTP confirmation.'
    }
  }
];

export const INITIAL_INVENTORY: InventoryItem[] = [
  {
    productId: 'prod-original',
    variantId: 'v-orig-100',
    productName: 'Ukusha Original Sea Salt Spray',
    variantSize: 'Travel Pocket (100ml)',
    sku: 'UK-ORIG-100ML',
    availableStock: 45,
    reservedStock: 4,
    lowStockThreshold: 15,
    costPrice: 220.00,
    retailPrice: 899.00
  },
  {
    productId: 'prod-original',
    variantId: 'v-orig-200',
    productName: 'Ukusha Original Sea Salt Spray',
    variantSize: 'Signature Bottle (200ml)',
    sku: 'UK-ORIG-200ML',
    availableStock: 120,
    reservedStock: 12,
    lowStockThreshold: 25,
    costPrice: 380.00,
    retailPrice: 1499.00
  },
  {
    productId: 'prod-original',
    variantId: 'v-orig-duo',
    productName: 'Ukusha Original Sea Salt Spray',
    variantSize: 'Double Coast Bundle (2x200ml)',
    sku: 'UK-ORIG-DUO',
    availableStock: 38,
    reservedStock: 3,
    lowStockThreshold: 10,
    costPrice: 650.00,
    retailPrice: 2499.00
  },
  {
    productId: 'prod-driftwood',
    variantId: 'v-drift-100',
    productName: 'Ukusha Driftwood & Cedarwood Ocean Mist',
    variantSize: 'Travel Flask (100ml)',
    sku: 'UK-DRIFT-100ML',
    availableStock: 32,
    reservedStock: 2,
    lowStockThreshold: 10,
    costPrice: 240.00,
    retailPrice: 999.00
  },
  {
    productId: 'prod-driftwood',
    variantId: 'v-drift-200',
    productName: 'Ukusha Driftwood & Cedarwood Ocean Mist',
    variantSize: 'Signature Bottle (200ml)',
    sku: 'UK-DRIFT-200ML',
    availableStock: 84,
    reservedStock: 6,
    lowStockThreshold: 20,
    costPrice: 420.00,
    retailPrice: 1699.00
  },
  {
    productId: 'prod-wave-light',
    variantId: 'v-wave-100',
    productName: 'Ukusha Wave Whisper Salon Texture Mist',
    variantSize: 'Purse Size (100ml)',
    sku: 'UK-WAVE-100ML',
    availableStock: 50,
    reservedStock: 5,
    lowStockThreshold: 15,
    costPrice: 210.00,
    retailPrice: 799.00
  },
  {
    productId: 'prod-wave-light',
    variantId: 'v-wave-200',
    productName: 'Ukusha Wave Whisper Salon Texture Mist',
    variantSize: 'Salon Bottle (200ml)',
    sku: 'UK-WAVE-200ML',
    availableStock: 95,
    reservedStock: 8,
    lowStockThreshold: 20,
    costPrice: 350.00,
    retailPrice: 1399.00
  },
  {
    productId: 'prod-vault-bundle',
    variantId: 'v-vault-std',
    productName: 'The Ukusha Mineral Trilogy Vault',
    variantSize: 'Trilogy Set (3x200ml + Comb)',
    sku: 'UK-VAULT-TRIO',
    availableStock: 35,
    reservedStock: 3,
    lowStockThreshold: 10,
    costPrice: 950.00,
    retailPrice: 3699.00
  }
];

export const INITIAL_CUSTOMERS: CustomerProfile[] = [
  DEFAULT_CUSTOMER,
  {
    id: 'cust-02',
    name: 'Rohan Mehra',
    email: 'rohan.mehra@goasurfing.in',
    phone: '+91 97654 32109',
    address: '14 Anjuna Coastal Road',
    city: 'Goa',
    state: 'Goa',
    postalCode: '403509',
    country: 'India',
    pointsBalance: 612,
    lifetimePointsEarned: 912,
    tier: 'High Tide VIP',
    totalSpend: 11450.00,
    ordersCount: 4,
    loyaltyHistory: []
  },
  {
    id: 'cust-03',
    name: 'Kavita Nair',
    email: 'kavita.nair@beachybliss.in',
    phone: '+91 94471 88290',
    address: '88 Marine Drive',
    city: 'Kochi',
    state: 'Kerala',
    postalCode: '682011',
    country: 'India',
    pointsBalance: 320,
    lifetimePointsEarned: 520,
    tier: 'Tide Explorer',
    totalSpend: 6200.00,
    ordersCount: 3,
    loyaltyHistory: []
  },
  {
    id: 'cust-04',
    name: 'Aarav Singhania',
    email: 'aarav.singhania@bengalurusurf.in',
    phone: '+91 98450 11923',
    address: '104 Indiranagar 100ft Road',
    city: 'Bengaluru',
    state: 'Karnataka',
    postalCode: '560038',
    country: 'India',
    pointsBalance: 420,
    lifetimePointsEarned: 420,
    tier: 'Tide Explorer',
    totalSpend: 4999.00,
    ordersCount: 2,
    loyaltyHistory: []
  }
];
