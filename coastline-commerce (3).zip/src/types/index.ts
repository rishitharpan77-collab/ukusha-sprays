export interface ProductVariant {
  id: string;
  size: string;
  volumeMl: number;
  price: number;
  originalPrice?: number;
  stock: number;
}

export interface Product {
  id: string;
  name: string;
  subtitle: string;
  tagline: string;
  category: 'original' | 'driftwood' | 'waves' | 'bundle';
  price: number;
  originalPrice?: number;
  rating: number;
  reviewsCount: number;
  image: string;
  gallery: string[];
  description: string;
  holdLevel: 'Light Natural' | 'Medium Textured' | 'Firm Gritty';
  finish: 'Matte Beach Natural' | 'Satin Hydrated' | 'Wind-Blown Matte';
  scentProfile: {
    top: string;
    heart: string;
    base: string;
  };
  keyIngredients: string[];
  howToUse: string[];
  variants: ProductVariant[];
  inStock: boolean;
  totalStock: number;
  isBestSeller?: boolean;
  badge?: string;
}

export interface CartItem {
  id: string;
  productId: string;
  product: Product;
  selectedVariant: ProductVariant;
  quantity: number;
}

export interface LoyaltyReward {
  id: string;
  title: string;
  description: string;
  pointsCost: number;
  discountType: 'fixed' | 'percentage' | 'free_product';
  discountValue: number; // e.g. $10, $25, 20%
  code: string;
  minOrderValue?: number;
  isUnlocked?: boolean;
}

export interface LoyaltyTransaction {
  id: string;
  date: string;
  description: string;
  pointsChange: number; // + or -
  type: 'earned_purchase' | 'redeemed_reward' | 'welcome_bonus' | 'review_reward' | 'admin_adjustment';
  relatedOrderId?: string;
}

export interface CustomerProfile {
  id: string;
  name: string;
  email: string;
  phone: string;
  address: string;
  city: string;
  state: string;
  postalCode: string;
  country: string;
  pointsBalance: number;
  lifetimePointsEarned: number;
  tier: 'Coastal Seeker' | 'Tide Explorer' | 'High Tide VIP';
  totalSpend: number;
  ordersCount: number;
  loyaltyHistory: LoyaltyTransaction[];
}

export type OrderStatus = 
  | 'payment_confirmed'
  | 'pickup_scheduled'
  | 'carrier_picked_up'
  | 'in_transit'
  | 'out_for_delivery'
  | 'delivered';

export interface CourierPickupDetails {
  carrier: 'BlueDart Ocean Express' | 'Delhivery Coastal Priority' | 'DTDC Green Express' | 'FedEx Coastal Priority' | 'DHL Maritime Express';
  pickupRequestId: string;
  pickupWarehouse: string;
  pickupScheduledTime: string;
  trackingNumber: string;
  estimatedCustomerDropoff: string;
  shippingLabelUrl?: string;
  pickupNotes?: string;
  status: 'Pending Dispatch' | 'Carrier En Route to Merchant' | 'Picked Up from Merchant' | 'In Transit to Customer' | 'Delivered';
}

export interface PaymentSecurityMetadata {
  method: 'card' | 'upi' | 'apple_pay' | 'google_pay' | 'cod';
  last4?: string;
  upiId?: string;
  cardBrand?: string;
  encryptedTransactionToken: string; // e.g. "AES-GCM-256::tok_live_79a2..."
  pciComplianceVerified: boolean;
  timestamp: string;
  ipHash: string;
}

export interface Order {
  id: string;
  orderNumber: string;
  createdAt: string;
  customer: {
    name: string;
    email: string;
    phone: string;
    address: string;
    city: string;
    state: string;
    postalCode: string;
    country: string;
  };
  items: CartItem[];
  subtotal: number;
  discountAmount: number;
  discountCode?: string;
  shippingFee: number;
  taxAmount: number;
  total: number;
  pointsEarned: number;
  pointsRedeemed?: number;
  status: OrderStatus;
  payment: PaymentSecurityMetadata;
  courierPickup: CourierPickupDetails;
}

export interface InventoryItem {
  productId: string;
  variantId: string;
  productName: string;
  variantSize: string;
  sku: string;
  availableStock: number;
  reservedStock: number;
  lowStockThreshold: number;
  costPrice: number;
  retailPrice: number;
}
